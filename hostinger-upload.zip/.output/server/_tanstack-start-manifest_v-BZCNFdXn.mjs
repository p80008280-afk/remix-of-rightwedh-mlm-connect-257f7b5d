//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BZCNFdXn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/contact",
			"/disclaimer",
			"/forgot-password",
			"/login",
			"/plan",
			"/privacy",
			"/products",
			"/refund",
			"/register",
			"/sitemap.xml",
			"/terms",
			"/sbp/$"
		],
		preloads: ["/assets/index-L2Y2nc19.js", "/assets/useSelector-C0pj3Bsi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-L2Y2nc19.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DtVvolwB.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/arrow-right-BreTTagn.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/download-dz5W4KKb.js",
			"/assets/SiteLayout-Bd_-d7mU.js",
			"/assets/star-CVAYwxdY.js",
			"/assets/shopping-bag-Kl6hK9mI.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js"
		]
	},
	"/_authenticated": {
		filePath: "/dev-server/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin", "/_authenticated/dashboard"],
		preloads: ["/assets/route-DXO7RBb_.js"]
	},
	"/about": {
		filePath: "/dev-server/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-ysLhGNvd.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/SiteLayout-Bd_-d7mU.js"
		]
	},
	"/contact": {
		filePath: "/dev-server/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BXdI5xkC.js",
			"/assets/clock-DhIl8hnh.js",
			"/assets/SiteLayout-Bd_-d7mU.js",
			"/assets/wallet-Cs0V40q1.js"
		]
	},
	"/disclaimer": {
		filePath: "/dev-server/src/routes/disclaimer.tsx",
		children: void 0,
		preloads: ["/assets/disclaimer-B2HRPTin.js", "/assets/SiteLayout-Bd_-d7mU.js"]
	},
	"/forgot-password": {
		filePath: "/dev-server/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-B2ZZUsJl.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-Bd_-d7mU.js"
		]
	},
	"/login": {
		filePath: "/dev-server/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-sSVAFBA0.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-Bd_-d7mU.js"
		]
	},
	"/plan": {
		filePath: "/dev-server/src/routes/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-DMS2UwU1.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/arrow-right-BreTTagn.js",
			"/assets/SiteLayout-Bd_-d7mU.js",
			"/assets/plus-BQgSUM9m.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js"
		]
	},
	"/privacy": {
		filePath: "/dev-server/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-ec2tHYlk.js", "/assets/SiteLayout-Bd_-d7mU.js"]
	},
	"/products": {
		filePath: "/dev-server/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DCunMICk.js",
			"/assets/SiteLayout-Bd_-d7mU.js",
			"/assets/star-CVAYwxdY.js",
			"/assets/shopping-bag-Kl6hK9mI.js"
		]
	},
	"/refund": {
		filePath: "/dev-server/src/routes/refund.tsx",
		children: void 0,
		preloads: ["/assets/refund-zpAcvBQf.js", "/assets/SiteLayout-Bd_-d7mU.js"]
	},
	"/register": {
		filePath: "/dev-server/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-DKcrhuIG.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/copy-CMHWJAm5.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-Bd_-d7mU.js"
		]
	},
	"/terms": {
		filePath: "/dev-server/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-B_ts2EDR.js", "/assets/SiteLayout-Bd_-d7mU.js"]
	},
	"/_authenticated/admin": {
		filePath: "/dev-server/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-JJ09I7ZD.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/download-dz5W4KKb.js",
			"/assets/log-out-BBDDtYdP.js",
			"/assets/plus-BQgSUM9m.js",
			"/assets/users-BsfoCn1D.js",
			"/assets/wallet-Cs0V40q1.js",
			"/assets/x-GyDu7eCf.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-BClORMu9.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/clock-DhIl8hnh.js",
			"/assets/copy-CMHWJAm5.js",
			"/assets/log-out-BBDDtYdP.js",
			"/assets/shopping-bag-Kl6hK9mI.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js",
			"/assets/wallet-Cs0V40q1.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
