//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CdK5fPt_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/contact",
			"/disclaimer",
			"/forgot-password",
			"/login",
			"/plan",
			"/privacy",
			"/products",
			"/refund",
			"/register",
			"/sitemap.xml",
			"/terms",
			"/sbp/$"
		],
		preloads: ["/assets/index-GqzRCOut.js", "/assets/useSelector-C0pj3Bsi.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-GqzRCOut.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C0ORWWQ7.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/arrow-right-BreTTagn.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/download-dz5W4KKb.js",
			"/assets/SiteLayout-BB4mSBeJ.js",
			"/assets/star-CVAYwxdY.js",
			"/assets/shopping-bag-Kl6hK9mI.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js"
		]
	},
	"/_authenticated": {
		filePath: "/dev-server/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin", "/_authenticated/dashboard"],
		preloads: ["/assets/route-Do0t5JRe.js"]
	},
	"/about": {
		filePath: "/dev-server/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DPgiaWvh.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/SiteLayout-BB4mSBeJ.js"
		]
	},
	"/contact": {
		filePath: "/dev-server/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-DG7WxIPw.js",
			"/assets/clock-DhIl8hnh.js",
			"/assets/SiteLayout-BB4mSBeJ.js",
			"/assets/wallet-Cs0V40q1.js"
		]
	},
	"/disclaimer": {
		filePath: "/dev-server/src/routes/disclaimer.tsx",
		children: void 0,
		preloads: ["/assets/disclaimer-BNpmM8Dv.js", "/assets/SiteLayout-BB4mSBeJ.js"]
	},
	"/forgot-password": {
		filePath: "/dev-server/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-Bi7ThQLG.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-BB4mSBeJ.js"
		]
	},
	"/login": {
		filePath: "/dev-server/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CnfI1RvI.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-BB4mSBeJ.js"
		]
	},
	"/plan": {
		filePath: "/dev-server/src/routes/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-BQa-hW0i.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/arrow-right-BreTTagn.js",
			"/assets/SiteLayout-BB4mSBeJ.js",
			"/assets/plus-BQgSUM9m.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js"
		]
	},
	"/privacy": {
		filePath: "/dev-server/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-B65Qcl5d.js", "/assets/SiteLayout-BB4mSBeJ.js"]
	},
	"/products": {
		filePath: "/dev-server/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DCzlGzpr.js",
			"/assets/SiteLayout-BB4mSBeJ.js",
			"/assets/star-CVAYwxdY.js",
			"/assets/shopping-bag-Kl6hK9mI.js"
		]
	},
	"/refund": {
		filePath: "/dev-server/src/routes/refund.tsx",
		children: void 0,
		preloads: ["/assets/refund-e37OmyKS.js", "/assets/SiteLayout-BB4mSBeJ.js"]
	},
	"/register": {
		filePath: "/dev-server/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-wvdp_XbU.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/copy-CMHWJAm5.js",
			"/assets/password-input-BpMPp1VV.js",
			"/assets/SiteLayout-BB4mSBeJ.js"
		]
	},
	"/terms": {
		filePath: "/dev-server/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-BnyiCptM.js", "/assets/SiteLayout-BB4mSBeJ.js"]
	},
	"/_authenticated/admin": {
		filePath: "/dev-server/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-WcOZrpaB.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/circle-check-e96BBa8W.js",
			"/assets/download-dz5W4KKb.js",
			"/assets/log-out-BBDDtYdP.js",
			"/assets/plus-BQgSUM9m.js",
			"/assets/users-BsfoCn1D.js",
			"/assets/wallet-Cs0V40q1.js",
			"/assets/x-GyDu7eCf.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-8coBr0CP.js",
			"/assets/createLucideIcon-BzbuOpc0.js",
			"/assets/clock-DhIl8hnh.js",
			"/assets/copy-CMHWJAm5.js",
			"/assets/log-out-BBDDtYdP.js",
			"/assets/shopping-bag-Kl6hK9mI.js",
			"/assets/trending-up-CT2_jQej.js",
			"/assets/users-BsfoCn1D.js",
			"/assets/wallet-Cs0V40q1.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
