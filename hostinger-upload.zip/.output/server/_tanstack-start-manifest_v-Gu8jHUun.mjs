//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Gu8jHUun.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/contact",
			"/disclaimer",
			"/forgot-password",
			"/login",
			"/plan",
			"/privacy",
			"/products",
			"/refund",
			"/register",
			"/sitemap.xml",
			"/terms"
		],
		preloads: ["/assets/index-ZzwFvoB2.js", "/assets/useStore-DAs5vFz2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ZzwFvoB2.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-C5WZrcYz.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/arrow-right-CaTwsgy1.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/SiteLayout-DT2TAG4L.js",
			"/assets/star-z4IXGf62.js",
			"/assets/shopping-bag-C1VUHukY.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js"
		]
	},
	"/_authenticated": {
		filePath: "/dev-server/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin", "/_authenticated/dashboard"],
		preloads: ["/assets/route-DfxcyOBD.js"]
	},
	"/about": {
		filePath: "/dev-server/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-C3EfAe9V.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/SiteLayout-DT2TAG4L.js"
		]
	},
	"/contact": {
		filePath: "/dev-server/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-B8x8tYoe.js",
			"/assets/clock-TG24jTAE.js",
			"/assets/SiteLayout-DT2TAG4L.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	},
	"/disclaimer": {
		filePath: "/dev-server/src/routes/disclaimer.tsx",
		children: void 0,
		preloads: ["/assets/disclaimer-C8VH-Hd9.js", "/assets/SiteLayout-DT2TAG4L.js"]
	},
	"/forgot-password": {
		filePath: "/dev-server/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-D-yWdZ4b.js",
			"/assets/mlm.functions-DPUc81vs.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-DT2TAG4L.js"
		]
	},
	"/login": {
		filePath: "/dev-server/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-D_qFmvoP.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-DT2TAG4L.js"
		]
	},
	"/plan": {
		filePath: "/dev-server/src/routes/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-ySW9X5Op.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/arrow-right-CaTwsgy1.js",
			"/assets/SiteLayout-DT2TAG4L.js",
			"/assets/plus-CEpKvdwy.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js"
		]
	},
	"/privacy": {
		filePath: "/dev-server/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-Dc9d1H3k.js", "/assets/SiteLayout-DT2TAG4L.js"]
	},
	"/products": {
		filePath: "/dev-server/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-DOeozzOA.js",
			"/assets/SiteLayout-DT2TAG4L.js",
			"/assets/star-z4IXGf62.js",
			"/assets/shopping-bag-C1VUHukY.js"
		]
	},
	"/refund": {
		filePath: "/dev-server/src/routes/refund.tsx",
		children: void 0,
		preloads: ["/assets/refund-Cj5qOp32.js", "/assets/SiteLayout-DT2TAG4L.js"]
	},
	"/register": {
		filePath: "/dev-server/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-Cfo6N66l.js",
			"/assets/mlm.functions-DPUc81vs.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/copy-DbTxdhzR.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-DT2TAG4L.js"
		]
	},
	"/terms": {
		filePath: "/dev-server/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-CJ9KPTxx.js", "/assets/SiteLayout-DT2TAG4L.js"]
	},
	"/_authenticated/admin": {
		filePath: "/dev-server/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-BDwex2ci.js",
			"/assets/mlm.functions-DPUc81vs.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/log-out-D46uYx7J.js",
			"/assets/plus-CEpKvdwy.js",
			"/assets/users-CxxkGPZO.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-B7tku3A4.js",
			"/assets/mlm.functions-DPUc81vs.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/clock-TG24jTAE.js",
			"/assets/copy-DbTxdhzR.js",
			"/assets/log-out-D46uYx7J.js",
			"/assets/shopping-bag-C1VUHukY.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
