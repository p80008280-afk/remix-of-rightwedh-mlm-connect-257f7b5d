import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-C3f2JH_W.js
var import_jsx_runtime = require_jsx_runtime();
function Privacy() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-gradient-hero text-primary-foreground py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-5xl",
					children: "Privacy Policy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary-foreground/80",
					children: "Your data. Our responsibility."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-6 py-16 space-y-8 text-[15px] leading-relaxed text-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "1. Information We Collect",
				children: "When you register or purchase, we collect your name, email, phone number, UPI ID, payment screenshot and referral relationships. We do not collect passwords in plain text or store your card details."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "2. How We Use Your Information",
				children: "We use your information to create your account, place you in the binary tree, verify payments, credit commissions, process withdrawals to your UPI, and to contact you about your account, orders and rewards."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "3. Sharing",
				children: "We do not sell your data. Limited data is shared with (a) our payment processor for UPI verification, (b) our upline sponsor for team visibility (name, referral code, active status only) and (c) government / regulatory authorities if legally required."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "4. Data Retention",
				children: "Account, order and commission records are retained for as long as your account is active and for a further period required for tax and legal compliance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "5. Security",
				children: "Your data is stored on encrypted infrastructure. Payment screenshots are stored in a private bucket accessible only to you and the admin. Withdrawal UPI is only visible to you and the admin."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "6. Your Rights",
				children: [
					"You may request access to, correction of, or deletion of your personal data at any time by writing to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-primary underline",
						href: "mailto:righvedhsanjivni@gmail.com",
						children: "righvedhsanjivni@gmail.com"
					}),
					". Deletion of an active MLM account will result in forfeiture of un-withdrawn income."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "7. Cookies",
				children: "We use only essential cookies required to keep you signed in. We do not use third-party advertising cookies."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "8. Changes",
				children: "This policy may be updated from time to time. The latest version will always be available on this page."
			})
		]
	})] });
}
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl text-primary mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children
	})] });
}
//#endregion
export { Privacy as component };
