import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { G as ArrowRight, O as Leaf, U as CircleCheck, a as UserCheck, c as TrendingUp, f as Star, g as ShieldCheck, h as ShoppingBag, o as Upload, p as Sparkles, r as Users } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bgp40sKA.js
var import_jsx_runtime = require_jsx_runtime();
var capsuleAsset = { url: "/aaurva-capsule.png" };
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative overflow-hidden bg-gradient-hero text-primary-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 opacity-[0.12]",
				style: { backgroundImage: "radial-gradient(circle at 15% 20%, oklch(0.75 0.13 85) 0%, transparent 45%), radial-gradient(circle at 85% 75%, oklch(0.5 0.13 150) 0%, transparent 45%)" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-7xl px-6 py-24 lg:py-28 grid lg:grid-cols-2 gap-14 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "inline-flex items-center gap-2 rounded-full border border-gold/40 bg-gold/10 px-4 py-1.5 text-xs font-medium text-gold uppercase tracking-widest",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "h-3.5 w-3.5" }), " Ayurveda · Wealth · Wellness"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-6 font-serif text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05]",
						children: [
							"The power of nature,",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-gold",
								children: "in your life."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-lg text-primary-foreground/80 max-w-xl leading-relaxed",
						children: "Righvedh Sanjivni brings you pure Ayurvedic products and a rewarding business opportunity — where every sale and every pair builds real income and recognition."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex flex-wrap gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/register",
							className: "inline-flex items-center gap-2 rounded-full bg-gradient-gold px-8 py-4 text-base font-semibold text-gold-foreground shadow-gold hover:opacity-90 transition",
							children: ["Join The Family ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/plan",
							className: "inline-flex items-center gap-2 rounded-full border border-gold/50 px-8 py-4 text-base font-semibold text-primary-foreground hover:bg-gold/10 transition",
							children: "View Business Plan"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-12 grid grid-cols-3 gap-6 max-w-lg",
						children: [
							{
								n: "₹900",
								l: "Direct Commission"
							},
							{
								n: "₹300",
								l: "Pair Matching"
							},
							{
								n: "24/7",
								l: "Support"
							}
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-3xl text-gold font-bold",
							children: s.n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-widest text-primary-foreground/60 mt-1",
							children: s.l
						})] }, s.l))
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-6 bg-gold/15 blur-3xl rounded-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative rounded-3xl overflow-hidden border border-gold/30 bg-background shadow-elegant",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-[4/5]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: capsuleAsset.url,
									alt: "Aaurva Ayurvedic Weight Natural Power capsule",
									className: "absolute inset-0 h-full w-full object-cover"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-4 left-4 rounded-full bg-gold text-gold-foreground text-[11px] px-3 py-1 font-bold shadow-gold",
									children: "BESTSELLER"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/85 via-black/50 to-transparent text-white",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[11px] uppercase tracking-[0.25em] text-gold",
											children: "Aaurva Capsule"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-serif text-2xl mt-1",
											children: "Ayurvedic Weight Natural Power"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex items-end justify-between",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-white/70",
												children: "MRP"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "font-bold text-2xl",
												children: "₹ 3,250"
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-right",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-white/70",
													children: "Earn per sale"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "font-bold text-xl text-gold",
													children: "₹ 900"
												})]
											})]
										})
									]
								})
							]
						})
					})]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center max-w-2xl mx-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Why Righvedh Sanjivni"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl md:text-5xl text-primary",
						children: "One platform, endless opportunity."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted-foreground",
						children: "The purity of Ayurveda, the transparency of technology, and a fair binary income plan — all in one place."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-16 grid md:grid-cols-2 lg:grid-cols-4 gap-6",
				children: [
					{
						icon: Leaf,
						title: "100% Ayurveda",
						desc: "Premium products made from pure, natural herbs."
					},
					{
						icon: ShieldCheck,
						title: "Trusted Quality",
						desc: "Manufactured to GMP & ISO certified standards."
					},
					{
						icon: Users,
						title: "Binary Team Plan",
						desc: "Build left & right legs and earn pair income."
					},
					{
						icon: TrendingUp,
						title: "Unlimited Growth",
						desc: "Direct + pair + rank bonus — no earning cap."
					}
				].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative rounded-2xl border border-border bg-card p-8 shadow-soft hover:shadow-elegant transition",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-14 w-14 rounded-xl bg-gradient-gold flex items-center justify-center shadow-gold",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "h-7 w-7 text-gold-foreground" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-6 font-serif text-xl text-primary",
							children: f.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground leading-relaxed",
							children: f.desc
						})
					]
				}, f.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-leaf",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-6 py-24 grid lg:grid-cols-2 gap-14 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Business Plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl md:text-5xl text-primary",
						children: "Simple Binary — Powerful Income."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground leading-relaxed",
						children: "You are A. You bring in two people — B and C. Whenever B or C makes a sale, you earn a direct commission. And when B and C form a matching pair, you earn a pair bonus. Every member has their own \"+\" option to invite new members into any empty position."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-3",
						children: [
							"₹900 direct sponsor commission on every product sale",
							"₹300 pair matching bonus on every left-right match",
							"Level & rank rewards for growing leaders",
							"Real-time genealogy tree with plus-position invites"
						].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-5 w-5 text-gold shrink-0" }),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: i })
							]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/plan",
						className: "mt-8 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow transition",
						children: ["Explore The Full Plan ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-3xl border border-border bg-card p-10 shadow-elegant",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BinaryTreePreview, {})
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-7xl px-6 py-24",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between flex-wrap gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Flagship Product"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl md:text-5xl text-primary",
					children: "Aaurva — Weight Natural Power"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/products",
					className: "text-primary font-semibold hover:text-primary-glow inline-flex items-center gap-1",
					children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 grid lg:grid-cols-2 gap-10 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative rounded-3xl overflow-hidden border border-border shadow-elegant bg-gradient-leaf",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: capsuleAsset.url,
						alt: "Aaurva capsule bottle",
						className: "w-full aspect-square object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-gold",
						children: [Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-current" }, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-xs text-muted-foreground",
							children: "Trusted by 10,000+ customers"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-serif text-3xl text-primary",
						children: "Ayurvedic Weight Natural Power"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted-foreground leading-relaxed",
						children: "A 100% pure herbal weight gain formula with 10+ powerful Ayurvedic ingredients. 60 capsules per bottle — crafted for natural strength, stamina and vitality."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "MRP",
								value: "₹ 3,250"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Direct Commission",
								value: "₹ 900",
								accent: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Pair Matching",
								value: "₹ 300",
								accent: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/products",
							className: "inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary-glow",
							children: ["Shop Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/plan",
							className: "inline-flex items-center gap-2 rounded-full border border-primary/30 px-6 py-3 text-sm font-semibold text-primary hover:bg-primary/5",
							children: "Earning Details"
						})]
					})
				] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-leaf py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center max-w-2xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
							children: "Secure Checkout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-serif text-4xl text-primary",
							children: "QR appears only during product checkout."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-muted-foreground leading-relaxed",
							children: "Members choose a product, pay from the dashboard checkout, upload the payment screenshot, and admin approves it from the Orders tab."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-6 md:grid-cols-3",
					children: [
						{
							icon: ShoppingBag,
							title: "Add to cart",
							desc: "Member opens dashboard shop and selects the product."
						},
						{
							icon: Upload,
							title: "Pay & upload",
							desc: "Checkout shows the current admin QR/UPI and asks for payment proof."
						},
						{
							icon: UserCheck,
							title: "Admin approval",
							desc: "Admin verifies the screenshot, then approves or rejects the order."
						}
					].map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-7 shadow-soft text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mx-auto h-14 w-14 rounded-xl bg-gradient-gold flex items-center justify-center shadow-gold",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(step.icon, { className: "h-7 w-7 text-gold-foreground" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-serif text-xl text-primary",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: step.desc
							})
						]
					}, step.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-7xl px-6 pb-24 pt-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative overflow-hidden rounded-3xl bg-gradient-hero p-12 md:p-16 text-center text-primary-foreground shadow-elegant",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 opacity-10",
					style: { backgroundImage: "radial-gradient(circle at center, oklch(0.75 0.13 85) 0%, transparent 60%)" }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-serif text-4xl md:text-5xl",
							children: "Start your journey today."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-primary-foreground/80 max-w-xl mx-auto",
							children: "Join the Righvedh Sanjivni family through your sponsor's referral link."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/register",
							className: "mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-8 py-4 text-base font-semibold text-gold-foreground shadow-gold hover:opacity-90",
							children: ["Register Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
						})
					]
				})]
			})
		})
	] });
}
function Stat({ label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl p-4 border ${accent ? "bg-gradient-gold border-gold/40 text-gold-foreground shadow-gold" : "bg-card border-border"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-[10px] uppercase tracking-widest font-semibold ${accent ? "text-gold-foreground/80" : "text-muted-foreground"}`,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mt-1 font-bold text-lg ${accent ? "" : "text-primary"}`,
			children: value
		})]
	});
}
function TreePill({ label, tone = "primary" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `w-16 h-16 rounded-full flex items-center justify-center font-serif text-xl font-bold ${tone === "gold" ? "bg-gradient-gold text-gold-foreground shadow-gold" : "bg-primary text-primary-foreground shadow-soft"}`,
		children: label
	});
}
function BinaryTreePreview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, {
				label: "A",
				tone: "gold"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full flex justify-between max-w-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-6 bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-6 bg-border" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full flex justify-between max-w-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, { label: "B" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, { label: "C" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full flex justify-between max-w-xs mt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, { label: "D" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, { label: "E" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, { label: "F" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreePill, {
						label: "+",
						tone: "gold"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mt-4 text-center max-w-xs",
				children: "Tap the \"+\" on any node to invite a new member into that left or right position."
			})
		]
	});
}
//#endregion
export { Home as component };
