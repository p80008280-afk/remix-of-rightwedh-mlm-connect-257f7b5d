import { r as __toESM } from "../_runtime.mjs";
import { r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { O as isRedirect, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as TSS_SERVER_FUNCTION, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-49HeUXBo.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Cy4wKG6N.mjs";
import { a as stringType, i as objectType, n as enumType, r as numberType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mlm.functions-DUvakcGb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var registerMember = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date of birth"),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).default(""),
	position: enumType(["left", "right"])
}).parse(d)).handler(createSsrRpc("63df4d594e6482f23fb402be517e760acd7f7520fcefed57001f882f6f0d875f"));
var getMyDirectTeam = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("d3aa2b19004a5d6f224214912fba60f0cce69c57763035e0c208c1bd2fef493e"));
var reviewOrder = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	orderId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(createSsrRpc("800fce929f9fbc54248d521eaf53940de033b7ebbe1a1b88c6ba46e75d0023ce"));
var reviewWithdrawal = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	withdrawalId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(createSsrRpc("c638f4607614c44874652ef7ac5e174ebdd5634c7945d171fa73d8e960f5e90f"));
var upsertProduct = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	id: stringType().uuid().optional(),
	name: stringType().min(1),
	description: stringType().default(""),
	category: stringType().default("General"),
	image_url: stringType().default(""),
	mrp: numberType().nonnegative(),
	direct_commission: numberType().nonnegative(),
	pair_bonus: numberType().nonnegative(),
	stock: numberType().int().nonnegative(),
	status: enumType(["active", "inactive"]).default("active")
}).parse(d)).handler(createSsrRpc("08bc5bd1ba03345ea7136845a5dcc41ecd564e120451e2161dacbcb1623972e9"));
var updateMemberStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	kyc_status: enumType([
		"pending",
		"approved",
		"rejected"
	]).optional(),
	is_active: booleanType().optional()
}).parse(d)).handler(createSsrRpc("06cffbec6e121ebebf665af3d686f5d02fd7099d000a0389ab7fa99e83a041af"));
var updatePlanSettings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	min_withdrawal: numberType().nonnegative(),
	tds_percent: numberType().nonnegative(),
	admin_charge: numberType().nonnegative(),
	withdrawal_days: numberType().int().nonnegative(),
	daily_pair_cap: numberType().int().nonnegative(),
	refund_days: numberType().int().nonnegative(),
	monthly_repurchase: booleanType(),
	upi_id: stringType().min(3),
	payment_account_name: stringType().min(1),
	qr_image_url: stringType().min(1),
	qr_image_path: stringType().optional()
}).parse(d)).handler(createSsrRpc("26e7b1016ca7c300ae5d8c7e203d33245a5849dccea16ae780328a68f1e9f63f"));
var resetMemberPassword = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	email: stringType().trim().email(),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(createSsrRpc("daf614919d3622098abde76cc72ecfaedbd8fae5c963bdd9e051f7b9fadf1546"));
var getMyTree = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("49423a5f7efbde3049ab55f24ea06c0ad3bdf2b8e88a476dc6aafc505ce086df"));
var adminAddMember = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().optional().default("").transform((v) => /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).default(""),
	position: enumType(["left", "right"]).default("left"),
	activate: booleanType().default(false)
}).parse(d)).handler(createSsrRpc("6978bdfc0dc1d046ce1dda251923d4745b80d44c0d8131631f6e212e90039d6c"));
var adminSetAccountState = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	account_status: enumType([
		"active",
		"inactive",
		"suspended",
		"banned"
	]).optional(),
	is_active: booleanType().optional()
}).parse(d)).handler(createSsrRpc("b13323a0bf590f1cc5a38d042991d5a29ab954e2683c33ff11dd3cadfd9e49f2"));
var adminSetMemberPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(createSsrRpc("8149b961c456bf893dd4e18fd23c3873aeb46314bfc3abfc06b344c6e908a977"));
var claimMyReward = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ level: numberType().int().positive() }).parse(d)).handler(createSsrRpc("edeb85c398aad8de0a3e5548afa06784ef16364854c645b9efaf1e5ed785647e"));
var expireMyRewards = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(createSsrRpc("95c78d13f7863edc18b525b9fc4699f3d1919b2b6a6eb3c6a6a4ccc34c63d397"));
//#endregion
export { expireMyRewards as a, registerMember as c, reviewWithdrawal as d, updateMemberStatus as f, useServerFn as h, claimMyReward as i, resetMemberPassword as l, upsertProduct as m, adminSetAccountState as n, getMyDirectTeam as o, updatePlanSettings as p, adminSetMemberPassword as r, getMyTree as s, adminAddMember as t, reviewOrder as u };
