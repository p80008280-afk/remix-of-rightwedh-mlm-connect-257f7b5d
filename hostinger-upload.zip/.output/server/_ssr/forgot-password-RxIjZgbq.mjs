import { r as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
import { h as useServerFn, l as resetMemberPassword } from "./mlm.functions-DUvakcGb.mjs";
import { t as PasswordInput } from "./password-input-DZQVOfRZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-RxIjZgbq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ForgotPassword() {
	const nav = useNavigate();
	const reset = useServerFn(resetMemberPassword);
	const [f, setF] = (0, import_react.useState)({
		mobile: "",
		email: "",
		dob: "",
		newPassword: "",
		confirm: ""
	});
	const [msg, setMsg] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	async function submit(e) {
		e.preventDefault();
		setError("");
		setMsg("");
		if (f.newPassword !== f.confirm) {
			setError("Both passwords must match.");
			return;
		}
		setBusy(true);
		try {
			await reset({ data: {
				mobile: f.mobile.trim(),
				email: f.email,
				dob: f.dob,
				newPassword: f.newPassword
			} });
			setMsg("Password updated. You can login now with your mobile number and new password.");
			setTimeout(() => {
				nav({ to: "/login" });
			}, 1800);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not reset the password.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "min-h-[80vh] flex items-center justify-center bg-gradient-leaf px-6 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border bg-card p-10 shadow-elegant",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-serif text-3xl text-primary text-center",
					children: "Forgot Password"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-sm text-muted-foreground",
					children: "Verify the details you gave at registration to set a new password."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-4",
					onSubmit: submit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Registered Mobile Number",
							value: f.mobile,
							onChange: (v) => setF({
								...f,
								mobile: v
							}),
							placeholder: "10-digit mobile"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Registered Email",
							type: "email",
							value: f.email,
							onChange: (v) => setF({
								...f,
								email: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date of Birth",
							type: "date",
							value: f.dob,
							onChange: (v) => setF({
								...f,
								dob: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "New Password",
							type: "password",
							value: f.newPassword,
							onChange: (v) => setF({
								...f,
								newPassword: v
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Confirm New Password",
							type: "password",
							value: f.confirm,
							onChange: (v) => setF({
								...f,
								confirm: v
							})
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg bg-destructive/10 text-destructive text-sm p-3",
							children: error
						}),
						msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg bg-primary/10 text-primary text-sm p-3",
							children: msg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: busy || !ready,
							className: "w-full rounded-full bg-gradient-gold py-3.5 font-semibold text-gold-foreground shadow-gold disabled:opacity-60",
							children: busy ? "Updating..." : !ready ? "Please wait..." : "Reset Password"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-center text-sm text-muted-foreground",
					children: ["Remembered it? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "text-primary hover:underline",
						children: "Back to login"
					})]
				})
			]
		})
	}) });
}
function Field({ label, value, onChange, type = "text", placeholder }) {
	if (type === "password") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
			value,
			onChange,
			placeholder,
			autoComplete: "new-password"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			required: true,
			value,
			placeholder,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm focus:ring-2 focus:ring-ring"
		})]
	});
}
//#endregion
export { ForgotPassword as component };
