import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DCIbG3ZB.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { c as HeadContent, d as Outlet, f as lazyRouteComponent, h as Link, j as redirect, m as createRootRouteWithContext, p as createFileRoute, s as Scripts, u as createRouter, v as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as stringType, i as objectType, n as enumType } from "../_libs/zod.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-ANKBaFsR.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DHzyrMHg.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$16 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Righvedh Sanjivni — Ayurveda Wellness & Business Opportunity" },
			{
				name: "description",
				content: "Righvedh Sanjivni is a premium Ayurveda wellness company offering pure herbal products and a rewarding binary MLM business opportunity across India."
			},
			{
				name: "author",
				content: "Righvedh Sanjivni"
			},
			{
				property: "og:title",
				content: "Righvedh Sanjivni — Ayurveda Wellness"
			},
			{
				property: "og:description",
				content: "Pure Ayurveda products and a rewarding direct-selling opportunity. Join Righvedh Sanjivni today."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800&family=Inter:wght@400;500;600;700&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$16.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$14 = () => import("./terms-BkEyjURS.mjs");
var Route$15 = createFileRoute("/terms")({
	head: () => ({
		meta: [
			{ title: "Terms & Conditions — Righvedh Sanjivni" },
			{
				name: "description",
				content: "The terms and conditions that govern membership, purchases and commissions on Righvedh Sanjivni."
			},
			{
				property: "og:title",
				content: "Terms & Conditions — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Membership, purchase and commission terms."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/terms"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/terms"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var BASE_URL = "https://righvedhsanjivni.in";
var Route$14 = createFileRoute("/sitemap.xml")({ server: { handlers: { GET: async () => {
	const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${[
		{
			path: "/",
			priority: "1.0",
			changefreq: "weekly"
		},
		{
			path: "/about",
			priority: "0.8",
			changefreq: "monthly"
		},
		{
			path: "/products",
			priority: "0.9",
			changefreq: "weekly"
		},
		{
			path: "/plan",
			priority: "0.9",
			changefreq: "monthly"
		},
		{
			path: "/contact",
			priority: "0.7",
			changefreq: "monthly"
		},
		{
			path: "/login",
			priority: "0.4",
			changefreq: "yearly"
		},
		{
			path: "/register",
			priority: "0.6",
			changefreq: "monthly"
		}
	].map((e) => `  <url>\n    <loc>${BASE_URL}${e.path}</loc>\n    <changefreq>${e.changefreq}</changefreq>\n    <priority>${e.priority}</priority>\n  </url>`).join("\n")}\n</urlset>`;
	return new Response(xml, { headers: {
		"Content-Type": "application/xml",
		"Cache-Control": "public, max-age=3600"
	} });
} } } });
var $$splitComponentImporter$13 = () => import("./register-WlCk0210.mjs");
var search = objectType({
	ref: stringType().optional(),
	pos: enumType(["left", "right"]).optional()
});
var Route$13 = createFileRoute("/register")({
	validateSearch: search,
	head: () => ({
		meta: [
			{ title: "Register — Righvedh Sanjivni" },
			{
				name: "description",
				content: "Join Righvedh Sanjivni. Register with your mobile number and your sponsor's referral code."
			},
			{
				property: "og:title",
				content: "Register — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Create a Righvedh Sanjivni member account with a sponsor referral."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/register"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/register"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("./refund-BLsgZdnF.mjs");
var Route$12 = createFileRoute("/refund")({
	head: () => ({
		meta: [
			{ title: "Refund & Return Policy — Righvedh Sanjivni" },
			{
				name: "description",
				content: "15-day product return and exchange window at Righvedh Sanjivni."
			},
			{
				property: "og:title",
				content: "Refund & Return Policy — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "15-day return / exchange window."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/refund"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/refund"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$12, "component")
});
var $$splitComponentImporter$11 = () => import("./products-DaItDv2v.mjs");
var Route$11 = createFileRoute("/products")({
	head: () => ({
		meta: [
			{ title: "Products — Righvedh Sanjivni Ayurveda Range" },
			{
				name: "description",
				content: "Pure Ayurvedic products by Righvedh Sanjivni — Aaurva capsule, immunity, detox and wellness. Every product earns you commission."
			},
			{
				property: "og:title",
				content: "Products — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Premium Ayurveda products with business volume rewards."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/products"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/products"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./privacy-C3f2JH_W.mjs");
var Route$10 = createFileRoute("/privacy")({
	head: () => ({
		meta: [
			{ title: "Privacy Policy — Righvedh Sanjivni" },
			{
				name: "description",
				content: "How Righvedh Sanjivni collects, uses and protects your personal information."
			},
			{
				property: "og:title",
				content: "Privacy Policy — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "How we handle your data."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/privacy"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/privacy"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("./plan-CvGGa8gx.mjs");
var Route$9 = createFileRoute("/plan")({
	head: () => ({
		meta: [
			{ title: "Business Plan — Righvedh Sanjivni Binary MLM" },
			{
				name: "description",
				content: "The Righvedh Sanjivni binary MLM plan — direct sale commission, pair matching bonus, level income and rank rewards. Simple and fair."
			},
			{
				property: "og:title",
				content: "Business Plan — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Fair binary plan: direct + pair + rank income."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/plan"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/plan"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./login-BimHhIM3.mjs");
var Route$8 = createFileRoute("/login")({
	head: () => ({
		meta: [
			{ title: "Login — Righvedh Sanjivni" },
			{
				name: "description",
				content: "Login to your Righvedh Sanjivni member or admin account."
			},
			{
				property: "og:title",
				content: "Login — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Secure member and admin login for Righvedh Sanjivni."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/login"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/login"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./forgot-password-DgOIdyoY.mjs");
var Route$7 = createFileRoute("/forgot-password")({
	head: () => ({
		meta: [
			{ title: "Reset Password — Righvedh Sanjivni" },
			{
				name: "description",
				content: "Reset your Righvedh Sanjivni member account password using your registered mobile number, email and date of birth."
			},
			{
				property: "og:title",
				content: "Reset Password — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Recover access to your Righvedh Sanjivni member account."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary"
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/forgot-password"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/forgot-password"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./disclaimer-BZvkkfbp.mjs");
var Route$6 = createFileRoute("/disclaimer")({
	head: () => ({
		meta: [
			{ title: "Income Disclaimer — Righvedh Sanjivni" },
			{
				name: "description",
				content: "Income earned through Righvedh Sanjivni depends entirely on individual effort. No income is guaranteed."
			},
			{
				property: "og:title",
				content: "Income Disclaimer — Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "No income is guaranteed."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/disclaimer"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/disclaimer"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./contact-DJ5VU5k2.mjs");
var Route$5 = createFileRoute("/contact")({
	head: () => ({
		meta: [
			{ title: "Contact — Righvedh Sanjivni" },
			{
				name: "description",
				content: "Get in touch with Righvedh Sanjivni — Scheme No. 136-A, Indore, MP. Email righvedhsanjivni@gmail.com. 24 hour support."
			},
			{
				property: "og:title",
				content: "Contact Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "24 hour Ayurveda & business support."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/contact"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/contact"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./about-CqgNuu-7.mjs");
var Route$4 = createFileRoute("/about")({
	head: () => ({
		meta: [
			{ title: "About Us — Righvedh Sanjivni" },
			{
				name: "description",
				content: "The story of Righvedh Sanjivni — where the tradition of Ayurveda meets a fair business opportunity."
			},
			{
				property: "og:title",
				content: "About Righvedh Sanjivni"
			},
			{
				property: "og:description",
				content: "Ayurvedic tradition meets a modern income opportunity."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/about"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/about"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./route-Di7iQBCH.mjs");
var Route$3 = createFileRoute("/_authenticated")({
	ssr: false,
	beforeLoad: async () => {
		const { data, error } = await supabase.auth.getUser();
		if (error || !data.user) throw redirect({ to: "/login" });
		return { user: data.user };
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./routes-Bgp40sKA.mjs");
var Route$2 = createFileRoute("/")({
	head: () => ({
		meta: [
			{ title: "Righvedh Sanjivni — Pure Ayurveda & Binary Business Opportunity" },
			{
				name: "description",
				content: "Righvedh Sanjivni offers 100% pure Ayurvedic wellness products and a transparent binary MLM plan. Earn direct sale commission and pair matching bonus."
			},
			{
				property: "og:title",
				content: "Righvedh Sanjivni — Ayurveda & Income Opportunity"
			},
			{
				property: "og:description",
				content: "Pure Ayurveda products with a fair binary income plan."
			},
			{
				property: "og:url",
				content: "https://righvedhsanjivni.in/"
			}
		],
		links: [{
			rel: "canonical",
			href: "https://righvedhsanjivni.in/"
		}]
	}),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./dashboard-CU-ExE23.mjs");
var Route$1 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [
		{ title: "Member Dashboard — Righvedh Sanjivni" },
		{
			name: "description",
			content: "Manage Righvedh Sanjivni orders, team, income, withdrawals, and profile."
		},
		{
			property: "og:title",
			content: "Member Dashboard — Righvedh Sanjivni"
		},
		{
			property: "og:description",
			content: "Righvedh Sanjivni member account dashboard."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex,nofollow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./admin-Boc4ckB7.mjs");
var Route = createFileRoute("/_authenticated/admin")({
	head: () => ({ meta: [
		{ title: "Admin Panel — Righvedh Sanjivni" },
		{
			name: "description",
			content: "Manage Righvedh Sanjivni members, products, orders, withdrawals, and payment settings."
		},
		{
			property: "og:title",
			content: "Admin Panel — Righvedh Sanjivni"
		},
		{
			property: "og:description",
			content: "Secure Righvedh Sanjivni administration panel."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary"
		},
		{
			name: "robots",
			content: "noindex,nofollow"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var TermsRoute = Route$15.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$16
});
var SitemapDotxmlRoute = Route$14.update({
	id: "/sitemap.xml",
	path: "/sitemap.xml",
	getParentRoute: () => Route$16
});
var RegisterRoute = Route$13.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$16
});
var RefundRoute = Route$12.update({
	id: "/refund",
	path: "/refund",
	getParentRoute: () => Route$16
});
var ProductsRoute = Route$11.update({
	id: "/products",
	path: "/products",
	getParentRoute: () => Route$16
});
var PrivacyRoute = Route$10.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$16
});
var PlanRoute = Route$9.update({
	id: "/plan",
	path: "/plan",
	getParentRoute: () => Route$16
});
var LoginRoute = Route$8.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$16
});
var ForgotPasswordRoute = Route$7.update({
	id: "/forgot-password",
	path: "/forgot-password",
	getParentRoute: () => Route$16
});
var DisclaimerRoute = Route$6.update({
	id: "/disclaimer",
	path: "/disclaimer",
	getParentRoute: () => Route$16
});
var ContactRoute = Route$5.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$16
});
var AboutRoute = Route$4.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$16
});
var AuthenticatedRouteRoute = Route$3.update({
	id: "/_authenticated",
	getParentRoute: () => Route$16
});
var IndexRoute = Route$2.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$16
});
var AuthenticatedDashboardRoute = Route$1.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRouteRoute
});
var AuthenticatedRouteRouteChildren = {
	AuthenticatedAdminRoute: Route.update({
		id: "/admin",
		path: "/admin",
		getParentRoute: () => AuthenticatedRouteRoute
	}),
	AuthenticatedDashboardRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRouteRoute: AuthenticatedRouteRoute._addFileChildren(AuthenticatedRouteRouteChildren),
	AboutRoute,
	ContactRoute,
	DisclaimerRoute,
	ForgotPasswordRoute,
	LoginRoute,
	PlanRoute,
	PrivacyRoute,
	ProductsRoute,
	RefundRoute,
	RegisterRoute,
	SitemapDotxmlRoute,
	TermsRoute
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient() },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
