import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/disclaimer-BZvkkfbp.js
var import_jsx_runtime = require_jsx_runtime();
function Disclaimer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-gradient-hero text-primary-foreground py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-5xl",
					children: "Income Disclaimer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary-foreground/80",
					children: "Effort based. No guaranteed income."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-6 py-16 space-y-8 text-[15px] leading-relaxed text-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "1. No Guaranteed Income",
				children: "Righvedh Sanjivni is a direct-selling / MLM opportunity. Any income figure or example shown on this website, in printed material, or during training sessions is for illustration only. Actual income depends entirely on the member's own selling effort, team building activity and market conditions."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "2. Not an Investment Scheme",
				children: [
					"Righvedh Sanjivni is ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "not" }),
					" a money-circulation, chit-fund, deposit-taking or investment scheme. Income is earned only through genuine product sales and team building. No income is generated merely by signing up or by paying money to the company."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "3. Individual Results Vary",
				children: "Some members earn substantially, many earn modest amounts, and some may earn nothing at all. Past results of any individual member are not a guarantee of future performance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "4. Tax Responsibility",
				children: "Members are solely responsible for reporting their MLM income to tax authorities and paying all applicable taxes. Righvedh Sanjivni will deduct 5% TDS on withdrawals as required by law and issue relevant statements."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "5. No Employment",
				children: "Membership does not create an employer-employee relationship. Members act as independent distributors."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "6. Product Claims",
				children: "Ayurvedic products are traditional wellness supplements, not a substitute for prescribed medical treatment. Consult a qualified physician before use if you are pregnant, on medication, or have a medical condition."
			})
		]
	})] });
}
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl text-primary mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children
	})] });
}
//#endregion
export { Disclaimer as component };
