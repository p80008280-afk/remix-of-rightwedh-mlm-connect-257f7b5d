import { i as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { F as Eye, I as EyeOff } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/password-input-DZQVOfRZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PasswordInput({ value, onChange, required = true, placeholder, autoComplete = "current-password", className = "" }) {
	const [show, setShow] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: show ? "text" : "password",
			required,
			placeholder,
			autoComplete,
			value,
			onChange: (e) => onChange(e.target.value),
			className: `mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 pr-12 text-sm focus:ring-2 focus:ring-ring ${className}`
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => setShow((s) => !s),
			"aria-label": show ? "Hide password" : "Show password",
			className: "absolute right-3 top-1/2 -translate-y-1/2 mt-0.5 text-muted-foreground hover:text-primary",
			children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "h-4 w-4" })
		})]
	});
}
//#endregion
export { PasswordInput as t };
