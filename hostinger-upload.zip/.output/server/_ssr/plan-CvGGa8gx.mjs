import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { G as ArrowRight, R as DollarSign, b as Plus, c as TrendingUp, r as Users, s as Trophy } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plan-CvGGa8gx.js
var import_jsx_runtime = require_jsx_runtime();
function Plan() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-hero text-primary-foreground py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Business Plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-serif text-5xl md:text-6xl",
						children: "Righvedh Binary Plan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-primary-foreground/80 max-w-2xl mx-auto",
						children: "A simple binary structure — two legs (Left & Right). Earn a direct commission on every sale and a pair bonus on every match. Grow your team at your own pace."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 grid grid-cols-3 gap-4 max-w-xl mx-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanStat, {
								label: "Product MRP",
								value: "₹ 3,250"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanStat, {
								label: "Direct Commission",
								value: "₹ 900",
								gold: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanStat, {
								label: "Pair Match",
								value: "₹ 300",
								gold: true
							})
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-6 py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "How It Works"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl text-primary",
					children: "A simple example — A, B and C"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-14 grid lg:grid-cols-2 gap-12 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-3xl border border-border bg-card p-10 shadow-elegant",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeDemo, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "space-y-5",
					children: [
						{
							s: "Step 1",
							t: "You are A",
							d: "You register using your sponsor's referral link."
						},
						{
							s: "Step 2",
							t: "Add B and C",
							d: "You place B on your left and C on your right — both are your directs."
						},
						{
							s: "Step 3",
							t: "Direct Commission",
							d: "Whenever B makes a purchase, A earns ₹900. Whenever C makes a purchase, A earns ₹900."
						},
						{
							s: "Step 4",
							t: "Pair Bonus",
							d: "When the BV of B and C matches, A earns a pair matching bonus of ₹300."
						},
						{
							s: "Step 5",
							t: "The chain grows",
							d: "B and C build their own teams below them — their pairs count for their upline, and the chain grows to infinite depth."
						},
						{
							s: "Step 6",
							t: "The \"+\" option",
							d: "Every member sees a + button on their tree — invite a new member into any empty left/right position at any time."
						}
					].map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "relative rounded-2xl border border-border bg-card p-6 pl-16 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute left-4 top-6 h-10 w-10 rounded-full bg-gradient-gold flex items-center justify-center text-gold-foreground font-serif font-bold text-lg shadow-gold",
								children: i + 1
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-widest text-gold font-semibold",
								children: s.s
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif text-xl text-primary mt-1",
								children: s.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 text-sm text-muted-foreground leading-relaxed",
								children: s.d
							})
						]
					}, i))
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-leaf py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Income Streams"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl text-primary",
						children: "Four ways to earn"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid md:grid-cols-2 lg:grid-cols-4 gap-6",
					children: [
						{
							icon: DollarSign,
							t: "Direct Sale Income",
							d: "Earn ₹900 fixed commission for every product purchase made by your direct member."
						},
						{
							icon: Users,
							t: "Pair Matching Bonus",
							d: "Earn ₹300 every time your Left and Right legs form a matched pair in BV."
						},
						{
							icon: TrendingUp,
							t: "Level Income",
							d: "A small % commission from the generations below you — deep-team rewards."
						},
						{
							icon: Trophy,
							t: "Rank & Reward Bonus",
							d: "Silver, Gold and Diamond ranks unlock travel, gifts and cash rewards."
						}
					].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-card p-8 shadow-soft border border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-14 w-14 rounded-xl bg-primary flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { className: "h-7 w-7 text-primary-foreground" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-5 font-serif text-xl text-primary",
								children: f.t
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 text-sm text-muted-foreground leading-relaxed",
								children: f.d
							})
						]
					}, f.t))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-6 py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Plan Terms & Rules"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl text-primary",
					children: "Fair, transparent, capped"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3",
				children: [
					{
						t: "Joining Fee",
						d: "₹3,250 — one time via Ayurvedic product purchase."
					},
					{
						t: "Direct Sale Commission",
						d: "₹900 fixed on every direct member's purchase."
					},
					{
						t: "Pair Matching Bonus",
						d: "₹300 per matched pair (1 Left + 1 Right)."
					},
					{
						t: "Daily Capping",
						d: "Maximum 20 pairs per day, per member. Extra pairs carry no bonus."
					},
					{
						t: "Monthly Repurchase",
						d: "1 product repurchase per month is compulsory to keep the ID active and eligible for pair income."
					},
					{
						t: "Withdrawal",
						d: "Minimum ₹300 • 5% TDS deducted • 0 admin charge • paid within 7 days of admin approval."
					},
					{
						t: "Refund / Return",
						d: "15 days from purchase — only if the pair-matching income has not yet been distributed on your order."
					},
					{
						t: "Product Exchange",
						d: "Product exchange is allowed within the same 15-day window."
					},
					{
						t: "Rewards",
						d: "Level Income, Rank Rewards and Leadership Bonuses will be updated in future releases."
					}
				].map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-card border border-border p-6 shadow-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-widest text-gold font-semibold",
						children: r.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 text-sm text-primary leading-relaxed",
						children: r.d
					})]
				}, r.t))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-4xl px-6 py-20 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-4xl text-primary",
					children: "Ready to build your team?"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: "Ask your sponsor for their referral link to get started."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/register",
					className: "mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-8 py-4 text-base font-semibold text-gold-foreground shadow-gold hover:opacity-90",
					children: ["Join Now ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-4 w-4" })]
				})
			]
		})
	] });
}
function PlanStat({ label, value, gold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl px-3 py-4 border ${gold ? "bg-gradient-gold border-gold/40 text-gold-foreground shadow-gold" : "bg-primary-foreground/10 border-primary-foreground/20"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-[10px] uppercase tracking-widest font-semibold ${gold ? "text-gold-foreground/80" : "text-primary-foreground/70"}`,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1 font-bold text-xl",
			children: value
		})]
	});
}
function Node({ label, tone = "primary", plus }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `w-16 h-16 rounded-full flex items-center justify-center font-serif text-xl font-bold ${{
				primary: "bg-primary text-primary-foreground",
				gold: "bg-gradient-gold text-gold-foreground shadow-gold",
				muted: "bg-muted text-muted-foreground border border-dashed border-border"
			}[tone]}`,
			children: label
		}), plus && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute -bottom-2 -right-2 h-6 w-6 rounded-full bg-gold flex items-center justify-center shadow-gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 text-gold-foreground" })
		})]
	});
}
function TreeDemo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
				label: "A",
				tone: "gold",
				plus: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-64 flex justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-6 bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px h-6 bg-border" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-64 flex justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
					label: "B",
					plus: true
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
					label: "C",
					plus: true
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md grid grid-cols-4 gap-2 mt-4 justify-items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
						label: "D",
						tone: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
						label: "+",
						tone: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
						label: "F",
						tone: "muted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Node, {
						label: "+",
						tone: "muted"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 text-xs text-muted-foreground text-center max-w-sm",
				children: [
					"Tap the ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "+" }),
					" on any circle to invite a new member into that position."
				]
			})
		]
	});
}
//#endregion
export { Plan as component };
