import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-BkEyjURS.js
var import_jsx_runtime = require_jsx_runtime();
function Terms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-gradient-hero text-primary-foreground py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-5xl",
					children: "Terms & Conditions"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary-foreground/80",
					children: "Please read carefully before joining or purchasing."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-6 py-16 space-y-8 text-[15px] leading-relaxed text-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "1. Acceptance",
				children: "By registering as a member, purchasing a product or using this website, you agree to these Terms & Conditions and to our Privacy Policy, Refund Policy and Income Disclaimer."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "2. Membership",
				children: "Membership requires a one-time joining product purchase of ₹3,250. Every member is placed in a binary tree structure (Left / Right leg) under the sponsor who invited them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "3. Commissions & Income",
				children: "Members earn a ₹900 direct commission on every direct member's product purchase and a ₹300 pair-matching bonus for each matched pair (subject to a daily cap of 20 pairs per member). Level income, rank rewards and leadership bonuses may be introduced in future updates."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "4. Monthly Repurchase",
				children: "To remain active and eligible for pair matching income, every member must purchase at least one product per month."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "5. Withdrawals",
				children: "Minimum withdrawal is ₹300. A 5% TDS is deducted from every withdrawal. Approved withdrawals are paid to the member's registered UPI within 7 days."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "6. Product Return & Exchange",
				children: "Products may be returned or exchanged within 15 days of purchase — provided the pair-matching income for that order has not yet been distributed. Once income is distributed the order is final."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "7. Prohibited Conduct",
				children: "Fake registrations, fraudulent payments, misleading claims about income, and misuse of the referral system may result in account suspension and forfeiture of pending income."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "8. Modifications",
				children: "Righvedh Sanjivni reserves the right to update these terms, product prices, commission structures and rewards at any time. Continued use of the platform after changes indicates acceptance."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "9. Contact",
				children: [
					"For any query please write to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-primary underline",
						href: "mailto:righvedhsanjivni@gmail.com",
						children: "righvedhsanjivni@gmail.com"
					}),
					" or call +91 86199 90944."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground pt-4 border-t border-border",
				children: "A downloadable PDF version of these terms will be provided by the company on request."
			})
		]
	})] });
}
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl text-primary mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children
	})] });
}
//#endregion
export { Terms as component };
