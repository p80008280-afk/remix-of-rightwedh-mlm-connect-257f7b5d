import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DCIbG3ZB.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as IndianRupee, D as LogOut, H as CircleX, L as Download, S as Package, U as CircleCheck, _ as Settings, b as Plus, d as Table2, k as LayoutDashboard, m as ShoppingCart, n as Wallet, r as Users, y as RefreshCw, z as Database } from "../_libs/lucide-react.mjs";
import { d as reviewWithdrawal, f as updateMemberStatus, h as useServerFn, m as upsertProduct, n as adminSetAccountState, p as updatePlanSettings, r as adminSetMemberPassword, t as adminAddMember, u as reviewOrder } from "./mlm.functions-wpgd-J5F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-Boc4ckB7.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABLES = [
	{
		name: "profiles",
		label: "profiles",
		description: "Every member: name, User ID, mobile, email, DOB, photo, address, sponsor & tree position, KYC, account status, login password.",
		order: "created_at",
		desc: true
	},
	{
		name: "user_roles",
		label: "user_roles",
		description: "Which account is an admin and which is a member."
	},
	{
		name: "products",
		label: "products",
		description: "Product catalogue: name, category, image, MRP, direct commission, pair bonus, stock, status.",
		order: "created_at"
	},
	{
		name: "orders",
		label: "orders",
		description: "Every purchase: member, product, quantity, amount, payment reference & screenshot, full delivery address, approval status.",
		order: "created_at",
		desc: true
	},
	{
		name: "commissions",
		label: "commissions",
		description: "Every income entry credited: direct, pair and reward payouts with source member and order.",
		order: "created_at",
		desc: true
	},
	{
		name: "wallets",
		label: "wallets",
		description: "Per-member balance, total earned, direct income and pair income."
	},
	{
		name: "tree_stats",
		label: "tree_stats",
		description: "Binary tree counters: left count, right count, matched pairs, pairs used today."
	},
	{
		name: "reward_levels",
		label: "reward_levels",
		description: "The 18 reward levels: pairs required and reward amount.",
		order: "level"
	},
	{
		name: "user_rewards",
		label: "user_rewards",
		description: "Rewards unlocked by each member with claim deadline, claimed and expired state.",
		order: "created_at",
		desc: true
	},
	{
		name: "withdrawals",
		label: "withdrawals",
		description: "Withdrawal requests: amount, TDS, net payable, UPI ID, approval status.",
		order: "created_at",
		desc: true
	},
	{
		name: "plan_settings",
		label: "plan_settings",
		description: "Business settings: UPI ID, QR image, minimum withdrawal, TDS %, daily pair cap, refund days."
	}
];
function typeOf(value) {
	if (value === null || value === void 0) return "empty";
	if (typeof value === "boolean") return "true / false";
	if (typeof value === "number") return "number";
	if (typeof value === "string") {
		if (/^\d{4}-\d{2}-\d{2}T/.test(value)) return "date & time";
		if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return "date";
		if (/^[0-9a-f]{8}-[0-9a-f]{4}-/.test(value)) return "unique id";
		return "text";
	}
	return "data";
}
function DatabaseConsole() {
	const [active, setActive] = (0, import_react.useState)("profiles");
	const [data, setData] = (0, import_react.useState)({});
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [q, setQ] = (0, import_react.useState)("");
	const [view, setView] = (0, import_react.useState)("rows");
	async function load() {
		setLoading(true);
		const results = await Promise.all(TABLES.map(async (t) => {
			let query = supabase.from(t.name).select("*");
			if (t.order) query = query.order(t.order, { ascending: !t.desc });
			const { data: rows } = await query.limit(1e3);
			return [t.name, rows || []];
		}));
		setData(Object.fromEntries(results));
		setLoading(false);
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const def = TABLES.find((t) => t.name === active);
	const rows = data[active] || [];
	const cols = (0, import_react.useMemo)(() => rows.length ? Object.keys(rows[0]) : [], [rows]);
	const filtered = (0, import_react.useMemo)(() => q.trim() ? rows.filter((r) => JSON.stringify(r).toLowerCase().includes(q.trim().toLowerCase())) : rows, [rows, q]);
	function exportCsv() {
		const esc = (v) => `"${String(v ?? "").replace(/"/g, "\"\"")}"`;
		const csv = [cols.join(","), ...filtered.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
		const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = `${active}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	}
	const totalRows = TABLES.reduce((s, t) => s + (data[t.name]?.length || 0), 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card shadow-elegant overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3 border-b border-border px-5 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-serif text-xl text-primary",
				children: "Database"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: [
					TABLES.length,
					" tables · ",
					totalRows,
					" rows stored · live data"
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: load,
					className: "inline-flex items-center gap-1.5 rounded-full border border-input px-4 py-1.5 text-xs font-semibold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: `h-3.5 w-3.5 ${loading ? "animate-spin" : ""}` }), " Refresh"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: exportCsv,
					className: "inline-flex items-center gap-1.5 rounded-full bg-gradient-gold px-4 py-1.5 text-xs font-semibold text-gold-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " Export CSV"]
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col lg:flex-row",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "lg:w-64 shrink-0 border-b lg:border-b-0 lg:border-r border-border max-h-[240px] lg:max-h-none overflow-y-auto",
				children: TABLES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => {
						setActive(t.name);
						setQ("");
					},
					className: `w-full flex items-center justify-between gap-2 px-4 py-2.5 text-left text-xs border-b border-border/50 ${active === t.name ? "bg-primary text-primary-foreground font-semibold" : "hover:bg-muted/50"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-2 truncate",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table2, { className: "h-3.5 w-3.5 shrink-0" }),
							" ",
							t.label
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `shrink-0 rounded-full px-2 py-0.5 text-[10px] ${active === t.name ? "bg-primary-foreground/20" : "bg-muted"}`,
						children: data[t.name]?.length ?? "…"
					})]
				}, t.name))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex-1 min-w-0 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground mb-3",
						children: def.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2 mb-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "inline-flex rounded-full border border-input p-0.5 text-xs",
								children: ["rows", "structure"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setView(v),
									className: `rounded-full px-3 py-1 capitalize ${view === v ? "bg-primary text-primary-foreground font-semibold" : ""}`,
									children: v === "rows" ? "Data" : "Columns"
								}, v))
							}),
							view === "rows" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: `Search in ${def.label}...`,
								className: "rounded-full border border-input bg-background px-4 py-1.5 text-xs flex-1 min-w-[180px]"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-[11px] text-muted-foreground",
								children: [filtered.length, " row(s)"]
							})
						]
					}),
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted-foreground",
						children: "Loading data…"
					}) : view === "structure" ? cols.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted-foreground",
						children: "No rows yet, so columns cannot be listed."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-[10px] uppercase tracking-wide text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 px-2",
									children: "Column"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 px-2",
									children: "Kind of value"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 px-2",
									children: "Example"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: cols.map((c) => {
							const sample = rows.find((r) => r[c] !== null && r[c] !== void 0)?.[c];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-2 font-medium",
										children: c
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-2 text-muted-foreground",
										children: typeOf(sample)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-2 max-w-[320px] truncate text-muted-foreground",
										children: String(sample ?? "—")
									})
								]
							}, c);
						}) })]
					}) : filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted-foreground",
						children: "No rows stored in this table yet."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
								className: "border-b border-border",
								children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "py-2 px-2 whitespace-nowrap uppercase tracking-wide text-[10px] text-muted-foreground",
									children: c
								}, c))
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
								className: "border-b border-border/50 hover:bg-muted/40 align-top",
								children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 px-2 max-w-[240px] truncate",
									title: String(r[c] ?? ""),
									children: r[c] === null || r[c] === void 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "null"
									}) : String(r[c])
								}, c))
							}, r.id || i)) })]
						})
					})
				]
			})]
		})]
	});
}
var logoAsset = { url: "/logo.png" };
var qrAsset = { url: "/phonepe-qr.png" };
function Admin() {
	const nav = useNavigate();
	const [tab, setTab] = (0, import_react.useState)("dash");
	const [openOrder, setOpenOrder] = (0, import_react.useState)(null);
	const [isAdmin, setIsAdmin] = (0, import_react.useState)(null);
	const [members, setMembers] = (0, import_react.useState)([]);
	const [products, setProducts] = (0, import_react.useState)([]);
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [withdrawals, setWithdrawals] = (0, import_react.useState)([]);
	const [settings, setSettings] = (0, import_react.useState)(null);
	const [ask, setAsk] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)("");
	const rvOrder = useServerFn(reviewOrder);
	const rvWd = useServerFn(reviewWithdrawal);
	const upProd = useServerFn(upsertProduct);
	const upMem = useServerFn(updateMemberStatus);
	const upSettings = useServerFn(updatePlanSettings);
	const addMember = useServerFn(adminAddMember);
	const setState = useServerFn(adminSetAccountState);
	const setPassword = useServerFn(adminSetMemberPassword);
	async function loadAll() {
		const [m, p, o, w, ps] = await Promise.all([
			supabase.from("profiles").select("*").order("created_at", { ascending: false }),
			supabase.from("products").select("*").order("created_at"),
			supabase.from("orders").select("*").order("created_at", { ascending: false }),
			supabase.from("withdrawals").select("*").order("created_at", { ascending: false }),
			supabase.from("plan_settings").select("*").eq("id", 1).maybeSingle()
		]);
		setMembers(m.data || []);
		setProducts(p.data || []);
		setOrders(o.data || []);
		setWithdrawals(w.data || []);
		if (ps.data) setSettings(ps.data);
	}
	(0, import_react.useEffect)(() => {
		(async () => {
			const { data: userRes } = await supabase.auth.getUser();
			if (!userRes.user) {
				nav({ to: "/login" });
				return;
			}
			const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userRes.user.id);
			const admin = roles?.some((r) => r.role === "admin") || false;
			setIsAdmin(admin);
			if (admin) loadAll();
		})();
	}, []);
	async function logout() {
		await supabase.auth.signOut();
		nav({ to: "/" });
	}
	if (isAdmin === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen flex items-center justify-center",
		children: "Checking access..."
	});
	if (!isAdmin) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex flex-col items-center justify-center gap-3 text-center px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-12 w-12 text-destructive" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-serif text-2xl text-primary",
				children: "Access Denied"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "You must be an admin to view this page."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/dashboard",
				className: "text-primary underline",
				children: "Go to your dashboard"
			})
		]
	});
	const pendingOrders = orders.filter((o) => o.status === "pending");
	const pendingWd = withdrawals.filter((w) => w.status === "pending");
	const totalSales = orders.filter((o) => o.status === "approved").reduce((s, o) => s + Number(o.amount), 0);
	const memberMap = new Map(members.map((m) => [m.id, m]));
	const prodMap = new Map(products.map((p) => [p.id, p]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex bg-gradient-leaf",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "w-64 bg-primary text-primary-foreground min-h-screen sticky top-0 hidden md:flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-6 py-5 border-b border-primary-foreground/10 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-10 w-10 rounded-full overflow-hidden bg-white ring-2 ring-gold/50",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoAsset.url,
								alt: "Logo",
								className: "h-full w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif font-bold",
								children: "Righvedh"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-widest text-gold",
								children: "Admin"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex-1 p-4 space-y-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "dash",
								onClick: () => setTab("dash"),
								icon: LayoutDashboard,
								label: "Dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "members",
								onClick: () => setTab("members"),
								icon: Users,
								label: "Members"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "products",
								onClick: () => setTab("products"),
								icon: Package,
								label: "Products"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "orders",
								onClick: () => setTab("orders"),
								icon: ShoppingCart,
								label: `Orders${pendingOrders.length ? ` (${pendingOrders.length})` : ""}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "withdrawals",
								onClick: () => setTab("withdrawals"),
								icon: Wallet,
								label: `Withdrawals${pendingWd.length ? ` (${pendingWd.length})` : ""}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "settings",
								onClick: () => setTab("settings"),
								icon: Settings,
								label: "Payment Settings"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "records",
								onClick: () => setTab("records"),
								icon: Download,
								label: "Records / Data"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBtn, {
								active: tab === "database",
								onClick: () => setTab("database"),
								icon: Database,
								label: "Database"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: logout,
						className: "m-4 flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-foreground/10 hover:bg-primary-foreground/20 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Sign out"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 p-6 md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden flex gap-1 mb-4 overflow-x-auto text-xs",
						children: [
							"dash",
							"members",
							"products",
							"orders",
							"withdrawals",
							"settings",
							"records",
							"database"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setTab(t),
							className: `px-3 py-2 rounded-lg whitespace-nowrap ${tab === t ? "bg-primary text-primary-foreground" : "bg-card"}`,
							children: t
						}, t))
					}),
					tab === "dash" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-serif text-3xl text-primary",
								children: "Admin Dashboard"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Users,
										label: "Total Members",
										value: String(members.length)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: CircleCheck,
										label: "Active Members",
										value: String(members.filter((m) => m.is_active).length)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: ShoppingCart,
										label: "Pending Orders",
										value: String(pendingOrders.length),
										accent: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: IndianRupee,
										label: "Approved Sales",
										value: `₹${totalSales}`,
										accent: true
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: Wallet,
									label: "Pending Withdrawals",
									value: String(pendingWd.length)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: Package,
									label: "Active Products",
									value: String(products.filter((p) => p.status === "active").length)
								})]
							}),
							settings && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-card border border-border p-6 shadow-soft grid gap-4 md:grid-cols-[1fr_auto] items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-serif text-2xl text-primary",
									children: "Payment QR & UPI"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground mt-1",
									children: [
										"Current checkout UPI: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
											className: "text-primary",
											children: settings.upi_id
										}),
										" · ",
										settings.payment_account_name
									]
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setTab("settings"),
									className: "rounded-full bg-primary text-primary-foreground px-5 py-2.5 text-sm font-semibold",
									children: "Edit Payment Settings"
								})]
							})
						]
					}),
					tab === "members" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MembersTab, {
						members,
						onReload: loadAll,
						onKyc: async (userId, kyc) => {
							await upMem({ data: {
								userId,
								kyc_status: kyc
							} });
							loadAll();
						},
						onState: async (userId, patch) => {
							await setState({ data: {
								userId,
								...patch
							} });
							loadAll();
						},
						onPassword: async (userId, newPassword) => {
							await setPassword({ data: {
								userId,
								newPassword
							} });
							loadAll();
						},
						onAdd: async (payload) => {
							const res = await addMember({ data: payload });
							await loadAll();
							return res;
						}
					}),
					tab === "products" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductsTab, {
						products,
						onSave: async (p) => {
							await upProd({ data: p });
							loadAll();
						}
					}),
					tab === "orders" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
						title: `Orders (${orders.length}) — ${pendingOrders.length} pending review`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground mb-4",
								children: [
									"Verify each pending order by viewing the payment screenshot. If the amount and receiver UPI (",
									settings?.upi_id || "current admin UPI",
									") match, click ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Approve" }),
									" — commissions are paid automatically and the member becomes active. Otherwise click ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "Reject" }),
									"."
								]
							}),
							orders.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground py-6 text-center",
								children: "No orders yet. As soon as a member checks out from Shop / Cart, the order appears here with their delivery address and payment screenshot."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, {
								cols: [
									"Date",
									"Member",
									"Product",
									"Delivery Address",
									"Amount",
									"UPI Ref",
									"Proof",
									"Status",
									"Action"
								],
								children: orders.map((o) => {
									const mem = memberMap.get(o.user_id);
									const pr = prodMap.get(o.product_id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "border-b border-border/50 align-top hover:bg-muted/40 cursor-pointer",
										onClick: () => setOpenOrder(o),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2 px-2 text-xs whitespace-nowrap",
												children: new Date(o.created_at).toLocaleString()
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "py-2 px-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-medium",
														children: mem?.full_name || o.user_id.slice(0, 8)
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs text-muted-foreground",
														children: mem?.email
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-xs text-muted-foreground",
														children: mem?.phone
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "py-2 px-2",
												children: [pr?.name || "—", o.quantity > 1 ? ` × ${o.quantity}` : ""]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "py-2 px-2 text-xs max-w-[220px]",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "font-medium",
														children: o.ship_name || "—"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-muted-foreground",
														children: o.ship_phone
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-muted-foreground truncate",
														children: [
															o.ship_address,
															o.ship_city,
															o.ship_state,
															o.ship_pincode
														].filter(Boolean).join(", ") || "—"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-primary underline",
														children: "View full details"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
												className: "py-2 px-2 font-semibold",
												children: ["₹", o.amount]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2 px-2 font-mono text-xs",
												children: o.upi_reference || "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2 px-2",
												onClick: (e) => e.stopPropagation(),
												children: o.payment_screenshot_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: o.payment_screenshot_url,
													target: "_blank",
													rel: "noreferrer",
													className: "inline-block",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
														src: o.payment_screenshot_url,
														alt: "proof",
														className: "h-16 w-16 object-cover rounded border border-border hover:ring-2 hover:ring-gold"
													})
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted-foreground",
													children: "No proof"
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2 px-2",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: o.status })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
												className: "py-2 px-2",
												onClick: (e) => e.stopPropagation(),
												children: o.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col gap-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => setAsk({
															title: "Approve this order?",
															message: `₹${o.amount} order for ${mem?.full_name || "member"} will be approved and commissions will be paid.`,
															confirmLabel: "Approve",
															onConfirm: async () => {
																await rvOrder({ data: {
																	orderId: o.id,
																	action: "approve"
																} });
																await loadAll();
																setNotice("Order approved.");
															}
														}),
														className: "rounded bg-green-600 text-white px-3 py-1 text-xs font-semibold",
														children: "✓ Approve"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
														onClick: () => setAsk({
															title: "Reject this order?",
															input: { label: "Reason for rejection" },
															confirmLabel: "Reject order",
															tone: "danger",
															onConfirm: async (note) => {
																await rvOrder({ data: {
																	orderId: o.id,
																	action: "reject",
																	note
																} });
																await loadAll();
																setNotice("Order rejected.");
															}
														}),
														className: "rounded bg-red-600 text-white px-3 py-1 text-xs font-semibold",
														children: "✗ Reject"
													})]
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted-foreground",
													children: o.admin_note || "—"
												})
											})
										]
									}, o.id);
								})
							})
						]
					}),
					tab === "withdrawals" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
						title: `Withdrawals (${withdrawals.length})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, {
							cols: [
								"Date",
								"Member",
								"Amount",
								"UPI",
								"Status",
								"Action"
							],
							children: withdrawals.map((w) => {
								const mem = memberMap.get(w.user_id);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-2 text-xs",
											children: new Date(w.created_at).toLocaleString()
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-2 px-2",
											children: [mem?.full_name || w.user_id.slice(0, 8), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xs text-muted-foreground",
												children: mem?.email
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-2 px-2 font-semibold",
											children: ["₹", w.amount]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-2 font-mono text-xs",
											children: w.upi_id
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: w.status })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-2",
											children: w.status === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setAsk({
														title: "Mark as paid?",
														message: `₹${w.amount} will be marked paid to ${w.upi_id}.`,
														confirmLabel: "Mark paid",
														onConfirm: async () => {
															await rvWd({ data: {
																withdrawalId: w.id,
																action: "approve"
															} });
															await loadAll();
															setNotice("Withdrawal marked paid.");
														}
													}),
													className: "rounded bg-green-600 text-white px-2 py-1 text-xs",
													children: "Paid"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													onClick: () => setAsk({
														title: "Reject this withdrawal?",
														input: { label: "Reason (optional)" },
														confirmLabel: "Reject",
														tone: "danger",
														onConfirm: async (note) => {
															await rvWd({ data: {
																withdrawalId: w.id,
																action: "reject",
																note
															} });
															await loadAll();
															setNotice("Withdrawal rejected.");
														}
													}),
													className: "rounded bg-red-600 text-white px-2 py-1 text-xs",
													children: "Reject"
												})]
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted-foreground",
												children: "—"
											})
										})
									]
								}, w.id);
							})
						})
					}),
					tab === "settings" && settings && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsTab, {
						settings,
						onSave: async (next) => {
							await upSettings({ data: next });
							await loadAll();
						}
					}),
					tab === "records" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordsTab, {
						members,
						products,
						orders,
						withdrawals
					}),
					tab === "database" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatabaseConsole, {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderDetailModal, {
				order: openOrder,
				memberName: openOrder ? memberMap.get(openOrder.user_id)?.full_name || "" : "",
				memberCode: openOrder ? memberMap.get(openOrder.user_id)?.member_code || "" : "",
				productName: openOrder ? prodMap.get(openOrder.product_id)?.name || "" : "",
				onClose: () => setOpenOrder(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AskDialog, {
				state: ask,
				onClose: () => setAsk(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				text: notice,
				onClose: () => setNotice("")
			})
		]
	});
}
function OrderDetailModal({ order, memberName, memberCode, productName, onClose }) {
	if (!order) return null;
	const Row = ({ label, value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-3 py-1.5 border-b border-border/50 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-40 shrink-0 text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex-1 font-medium break-words",
			children: value || "—"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 bg-black/60 flex items-start justify-center p-6 overflow-y-auto",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			className: "bg-card rounded-2xl p-8 max-w-2xl w-full shadow-elegant my-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-2xl text-primary",
					children: "Order Details"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground mt-1",
					children: ["Placed ", new Date(order.created_at).toLocaleString()]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-5 text-sm font-semibold text-primary uppercase tracking-wide",
					children: "Customer"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Member",
					value: `${memberName}${memberCode ? ` (${memberCode})` : ""}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Product",
					value: `${productName} × ${order.quantity}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Amount",
					value: `₹${order.amount}`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Status",
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: order.status })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-5 text-sm font-semibold text-primary uppercase tracking-wide",
					children: "Delivery Address"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Name",
					value: order.ship_name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Mobile",
					value: order.ship_phone
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "House / Street / Area",
					value: order.ship_address
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "City",
					value: order.ship_city
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "State",
					value: order.ship_state
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Pincode",
					value: order.ship_pincode
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
					className: "mt-5 text-sm font-semibold text-primary uppercase tracking-wide",
					children: "Payment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "UPI reference",
					value: order.upi_reference
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: "Admin note",
					value: order.admin_note
				}),
				order.payment_screenshot_url && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: order.payment_screenshot_url,
					target: "_blank",
					rel: "noreferrer",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: order.payment_screenshot_url,
						alt: "Payment proof",
						className: "mt-3 max-h-72 rounded-xl border border-border"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onClose,
					className: "mt-6 w-full rounded-full bg-gradient-gold py-2.5 text-sm font-semibold text-gold-foreground",
					children: "Close"
				})
			]
		})
	});
}
var RECORD_TABLES = [
	"members",
	"orders",
	"withdrawals",
	"products"
];
function RecordsTab({ members, products, orders, withdrawals }) {
	const [table, setTable] = (0, import_react.useState)("members");
	const [q, setQ] = (0, import_react.useState)("");
	const source = {
		members,
		orders,
		withdrawals,
		products
	};
	const rows = source[table];
	const cols = rows.length ? Object.keys(rows[0]) : [];
	const filtered = q.trim() ? rows.filter((r) => JSON.stringify(r).toLowerCase().includes(q.trim().toLowerCase())) : rows;
	function exportCsv() {
		const esc = (v) => `"${String(v ?? "").replace(/"/g, "\"\"")}"`;
		const csv = [cols.join(","), ...filtered.map((r) => cols.map((c) => esc(r[c])).join(","))].join("\n");
		const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
		const a = document.createElement("a");
		a.href = url;
		a.download = `righvedh-${table}-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`;
		a.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Records / Data",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground mb-4",
				children: "Complete stored data for every section. Use the search box to find any record, and download a spreadsheet (CSV) copy for your own records or accountant."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 mb-4",
				children: [
					RECORD_TABLES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setTable(t),
						className: `rounded-full px-4 py-1.5 text-xs font-semibold capitalize ${table === t ? "bg-primary text-primary-foreground" : "border border-input"}`,
						children: [
							t,
							" (",
							source[t].length,
							")"
						]
					}, t)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search records...",
						className: "rounded-full border border-input bg-background px-4 py-1.5 text-xs flex-1 min-w-[180px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: exportCsv,
						className: "inline-flex items-center gap-1.5 rounded-full bg-gradient-gold px-4 py-1.5 text-xs font-semibold text-gold-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " Download CSV"]
					})
				]
			}),
			filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground py-6 text-center",
				children: "No records in this section yet."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full text-left text-xs",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "border-b border-border",
						children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 px-2 whitespace-nowrap uppercase tracking-wide text-[10px] text-muted-foreground",
							children: c.replace(/_/g, " ")
						}, c))
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: filtered.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
						className: "border-b border-border/50 hover:bg-muted/40",
						children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 px-2 max-w-[220px] truncate",
							title: String(r[c] ?? ""),
							children: String(r[c] ?? "—")
						}, c))
					}, r.id || i)) })]
				})
			})
		]
	});
}
function SideBtn({ active, onClick, icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: `w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm ${active ? "bg-gold text-gold-foreground font-semibold" : "hover:bg-primary-foreground/10"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
			" ",
			label
		]
	});
}
function Stat({ icon: Icon, label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-2xl border p-5 shadow-soft ${accent ? "bg-gradient-gold text-gold-foreground border-gold/40" : "bg-card border-border"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs uppercase tracking-wider opacity-80",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
				" ",
				label
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 font-serif text-2xl font-bold",
			children: value
		})]
	});
}
function Card({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-card border border-border p-6 shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-primary mb-4",
			children: title
		}), children]
	});
}
function TableWrap({ cols, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "text-left text-xs uppercase text-muted-foreground border-b border-border",
				children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 px-2",
					children: c
				}, c))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children })]
		})
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `px-2 py-0.5 rounded-full text-xs font-semibold ${{
			pending: "bg-amber-100 text-amber-700",
			approved: "bg-green-100 text-green-700",
			rejected: "bg-red-100 text-red-700"
		}[status] || "bg-muted"}`,
		children: status
	});
}
function ProductsTab({ products, onSave }) {
	const [editing, setEditing] = (0, import_react.useState)(null);
	const blank = {
		name: "",
		description: "",
		category: "General",
		image_url: "",
		mrp: 3250,
		direct_commission: 900,
		pair_bonus: 300,
		stock: 100,
		status: "active"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-serif text-2xl text-primary",
					children: [
						"Products (",
						products.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setEditing(blank),
					className: "rounded-full bg-gradient-gold text-gold-foreground px-4 py-2 text-sm font-semibold flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Product"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "All Products",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, {
					cols: [
						"Name",
						"Category",
						"MRP",
						"Direct",
						"Pair",
						"Stock",
						"Status",
						"Action"
					],
					children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 text-xs",
								children: p.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 px-2",
								children: ["₹", p.mrp]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 px-2",
								children: ["₹", p.direct_commission]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2 px-2",
								children: ["₹", p.pair_bonus]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: p.stock
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: p.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setEditing(p),
									className: "text-primary underline text-xs",
									children: "Edit"
								})
							})
						]
					}, p.id))
				})
			}),
			editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6",
				onClick: () => setEditing(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onClick: (e) => e.stopPropagation(),
					className: "bg-card rounded-2xl p-8 max-w-2xl w-full shadow-elegant max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-serif text-2xl text-primary mb-4",
						children: [editing.id ? "Edit" : "Add", " Product"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: async (e) => {
							e.preventDefault();
							await onSave(editing);
							setEditing(null);
						},
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: editing.name,
									onChange: (e) => setEditing({
										...editing,
										name: e.target.value
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Description",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: editing.description,
									onChange: (e) => setEditing({
										...editing,
										description: e.target.value
									}),
									rows: 2,
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Category",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: editing.category,
										onChange: (e) => setEditing({
											...editing,
											category: e.target.value
										}),
										className: "w-full rounded border px-3 py-2"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageUploadField, {
									label: "Product Image",
									value: editing.image_url || "",
									folder: "products",
									onChange: (url) => setEditing((prev) => ({
										...prev || {},
										image_url: url
									}))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "MRP ₹",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											required: true,
											value: editing.mrp,
											onChange: (e) => setEditing({
												...editing,
												mrp: Number(e.target.value)
											}),
											className: "w-full rounded border px-3 py-2"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Direct Comm ₹",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											required: true,
											value: editing.direct_commission,
											onChange: (e) => setEditing({
												...editing,
												direct_commission: Number(e.target.value)
											}),
											className: "w-full rounded border px-3 py-2"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
										label: "Pair Bonus ₹",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											required: true,
											value: editing.pair_bonus,
											onChange: (e) => setEditing({
												...editing,
												pair_bonus: Number(e.target.value)
											}),
											className: "w-full rounded border px-3 py-2"
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Stock",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										required: true,
										value: editing.stock,
										onChange: (e) => setEditing({
											...editing,
											stock: Number(e.target.value)
										}),
										className: "w-full rounded border px-3 py-2"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Status",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: editing.status,
										onChange: (e) => setEditing({
											...editing,
											status: e.target.value
										}),
										className: "w-full rounded border px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "active",
											children: "Active"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "inactive",
											children: "Inactive"
										})]
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setEditing(null),
									className: "flex-1 rounded-full border py-2.5",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "flex-1 rounded-full bg-gradient-gold text-gold-foreground py-2.5 font-semibold",
									children: "Save"
								})]
							})
						]
					})]
				})
			})
		]
	});
}
function SettingsTab({ settings, onSave }) {
	const [form, setForm] = (0, import_react.useState)(settings);
	const [file, setFile] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function save(e) {
		e.preventDefault();
		setBusy(true);
		setMsg("");
		try {
			let next = { ...form };
			if (file) {
				const ext = file.name.split(".").pop() || "png";
				const path = `qr/payment-qr-${Date.now()}.${ext}`;
				const upload = await supabase.storage.from("payment-assets").upload(path, file, { upsert: false });
				if (upload.error) throw upload.error;
				const signed = await supabase.storage.from("payment-assets").createSignedUrl(path, 3600 * 24 * 365);
				next = {
					...next,
					qr_image_path: path,
					qr_image_url: signed.data?.signedUrl || qrAsset.url
				};
			}
			await onSave(next);
			setForm(next);
			setFile(null);
			setMsg("Payment settings updated.");
		} catch (err) {
			setMsg("Error: " + (err.message || String(err)));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		title: "Payment & Plan Settings",
		children: [msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 rounded-lg bg-primary/10 text-primary text-sm p-3",
			children: msg
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: save,
			className: "grid gap-6 lg:grid-cols-[1fr_260px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-2 gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Checkout UPI ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: form.upi_id,
								onChange: (e) => setForm({
									...form,
									upi_id: e.target.value
								}),
								className: "w-full rounded border px-3 py-2"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
							label: "Payment Account Name",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: form.payment_account_name,
								onChange: (e) => setForm({
									...form,
									payment_account_name: e.target.value
								}),
								className: "w-full rounded border px-3 py-2"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: "Upload New QR Image",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							onChange: (e) => setFile(e.target.files?.[0] || null),
							className: "w-full rounded border px-3 py-2 text-sm"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Minimum Withdrawal ₹",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.min_withdrawal,
									onChange: (e) => setForm({
										...form,
										min_withdrawal: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "TDS %",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.tds_percent,
									onChange: (e) => setForm({
										...form,
										tds_percent: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Admin Charge ₹",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.admin_charge,
									onChange: (e) => setForm({
										...form,
										admin_charge: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Withdrawal Days",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.withdrawal_days,
									onChange: (e) => setForm({
										...form,
										withdrawal_days: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Daily Pair Capping",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.daily_pair_cap,
									onChange: (e) => setForm({
										...form,
										daily_pair_cap: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Refund Days",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									required: true,
									value: form.refund_days,
									onChange: (e) => setForm({
										...form,
										refund_days: Number(e.target.value)
									}),
									className: "w-full rounded border px-3 py-2"
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: form.monthly_repurchase,
							onChange: (e) => setForm({
								...form,
								monthly_repurchase: e.target.checked
							})
						}), "Monthly repurchase is compulsory"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						className: "rounded-full bg-gradient-gold text-gold-foreground px-8 py-3 text-sm font-semibold disabled:opacity-60",
						children: busy ? "Saving..." : "Save Settings"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-background p-4 text-center h-fit",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: file ? URL.createObjectURL(file) : form.qr_image_url,
						onError: (event) => {
							event.currentTarget.src = qrAsset.url;
						},
						alt: "Current checkout QR",
						className: "mx-auto w-52 rounded-xl bg-white p-2 border border-border"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 font-mono text-sm text-primary break-all",
						children: form.upi_id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground",
						children: form.payment_account_name
					})
				]
			})]
		})]
	});
}
function F({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs font-medium text-muted-foreground",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-1",
			children
		})]
	});
}
function ImageUploadField({ label, value, folder, onChange }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	async function pick(file) {
		if (!file) return;
		setBusy(true);
		setErr("");
		try {
			const ext = file.name.split(".").pop() || "png";
			const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
			const up = await supabase.storage.from("payment-assets").upload(path, file, { upsert: false });
			if (up.error) throw up.error;
			onChange((await supabase.storage.from("payment-assets").createSignedUrl(path, 3600 * 24 * 365 * 5)).data?.signedUrl || "");
		} catch (e) {
			setErr(e.message || "Upload failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-16 w-16 rounded-lg border border-border bg-background overflow-hidden flex items-center justify-center text-[10px] text-muted-foreground",
				children: value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: value,
					alt: "",
					className: "h-full w-full object-cover"
				}) : "No image"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "file",
						accept: "image/*",
						disabled: busy,
						onChange: (e) => pick(e.target.files?.[0] || null),
						className: "w-full rounded border px-3 py-2 text-sm"
					}),
					busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground mt-1",
						children: "Uploading..."
					}),
					err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-destructive mt-1",
						children: err
					})
				]
			})]
		})
	});
}
function AskDialog({ state, onClose }) {
	const [value, setValue] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setValue("");
	}, [state]);
	if (!state) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[60] bg-black/60 flex items-center justify-center p-6",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			className: "bg-card rounded-2xl p-6 w-full max-w-md shadow-elegant",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-serif text-xl text-primary",
					children: state.title
				}),
				state.message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: state.message
				}),
				state.input && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
						label: state.input.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							autoFocus: true,
							type: state.input.type || "text",
							value,
							onChange: (e) => setValue(e.target.value),
							className: "w-full rounded border px-3 py-2"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "flex-1 rounded-full border py-2.5 text-sm",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy || state.input?.required && !value.trim(),
						onClick: async () => {
							setBusy(true);
							try {
								await state.onConfirm(value);
								onClose();
							} finally {
								setBusy(false);
							}
						},
						className: `flex-1 rounded-full py-2.5 text-sm font-semibold disabled:opacity-60 ${state.tone === "danger" ? "bg-destructive text-destructive-foreground" : "bg-gradient-gold text-gold-foreground"}`,
						children: busy ? "Please wait..." : state.confirmLabel || "Confirm"
					})]
				})
			]
		})
	});
}
function Notice({ text, onClose }) {
	if (!text) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed bottom-6 right-6 z-[70] rounded-xl bg-primary text-primary-foreground px-4 py-3 text-sm shadow-elegant flex items-center gap-3",
		children: [text, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: onClose,
			className: "opacity-70 hover:opacity-100",
			children: "✕"
		})]
	});
}
function MembersTab({ members, onReload, onKyc, onState, onPassword, onAdd }) {
	const blank = {
		fullName: "",
		mobile: "",
		realEmail: "",
		dob: "",
		password: "",
		sponsorCode: "",
		position: "left",
		activate: false
	};
	const [form, setForm] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [err, setErr] = (0, import_react.useState)("");
	const [created, setCreated] = (0, import_react.useState)(null);
	const [showPass, setShowPass] = (0, import_react.useState)({});
	const [query, setQuery] = (0, import_react.useState)("");
	const [ask, setAsk] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)("");
	const rows = members.filter((m) => {
		const q = query.trim().toLowerCase();
		if (!q) return true;
		return [
			m.full_name,
			m.phone,
			m.email,
			m.referral_code,
			m.member_code
		].some((v) => (v || "").toLowerCase().includes(q));
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-serif text-2xl text-primary",
					children: [
						"Members (",
						members.length,
						")"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => setQuery(e.target.value),
						placeholder: "Search name / mobile / ID",
						className: "rounded-full border border-border bg-card px-4 py-2 text-sm"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => {
							setErr("");
							setForm(blank);
						},
						className: "rounded-full bg-gradient-gold text-gold-foreground px-4 py-2 text-sm font-semibold flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4" }), " Add Member"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				title: "All Members",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableWrap, {
					cols: [
						"Name",
						"User ID",
						"Mobile",
						"Email",
						"Password",
						"Ref Code",
						"Paid / ID",
						"Account",
						"KYC",
						"Joined",
						"Actions"
					],
					children: rows.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/50 align-top",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: m.full_name || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 font-mono text-xs text-primary",
								children: m.member_code || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: m.phone || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 text-xs",
								children: m.email
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 text-xs",
								children: m.login_password ? showPass[m.id] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono",
									children: m.login_password
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setShowPass((s) => ({
										...s,
										[m.id]: true
									})),
									className: "text-primary underline",
									children: "Show"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground",
									children: "not stored"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 font-mono text-xs",
								children: m.referral_code
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: m.is_active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-green-600 font-semibold",
									children: "Active"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setAsk({
										title: "Activate this ID?",
										message: `${m.full_name}'s ID will be marked as paid and income will start.`,
										confirmLabel: "Activate ID",
										onConfirm: async () => {
											await onState(m.id, { is_active: true });
											setNotice("ID activated.");
										}
									}),
									className: "rounded bg-green-600 text-white px-2 py-1 text-xs font-semibold",
									children: "Activate ID"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: m.account_status || "active",
									onChange: async (e) => {
										await onState(m.id, { account_status: e.target.value });
									},
									className: "text-xs border rounded px-2 py-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "active",
											children: "Active"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "inactive",
											children: "Inactive"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "suspended",
											children: "Suspended"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "banned",
											children: "Banned"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									defaultValue: "",
									onChange: async (e) => {
										const v = e.target.value;
										if (!v) return;
										await onKyc(m.id, v);
										e.currentTarget.value = "";
									},
									className: "text-xs border rounded px-2 py-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: m.kyc_status
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "approved",
											children: "Approve"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "rejected",
											children: "Reject"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "pending",
											children: "Reset"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2 text-xs",
								children: new Date(m.created_at).toLocaleDateString()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2 px-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-col gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setAsk({
											title: "Set new password",
											message: `New login password for ${m.full_name} (minimum 6 characters).`,
											input: {
												label: "New password",
												required: true
											},
											confirmLabel: "Update password",
											onConfirm: async (v) => {
												if (v.trim().length < 6) {
													setNotice("Password must be at least 6 characters.");
													return;
												}
												await onPassword(m.id, v.trim());
												setNotice("Password updated.");
											}
										}),
										className: "rounded bg-primary text-primary-foreground px-2 py-1 text-xs",
										children: "Set password"
									}), m.is_active && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setAsk({
											title: "Deactivate this ID?",
											message: "The ID will be marked as not paid and income will stop.",
											confirmLabel: "Deactivate",
											tone: "danger",
											onConfirm: async () => {
												await onState(m.id, { is_active: false });
												setNotice("ID deactivated.");
											}
										}),
										className: "rounded border border-border px-2 py-1 text-xs",
										children: "Deactivate ID"
									})]
								})
							})
						]
					}, m.id))
				})
			}),
			form && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6",
				onClick: () => setForm(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onClick: (e) => e.stopPropagation(),
					className: "bg-card rounded-2xl p-8 max-w-xl w-full shadow-elegant max-h-[90vh] overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-serif text-2xl text-primary mb-4",
						children: "Add Member Manually"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "space-y-3",
						onSubmit: async (e) => {
							e.preventDefault();
							setBusy(true);
							setErr("");
							try {
								setCreated({
									memberCode: (await onAdd({
										...form,
										mobile: form.mobile.replace(/\D/g, ""),
										sponsorCode: form.sponsorCode.trim().toUpperCase()
									})).memberCode,
									mobile: form.mobile,
									password: form.password
								});
								setForm(null);
								await onReload();
							} catch (addError) {
								setErr(addError instanceof Error ? addError.message : "Could not add member");
							} finally {
								setBusy(false);
							}
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
								label: "Full Name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: form.fullName,
									onChange: (e) => setForm({
										...form,
										fullName: e.target.value
									}),
									className: "w-full rounded border px-3 py-2"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Mobile Number (login ID)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										value: form.mobile,
										onChange: (e) => setForm({
											...form,
											mobile: e.target.value.replace(/\D/g, "").slice(0, 10)
										}),
										className: "w-full rounded border px-3 py-2"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Password",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										minLength: 6,
										value: form.password,
										onChange: (e) => setForm({
											...form,
											password: e.target.value
										}),
										className: "w-full rounded border px-3 py-2"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Email",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										required: true,
										type: "email",
										value: form.realEmail,
										onChange: (e) => setForm({
											...form,
											realEmail: e.target.value
										}),
										className: "w-full rounded border px-3 py-2"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Date of Birth",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										value: form.dob,
										onChange: (e) => setForm({
											...form,
											dob: e.target.value
										}),
										className: "w-full rounded border px-3 py-2"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Sponsor Code (optional)",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: form.sponsorCode,
										onChange: (e) => setForm({
											...form,
											sponsorCode: e.target.value.toUpperCase()
										}),
										className: "w-full rounded border px-3 py-2"
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(F, {
									label: "Position",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: form.position,
										onChange: (e) => setForm({
											...form,
											position: e.target.value
										}),
										className: "w-full rounded border px-3 py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "left",
											children: "Left"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "right",
											children: "Right"
										})]
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: form.activate,
									onChange: (e) => setForm({
										...form,
										activate: e.target.checked
									})
								}), "Activate this ID immediately (payment already received)"]
							}),
							err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "rounded-lg bg-destructive/10 text-destructive text-sm p-3",
								children: err
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: busy,
									type: "submit",
									className: "rounded-full bg-gradient-gold text-gold-foreground px-5 py-2.5 text-sm font-semibold disabled:opacity-60",
									children: busy ? "Creating…" : "Create Member"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setForm(null),
									className: "rounded-full border border-border px-5 py-2.5 text-sm",
									children: "Cancel"
								})]
							})
						]
					})]
				})
			}),
			created && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-6",
				onClick: () => setCreated(null),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onClick: (e) => e.stopPropagation(),
					className: "bg-card rounded-2xl p-8 max-w-sm w-full shadow-elegant text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-12 w-12 text-green-600" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-2xl text-primary mt-3",
							children: "Member Created"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl bg-muted/40 p-4 text-left text-sm space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "User ID"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
										className: "text-primary",
										children: created.memberCode
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Login mobile"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: created.mobile })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted-foreground",
										children: "Password"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: created.password })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => navigator.clipboard?.writeText(`User ID: ${created.memberCode}\nMobile: ${created.mobile}\nPassword: ${created.password}`),
							className: "mt-4 text-sm text-primary underline",
							children: "Copy details"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setCreated(null),
							className: "mt-4 w-full rounded-full bg-primary text-primary-foreground py-2.5 text-sm font-semibold",
							children: "Done"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AskDialog, {
				state: ask,
				onClose: () => setAsk(null)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				text: notice,
				onClose: () => setNotice("")
			})
		]
	});
}
//#endregion
export { Admin as component };
