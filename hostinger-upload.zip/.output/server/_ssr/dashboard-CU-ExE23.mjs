import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DCIbG3ZB.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as IndianRupee, B as Copy, C as Network, D as LogOut, N as GitBranch, P as Gift, V as Clock, c as TrendingUp, h as ShoppingBag, i as User, j as IdCard, k as LayoutDashboard, l as Trash2, n as Wallet, r as Users, v as Send } from "../_libs/lucide-react.mjs";
import { a as expireMyRewards, h as useServerFn, i as claimMyReward, o as getMyDirectTeam, s as getMyTree } from "./mlm.functions-wpgd-J5F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-CU-ExE23.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var logoAsset = { url: "/logo.png" };
var capsuleAsset = { url: "/aaurva-capsule.png" };
function Dashboard() {
	const nav = useNavigate();
	const fetchDirectTeam = useServerFn(getMyDirectTeam);
	const fetchTree = useServerFn(getMyTree);
	const claimReward = useServerFn(claimMyReward);
	const expireRewards = useServerFn(expireMyRewards);
	const [tab, setTab] = (0, import_react.useState)(() => {
		if (typeof window === "undefined") return "overview";
		return new URLSearchParams(window.location.search).get("tab") === "shop" ? "shop" : "overview";
	});
	const [profile, setProfile] = (0, import_react.useState)(null);
	const [wallet, setWallet] = (0, import_react.useState)(null);
	const [stats, setStats] = (0, import_react.useState)(null);
	const [products, setProducts] = (0, import_react.useState)([]);
	const [orders, setOrders] = (0, import_react.useState)([]);
	const [commissions, setCommissions] = (0, import_react.useState)([]);
	const [withdrawals, setWithdrawals] = (0, import_react.useState)([]);
	const [team, setTeam] = (0, import_react.useState)([]);
	const [tree, setTree] = (0, import_react.useState)(null);
	const [rewardLevels, setRewardLevels] = (0, import_react.useState)([]);
	const [myRewards, setMyRewards] = (0, import_react.useState)([]);
	const [settings, setSettings] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [notice, setNotice] = (0, import_react.useState)("");
	async function loadAll() {
		const { data: userRes } = await supabase.auth.getUser();
		try {
			await expireRewards({});
		} catch {}
		if (!userRes.user) return;
		const uid = userRes.user.id;
		const [p, w, s, pr, o, c, wd, tm, ps, rl, ur, tr] = await Promise.all([
			supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
			supabase.from("wallets").select("*").eq("user_id", uid).maybeSingle(),
			supabase.from("tree_stats").select("*").eq("user_id", uid).maybeSingle(),
			supabase.from("products").select("*").eq("status", "active").order("created_at"),
			supabase.from("orders").select("*").eq("user_id", uid).order("created_at", { ascending: false }),
			supabase.from("commissions").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(50),
			supabase.from("withdrawals").select("*").eq("user_id", uid).order("created_at", { ascending: false }),
			fetchDirectTeam(),
			supabase.from("plan_settings").select("*").eq("id", 1).maybeSingle(),
			supabase.from("reward_levels").select("*").order("level"),
			supabase.from("user_rewards").select("level,amount,created_at,status,claim_deadline").eq("user_id", uid),
			fetchTree()
		]);
		if (p.data) setProfile(p.data);
		if (w.data) setWallet(w.data);
		if (s.data) setStats(s.data);
		setProducts(pr.data || []);
		setOrders(o.data || []);
		setCommissions(c.data || []);
		setWithdrawals(wd.data || []);
		setTeam(tm || []);
		setRewardLevels(rl.data || []);
		setMyRewards(ur.data || []);
		setTree(tr ?? null);
		if (ps.data) setSettings(ps.data);
		setLoading(false);
	}
	(0, import_react.useEffect)(() => {
		loadAll();
	}, []);
	async function logout() {
		await supabase.auth.signOut();
		await nav({
			to: "/login",
			replace: true
		});
	}
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen flex items-center justify-center text-muted-foreground",
		children: "Loading your dashboard..."
	});
	if (!profile || !wallet) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen flex items-center justify-center text-destructive",
		children: "Could not load profile. Please try again."
	});
	const referralLink = typeof window !== "undefined" ? `${window.location.origin}/register?ref=${profile.referral_code}&pos=${profile.position || "left"}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex bg-gradient-leaf",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "w-64 bg-primary text-primary-foreground min-h-screen sticky top-0 hidden md:flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-6 py-5 border-b border-primary-foreground/10 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-10 w-10 rounded-full overflow-hidden bg-white ring-2 ring-gold/50 flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoAsset.url,
								alt: "Logo",
								className: "h-full w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "leading-tight",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-serif font-bold",
								children: "Righvedh"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] uppercase tracking-widest text-gold",
								children: "Member"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "flex-1 p-4 space-y-1 overflow-y-auto",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "overview",
								onClick: () => setTab("overview"),
								icon: LayoutDashboard,
								label: "Overview"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "shop",
								onClick: () => setTab("shop"),
								icon: ShoppingBag,
								label: "Shop / Cart"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "orders",
								onClick: () => setTab("orders"),
								icon: Clock,
								label: "My Orders"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "team",
								onClick: () => setTab("team"),
								icon: Users,
								label: "My Team"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "tree",
								onClick: () => setTab("tree"),
								icon: Network,
								label: "Tree View"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "rewards",
								onClick: () => setTab("rewards"),
								icon: Gift,
								label: "Reward Levels"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "income",
								onClick: () => setTab("income"),
								icon: TrendingUp,
								label: "Income History"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "withdraw",
								onClick: () => setTab("withdraw"),
								icon: Send,
								label: "Withdraw"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "idcard",
								onClick: () => setTab("idcard"),
								icon: IdCard,
								label: "ID Card"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavBtn, {
								active: tab === "profile",
								onClick: () => setTab("profile"),
								icon: User,
								label: "Profile & KYC"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: logout,
						className: "m-4 flex items-center gap-2 px-4 py-2 rounded-lg bg-primary-foreground/10 hover:bg-primary-foreground/20 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), " Logout"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "flex-1 p-6 md:p-10 max-w-full overflow-x-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3 mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-serif text-3xl text-primary",
							children: ["Welcome, ", profile.full_name || "Member"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								"User ID: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-primary",
									children: profile.member_code
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-2",
									children: "·"
								}),
								"Login mobile: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-primary",
									children: profile.username || profile.phone || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-2",
									children: "·"
								}),
								"Referral code: ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold text-primary",
									children: profile.referral_code
								})
							]
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								className: "text-sm text-primary hover:underline",
								children: "← Back to website"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: logout,
								className: "md:hidden inline-flex items-center gap-1 rounded-full border border-primary px-3 py-1.5 text-xs text-primary",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-3.5 w-3.5" }), " Logout"]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "md:hidden mb-4 grid grid-cols-4 gap-1 text-[11px]",
						children: [
							"overview",
							"shop",
							"orders",
							"team",
							"tree",
							"rewards",
							"income",
							"withdraw",
							"idcard",
							"profile"
						].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setTab(t),
							className: `py-2 rounded-lg ${tab === t ? "bg-primary text-primary-foreground" : "bg-card"}`,
							children: t
						}, t))
					}),
					tab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Wallet,
										label: "Wallet Balance",
										value: `₹${wallet.balance}`,
										accent: "gold"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: TrendingUp,
										label: "Total Earned",
										value: `₹${wallet.total_earned}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: IndianRupee,
										label: "Direct Income",
										value: `₹${wallet.direct_income}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: IndianRupee,
										label: "Pair Income",
										value: `₹${wallet.pair_income}`
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Users,
										label: "Left Team",
										value: String(stats?.left_count ?? 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Users,
										label: "Right Team",
										value: String(stats?.right_count ?? 0)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: GitBranch,
										label: "Matched Pairs",
										value: String(stats?.matched_pairs ?? 0)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-card border border-border p-6 shadow-soft",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-serif text-xl text-primary mb-2",
										children: "Your Referral Link"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-sm text-muted-foreground mb-3",
										children: [
											"Share this link to add members to your ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: profile.position || "left" }),
											" leg."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2 items-center",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											readOnly: true,
											value: referralLink,
											className: "flex-1 rounded-lg border border-input bg-background px-3 py-2 text-xs font-mono"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											onClick: () => {
												navigator.clipboard.writeText(referralLink);
												setNotice("Referral link copied.");
											},
											className: "rounded-lg bg-gradient-gold px-4 py-2 text-sm text-gold-foreground font-semibold flex items-center gap-1",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy"]
										})]
									})
								]
							})
						]
					}),
					tab === "shop" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopTab, {
						products,
						profile,
						settings,
						onDone: loadAll
					}),
					tab === "orders" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "My Orders",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleTable, {
							cols: [
								"Date",
								"Product",
								"Amount",
								"UPI Ref",
								"Screenshot",
								"Status"
							],
							rows: orders.map((o) => [
								new Date(o.created_at).toLocaleDateString(),
								products.find((p) => p.id === o.product_id)?.name || "—",
								`₹${o.amount}`,
								o.upi_reference || "—",
								o.payment_screenshot_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: o.payment_screenshot_url,
									target: "_blank",
									rel: "noreferrer",
									className: "text-primary underline text-xs",
									children: "View"
								}, "ss") : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted-foreground",
									children: "—"
								}, "ss"),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: o.status }, "s")
							]),
							empty: "No orders yet. Buy a product from the Shop tab to place your first order."
						})
					}),
					tab === "team" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "My Direct Team",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleTable, {
							cols: [
								"Name",
								"Referral Code",
								"Position",
								"Status",
								"Joined"
							],
							rows: team.map((t) => [
								t.full_name || "—",
								t.referral_code,
								t.member_position || "—",
								t.is_active ? "Active" : "Pending",
								new Date(t.created_at).toLocaleDateString()
							]),
							empty: "No direct referrals yet. Share your referral link to grow your team!"
						})
					}),
					tab === "tree" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Binary Tree View",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 sm:grid-cols-3 mb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Users,
										label: "Left Leg Members",
										value: String(countLeg(tree?.left ?? null))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: Users,
										label: "Right Leg Members",
										value: String(countLeg(tree?.right ?? null))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
										icon: GitBranch,
										label: "Matched Pairs (paid)",
										value: String(stats?.matched_pairs ?? 0)
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground mb-4",
								children: "Every member has two positions — Left and Right. New joinings under your referral fill these positions top to bottom. One left member + one right member makes a pair, and each matched pair pays your pair bonus. Tree shows up to 10 levels deep."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-x-auto pb-4",
								children: tree ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeBranch, {
									node: tree,
									root: true
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "Tree is not available yet."
								})
							})
						]
					}),
					tab === "rewards" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RewardsTab, {
						levels: rewardLevels,
						earned: myRewards,
						pairs: stats?.matched_pairs ?? 0,
						onClaim: async (level) => {
							try {
								await claimReward({ data: { level } });
								await loadAll();
							} catch (claimError) {
								setNotice(claimError instanceof Error ? claimError.message : "Could not claim reward");
							}
						}
					}),
					tab === "income" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Commission History",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleTable, {
							cols: [
								"Date",
								"Type",
								"Amount",
								"Note"
							],
							rows: commissions.map((c) => [
								new Date(c.created_at).toLocaleDateString(),
								c.type === "direct" ? "Direct Sale" : c.type === "reward" ? "Level Reward" : "Pair Match",
								`₹${c.amount}`,
								c.note
							]),
							empty: "No commissions yet."
						})
					}),
					tab === "withdraw" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WithdrawTab, {
						wallet,
						profile,
						withdrawals,
						settings,
						onDone: loadAll
					}),
					tab === "idcard" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdCardTab, {
						profile,
						onDone: loadAll
					}),
					tab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileTab, {
						profile,
						onDone: loadAll
					})
				]
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed bottom-6 right-6 z-[70] rounded-xl bg-primary text-primary-foreground px-4 py-3 text-sm shadow-elegant flex items-center gap-3",
				children: [notice, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setNotice(""),
					className: "opacity-70 hover:opacity-100",
					children: "✕"
				})]
			})
		]
	});
}
function NavBtn({ active, onClick, icon: Icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick,
		className: `w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm ${active ? "bg-gold text-gold-foreground font-semibold" : "hover:bg-primary-foreground/10"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
			" ",
			label
		]
	});
}
function Stat({ icon: Icon, label, value, accent }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-2xl border p-5 shadow-soft ${accent === "gold" ? "bg-gradient-gold text-gold-foreground border-gold/40" : "bg-card border-border"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs uppercase tracking-wider opacity-80",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }),
				" ",
				label
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 font-serif text-2xl font-bold",
			children: value
		})]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-card border border-border p-6 shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-serif text-2xl text-primary mb-4",
			children: title
		}), children]
	});
}
function SimpleTable({ cols, rows, empty }) {
	if (rows.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground py-6 text-center",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "text-left text-xs uppercase text-muted-foreground border-b border-border",
				children: cols.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "py-2 px-2",
					children: c
				}, c))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "border-b border-border/50",
				children: r.map((cell, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "py-2 px-2",
					children: cell
				}, j))
			}, i)) })]
		})
	});
}
function StatusPill({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `px-2 py-0.5 rounded-full text-xs font-semibold ${{
			pending: "bg-amber-100 text-amber-700",
			approved: "bg-green-100 text-green-700",
			rejected: "bg-red-100 text-red-700"
		}[status] || "bg-muted"}`,
		children: status
	});
}
function ShopTab({ products, profile, settings, onDone }) {
	const [cart, setCart] = (0, import_react.useState)([]);
	const [checkout, setCheckout] = (0, import_react.useState)(false);
	const [upiRef, setUpiRef] = (0, import_react.useState)("");
	const [file, setFile] = (0, import_react.useState)(null);
	const [msg, setMsg] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [ship, setShip] = (0, import_react.useState)({
		name: profile.full_name || "",
		phone: profile.username || profile.phone || "",
		address: profile.address_line || "",
		city: profile.city || "",
		state: profile.state || "",
		pincode: profile.pincode || ""
	});
	const total = cart.reduce((s, l) => s + Number(l.product.mrp) * l.qty, 0);
	function add(p) {
		setCart((c) => c.some((l) => l.product.id === p.id) ? c.map((l) => l.product.id === p.id ? {
			...l,
			qty: l.qty + 1
		} : l) : [...c, {
			product: p,
			qty: 1
		}]);
		setMsg("");
	}
	function setQty(id, qty) {
		setCart((c) => qty <= 0 ? c.filter((l) => l.product.id !== id) : c.map((l) => l.product.id === id ? {
			...l,
			qty
		} : l));
	}
	async function place() {
		if (cart.length === 0) {
			setMsg("Your cart is empty.");
			return;
		}
		if (!file) {
			setMsg("Please upload your payment screenshot.");
			return;
		}
		if (!ship.name.trim() || !ship.phone.trim() || !ship.address.trim() || !ship.city.trim() || !ship.state.trim() || !/^\d{6}$/.test(ship.pincode.trim())) {
			setMsg("Please fill the complete delivery address with a valid 6-digit pincode.");
			return;
		}
		setBusy(true);
		try {
			const ext = file.name.split(".").pop() || "jpg";
			const path = `${profile.id}/${Date.now()}.${ext}`;
			const up = await supabase.storage.from("payment-proofs").upload(path, file, { upsert: false });
			if (up.error) throw up.error;
			const url = (await supabase.storage.from("payment-proofs").createSignedUrl(path, 3600 * 24 * 365)).data?.signedUrl || "";
			const cartGroup = globalThis.crypto?.randomUUID?.() ?? `${Date.now()}`;
			const rows = cart.map((l) => ({
				user_id: profile.id,
				product_id: l.product.id,
				quantity: l.qty,
				amount: Number(l.product.mrp) * l.qty,
				status: "pending",
				upi_reference: upiRef.trim(),
				payment_screenshot_url: url,
				cart_group: cartGroup,
				ship_name: ship.name.trim(),
				ship_phone: ship.phone.trim(),
				ship_address: ship.address.trim(),
				ship_city: ship.city.trim(),
				ship_state: ship.state.trim(),
				ship_pincode: ship.pincode.trim()
			}));
			const { error } = await supabase.from("orders").insert(rows);
			if (error) throw error;
			setMsg("Order submitted! Admin will verify your payment screenshot and approve or reject it.");
			setCart([]);
			setCheckout(false);
			setUpiRef("");
			setFile(null);
			onDone();
		} catch (e) {
			setMsg("Error: " + (e.message || String(e)));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-primary/10 text-primary text-sm p-4",
				children: msg
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: products.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-card border border-border shadow-soft overflow-hidden flex flex-col h-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: p.image_url || capsuleAsset.url,
						alt: p.name,
						className: "w-full h-40 object-cover bg-gradient-to-br from-primary/10 to-gold/20",
						onError: (e) => {
							e.currentTarget.src = capsuleAsset.url;
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5 flex flex-col flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wider text-gold font-semibold",
								children: p.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-serif text-lg text-primary mt-1 min-h-[3.5rem]",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground mt-1 line-clamp-2",
								children: p.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-auto pt-4 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-bold text-primary",
									children: ["₹", p.mrp]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => add(p),
									className: "rounded-full bg-gradient-gold px-4 py-2 text-xs font-semibold text-gold-foreground",
									children: "Add to Cart"
								})]
							})
						]
					})]
				}, p.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: `My Cart (${cart.length} item${cart.length === 1 ? "" : "s"})`,
				children: cart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground py-4 text-center",
					children: "Cart is empty. Add one or more products, then pay once for the whole cart."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [cart.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 border-b border-border/60 pb-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-semibold text-primary text-sm",
									children: l.product.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted-foreground",
									children: [
										"₹",
										l.product.mrp,
										" each"
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setQty(l.product.id, l.qty - 1),
										className: "h-7 w-7 rounded-full border border-input",
										children: "−"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-6 text-center text-sm",
										children: l.qty
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setQty(l.product.id, l.qty + 1),
										className: "h-7 w-7 rounded-full border border-input",
										children: "+"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-20 text-right font-bold text-primary text-sm",
								children: ["₹", Number(l.product.mrp) * l.qty]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setQty(l.product.id, 0),
								className: "text-destructive",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
							})
						]
					}, l.product.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between pt-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-serif text-xl text-primary",
							children: ["Total: ₹", total]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setCheckout(true);
								setMsg("");
							},
							className: "rounded-full bg-gradient-gold px-6 py-2.5 text-sm font-semibold text-gold-foreground shadow-gold",
							children: "Checkout & Pay"
						})]
					})]
				})
			}),
			checkout && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 bg-black/60 flex items-start justify-center p-6 overflow-y-auto",
				onClick: () => setCheckout(false),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					onClick: (e) => e.stopPropagation(),
					className: "bg-card rounded-2xl p-8 max-w-lg w-full shadow-elegant my-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-serif text-2xl text-primary",
							children: "Checkout"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground mt-1",
							children: [
								cart.length,
								" item(s) · Total ₹",
								total
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
							className: "mt-5 font-semibold text-sm text-primary",
							children: "Delivery Address"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid gap-3 sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.name,
									onChange: (e) => setShip({
										...ship,
										name: e.target.value
									}),
									placeholder: "Full name",
									className: "rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.phone,
									onChange: (e) => setShip({
										...ship,
										phone: e.target.value
									}),
									placeholder: "Mobile number",
									className: "rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.address,
									onChange: (e) => setShip({
										...ship,
										address: e.target.value
									}),
									placeholder: "House / Street / Area",
									className: "sm:col-span-2 rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.city,
									onChange: (e) => setShip({
										...ship,
										city: e.target.value
									}),
									placeholder: "City",
									className: "rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.state,
									onChange: (e) => setShip({
										...ship,
										state: e.target.value
									}),
									placeholder: "State",
									className: "rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ship.pincode,
									onChange: (e) => setShip({
										...ship,
										pincode: e.target.value
									}),
									placeholder: "Pincode",
									className: "rounded-xl border border-input bg-background px-3 py-2.5 text-sm"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 rounded-xl bg-cream p-4 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs uppercase tracking-widest text-muted-foreground",
									children: [
										"Pay ₹",
										total,
										" via UPI"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: settings?.qr_image_url || "/phonepe-qr.png",
									onError: (event) => {
										event.currentTarget.src = "/phonepe-qr.png";
									},
									alt: "Payment QR code",
									className: "mx-auto mt-3 w-44 rounded-xl border border-border bg-white p-2"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 font-mono text-lg font-bold text-primary select-all",
									children: settings?.upi_id || "kartiktirgar@ybl"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground",
									children: settings?.payment_account_name || "KARTIK TIRGAR"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block mt-4 text-sm font-medium",
							children: [
								"Payment Screenshot ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-destructive",
									children: "*"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "file",
									accept: "image/*",
									onChange: (e) => setFile(e.target.files?.[0] || null),
									required: true,
									className: "mt-1 w-full rounded-xl border border-input bg-background px-3 py-2 text-sm file:mr-3 file:rounded file:border-0 file:bg-primary file:text-primary-foreground file:px-3 file:py-1.5"
								}),
								file && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-1 text-xs text-muted-foreground",
									children: ["Selected: ", file.name]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block mt-4 text-sm font-medium",
							children: [
								"UPI Reference / UTR Number ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted-foreground text-xs",
									children: "(optional)"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: upiRef,
									onChange: (e) => setUpiRef(e.target.value),
									placeholder: "12 digit UTR",
									className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
								})
							]
						}),
						msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 rounded-lg bg-destructive/10 text-destructive text-sm p-3",
							children: msg
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setCheckout(false),
								className: "flex-1 rounded-full border border-input py-2.5 text-sm",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy || !file,
								onClick: place,
								className: "flex-1 rounded-full bg-gradient-gold py-2.5 text-sm font-semibold text-gold-foreground disabled:opacity-60",
								children: busy ? "Submitting..." : "I have paid, Submit"
							})]
						})
					]
				})
			})
		]
	});
}
function WithdrawTab({ wallet, profile, withdrawals, settings, onDone }) {
	const [amount, setAmount] = (0, import_react.useState)("");
	const [upi, setUpi] = (0, import_react.useState)(profile.upi_id || "");
	const [msg, setMsg] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const minWd = settings?.min_withdrawal ?? 300;
	const tdsPct = settings?.tds_percent ?? 5;
	const adminChg = settings?.admin_charge ?? 0;
	const days = settings?.withdrawal_days ?? 7;
	const amt = Number(amount) || 0;
	const tds = +(amt * tdsPct / 100).toFixed(2);
	const net = Math.max(0, +(amt - tds - adminChg).toFixed(2));
	async function submit(e) {
		e.preventDefault();
		if (amt < minWd) {
			setMsg(`Minimum withdrawal is ₹${minWd}`);
			return;
		}
		if (amt > wallet.balance) {
			setMsg("Amount exceeds wallet balance");
			return;
		}
		setBusy(true);
		const { error } = await supabase.from("withdrawals").insert({
			user_id: profile.id,
			amount: amt,
			upi_id: upi.trim(),
			tds_amount: tds,
			net_amount: net
		});
		setBusy(false);
		if (error) {
			setMsg("Error: " + error.message);
			return;
		}
		setMsg(`Withdrawal request submitted. You will receive ₹${net} in your UPI within ${days} days after admin approval.`);
		setAmount("");
		onDone();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-gradient-gold text-gold-foreground p-6 shadow-gold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-widest",
					children: "Available Balance"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "font-serif text-4xl font-bold mt-1",
					children: ["₹", wallet.balance]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-card border border-border p-5 shadow-soft grid gap-3 sm:grid-cols-4 text-center text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground uppercase",
						children: "Minimum"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-serif text-primary text-lg font-bold",
						children: ["₹", minWd]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground uppercase",
						children: "TDS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-serif text-primary text-lg font-bold",
						children: [tdsPct, "%"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground uppercase",
						children: "Admin Charge"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-serif text-primary text-lg font-bold",
						children: ["₹", adminChg]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground uppercase",
						children: "Payout Time"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-serif text-primary text-lg font-bold",
						children: [days, " days"]
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Request Withdrawal",
				children: [msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-primary/10 text-primary text-sm p-3 mb-4",
					children: msg
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "space-y-4 max-w-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: [
								"Amount (₹) ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted-foreground",
									children: ["— min ₹", minWd]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: minWd,
									value: amount,
									onChange: (e) => setAmount(e.target.value),
									required: true,
									className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Your UPI ID", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: upi,
								onChange: (e) => setUpi(e.target.value),
								required: true,
								placeholder: "yourname@ybl",
								className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
							})]
						}),
						amt > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-cream p-4 text-sm space-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Requested" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: ["₹", amt] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"TDS (",
										tdsPct,
										"%)"
									] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["− ₹", tds] })]
								}),
								adminChg > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Admin charge" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["− ₹", adminChg] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between border-t border-border pt-1 mt-1 text-primary font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "You will receive" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["₹", net] })]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "rounded-full bg-primary text-primary-foreground px-8 py-3 text-sm font-semibold disabled:opacity-60",
							children: busy ? "Submitting..." : "Submit Request"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: "Withdrawal History",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SimpleTable, {
					cols: [
						"Date",
						"Amount",
						"TDS",
						"Net Paid",
						"UPI",
						"Status"
					],
					rows: withdrawals.map((w) => [
						new Date(w.created_at).toLocaleDateString(),
						`₹${w.amount}`,
						`₹${w.tds_amount ?? 0}`,
						`₹${w.net_amount ?? w.amount}`,
						w.upi_id,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: w.status }, "s")
					]),
					empty: "No withdrawal requests yet."
				})
			})
		]
	});
}
function ProfileTab({ profile, onDone }) {
	const [f, setF] = (0, import_react.useState)({
		full_name: profile.full_name,
		phone: profile.phone,
		upi_id: profile.upi_id,
		address_line: profile.address_line || "",
		city: profile.city || "",
		state: profile.state || "",
		pincode: profile.pincode || ""
	});
	const [msg, setMsg] = (0, import_react.useState)("");
	async function save(e) {
		e.preventDefault();
		const { error } = await supabase.from("profiles").update(f).eq("id", profile.id);
		if (error) setMsg("Error: " + error.message);
		else {
			setMsg("Profile updated.");
			onDone();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
		title: "My Profile",
		children: [
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "rounded-lg bg-primary/10 text-primary text-sm p-3 mb-4",
				children: msg
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 grid gap-3 sm:grid-cols-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-cream p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase text-muted-foreground",
							children: "User ID"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono font-bold text-primary",
							children: profile.member_code
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-cream p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase text-muted-foreground",
							children: "Date of Birth"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-bold text-primary",
							children: profile.dob || "—"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-cream p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase text-muted-foreground",
							children: "Referral Code"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono font-bold text-primary",
							children: profile.referral_code
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				className: "space-y-4 max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Login Mobile Number", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							disabled: true,
							value: profile.username || profile.phone || "",
							className: "mt-1 w-full rounded-xl border border-input bg-muted px-4 py-3 text-sm font-mono"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							disabled: true,
							value: profile.email,
							className: "mt-1 w-full rounded-xl border border-input bg-muted px-4 py-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Full Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: f.full_name,
							onChange: (e) => setF({
								...f,
								full_name: e.target.value
							}),
							className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Phone", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: f.phone,
							onChange: (e) => setF({
								...f,
								phone: e.target.value
							}),
							className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["Address", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: f.address_line,
							onChange: (e) => setF({
								...f,
								address_line: e.target.value
							}),
							placeholder: "House / Street / Area",
							className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["City", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: f.city,
									onChange: (e) => setF({
										...f,
										city: e.target.value
									}),
									className: "mt-1 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["State", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: f.state,
									onChange: (e) => setF({
										...f,
										state: e.target.value
									}),
									className: "mt-1 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["Pincode", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: f.pincode,
									onChange: (e) => setF({
										...f,
										pincode: e.target.value
									}),
									className: "mt-1 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm"
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "block text-sm font-medium",
						children: ["UPI ID (for withdrawals)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: f.upi_id,
							onChange: (e) => setF({
								...f,
								upi_id: e.target.value
							}),
							placeholder: "yourname@ybl",
							className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm",
						children: ["KYC Status: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: profile.kyc_status === "approved" ? "text-green-600" : "text-amber-600",
							children: profile.kyc_status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "rounded-full bg-primary text-primary-foreground px-8 py-3 text-sm font-semibold",
						children: "Save"
					})
				]
			})
		]
	});
}
function countLeg(node) {
	if (!node) return 0;
	return 1 + countLeg(node.left) + countLeg(node.right);
}
function NodeCard({ node, root }) {
	if (!node) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-dashed border-border bg-muted/30 px-4 py-4 min-w-[150px] text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-9 w-9 rounded-full border border-dashed border-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 text-xs text-muted-foreground",
			children: "Empty position"
		})]
	});
	const initials = (node.full_name || "M").trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-2xl border px-4 py-3 min-w-[150px] text-center shadow-soft ${root ? "bg-gradient-gold text-gold-foreground border-gold/50" : node.is_active ? "bg-card border-primary/40" : "bg-card border-border"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mx-auto h-9 w-9 rounded-full flex items-center justify-center text-xs font-bold ${root ? "bg-gold-foreground/15" : node.is_active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`,
				children: initials
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 text-sm font-semibold truncate max-w-[150px] mx-auto",
				children: node.full_name || "Member"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-mono text-[11px] opacity-80",
				children: node.member_code
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wide ${root ? "bg-gold-foreground/15" : node.is_active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`,
				children: root ? "You" : node.is_active ? "Active" : "Pending"
			})
		]
	});
}
function TreeBranch({ node, root, depth = 0 }) {
	const showSlots = depth < 2 || !!(node.left || node.right);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NodeCard, {
			node,
			root
		}), depth < 10 && showSlots && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-px bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeLeg, {
				label: "Left",
				child: node.left,
				depth,
				side: "left"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeLeg, {
				label: "Right",
				child: node.right,
				depth,
				side: "right"
			})]
		})] })]
	});
}
function TreeLeg({ label, child, depth, side }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center px-3 sm:px-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-full h-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `flex-1 ${side === "right" ? "border-t border-border" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `flex-1 ${side === "left" ? "border-t border-border" : ""}` })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-px bg-border" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `mb-2 rounded-full px-2 py-0.5 text-[10px] uppercase tracking-widest ${side === "left" ? "bg-primary/10 text-primary" : "bg-gold/15 text-gold"}`,
				children: label
			}),
			child ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TreeBranch, {
				node: child,
				depth: depth + 1
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NodeCard, { node: null })
		]
	});
}
function RewardsTab({ levels, earned, pairs, onClaim }) {
	const byLevel = new Map(earned.map((e) => [e.level, e]));
	const claimed = earned.filter((e) => e.status === "claimed");
	const available = earned.filter((e) => e.status === "available");
	const total = claimed.reduce((s, e) => s + Number(e.amount), 0);
	const [busy, setBusy] = (0, import_react.useState)(null);
	function daysLeft(deadline) {
		if (!deadline) return 0;
		return Math.max(0, Math.ceil((new Date(deadline).getTime() - Date.now()) / 864e5));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: GitBranch,
						label: "Matched Pairs",
						value: String(pairs)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Gift,
						label: "Ready to Claim",
						value: String(available.length),
						accent: available.length ? "gold" : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: Gift,
						label: "Rewards Claimed",
						value: `${claimed.length} / ${levels.length}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						icon: IndianRupee,
						label: "Reward Income",
						value: `₹${total.toLocaleString("en-IN")}`,
						accent: "gold"
					})
				]
			}),
			available.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Rewards Ready to Claim",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-4",
					children: "Claim within 7 days of achieving the target. After 7 days the reward expires and cannot be claimed."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: available.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-gold/50 bg-gradient-gold text-gold-foreground p-5 shadow-gold",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs uppercase tracking-widest",
								children: [
									"Level ",
									r.level,
									" Star"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-serif text-2xl font-bold mt-1",
								children: ["₹", Number(r.amount).toLocaleString("en-IN")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs mt-1 opacity-90 flex items-center gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-3 w-3" }),
									" ",
									daysLeft(r.claim_deadline),
									" day(s) left to claim"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy === r.level,
								onClick: async () => {
									setBusy(r.level);
									await onClaim(r.level);
									setBusy(null);
								},
								className: "mt-3 w-full rounded-full bg-primary text-primary-foreground py-2 text-sm font-semibold disabled:opacity-60",
								children: busy === r.level ? "Claiming…" : "Claim Reward"
							})
						]
					}, r.level))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: "Reward Levels",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mb-4",
					children: "Achieve the required pairs to unlock each star. Unlocked rewards must be claimed within 7 days; claimed amounts go straight to your wallet balance. Scroll sideways to see all levels."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-x-auto pb-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-3 min-w-max",
						children: levels.map((l) => {
							const status = byLevel.get(l.level)?.status;
							const progress = Math.min(100, Math.round(pairs / l.pairs_required * 100));
							const done = status === "claimed";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: `w-44 shrink-0 rounded-2xl border p-4 ${done ? "bg-gradient-gold text-gold-foreground border-gold/50 shadow-gold" : status === "available" ? "bg-card border-gold" : "bg-card border-border"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs uppercase tracking-widest",
										children: [
											"Level ",
											l.level,
											" ★"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "font-serif text-xl font-bold mt-1",
										children: ["₹", Number(l.amount).toLocaleString("en-IN")]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs mt-1 opacity-80",
										children: [l.pairs_required.toLocaleString("en-IN"), " pairs"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-3 h-1.5 rounded-full bg-black/10 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full bg-primary",
											style: { width: `${progress}%` }
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 text-[11px] font-semibold",
										children: done ? "Claimed ✓" : status === "available" ? "Ready to claim" : status === "expired" ? "Expired" : `${progress}%`
									})
								]
							}, l.level);
						})
					})
				})]
			})
		]
	});
}
function IdCardTab({ profile, onDone }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [msg, setMsg] = (0, import_react.useState)("");
	const cardRef = (0, import_react.useRef)(null);
	async function uploadPhoto(file) {
		setBusy(true);
		setMsg("");
		try {
			const ext = file.name.split(".").pop() || "jpg";
			const path = `${profile.id}/photo-${Date.now()}.${ext}`;
			const up = await supabase.storage.from("member-photos").upload(path, file, { upsert: true });
			if (up.error) throw up.error;
			const { data } = supabase.storage.from("member-photos").getPublicUrl(path);
			const { error } = await supabase.from("profiles").update({ photo_url: data.publicUrl }).eq("id", profile.id);
			if (error) throw error;
			setMsg("Photo updated on your ID card.");
			onDone();
		} catch (e) {
			setMsg("Error: " + (e.message || String(e)));
		} finally {
			setBusy(false);
		}
	}
	async function download() {
		const canvas = document.createElement("canvas");
		canvas.width = 1012;
		canvas.height = 638;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		ctx.fillStyle = "#0f2e1d";
		ctx.fillRect(0, 0, 1012, 638);
		ctx.fillStyle = "#fdfaf1";
		ctx.fillRect(24, 140, 964, 474);
		ctx.fillStyle = "#c9a227";
		ctx.fillRect(24, 128, 964, 12);
		ctx.fillStyle = "#fdfaf1";
		ctx.font = "bold 42px Georgia, serif";
		ctx.fillText("RIGHVEDH SANJIVNI", 40, 70);
		ctx.font = "20px Arial";
		ctx.fillStyle = "#c9a227";
		ctx.fillText("MEMBER IDENTITY CARD", 42, 104);
		const loadImg = (src) => new Promise((res) => {
			const i = new Image();
			i.crossOrigin = "anonymous";
			i.onload = () => res(i);
			i.onerror = () => res(null);
			i.src = src;
		});
		const photo = profile.photo_url ? await loadImg(profile.photo_url) : null;
		ctx.strokeStyle = "#0f2e1d";
		ctx.lineWidth = 4;
		ctx.strokeRect(60, 190, 220, 260);
		if (photo) ctx.drawImage(photo, 60, 190, 220, 260);
		else {
			ctx.fillStyle = "#e6e1d3";
			ctx.fillRect(62, 192, 216, 256);
			ctx.fillStyle = "#8a8778";
			ctx.font = "18px Arial";
			ctx.fillText("No Photo", 130, 325);
		}
		const rows = [
			["Name", profile.full_name || "—"],
			["User ID", profile.member_code],
			["Mobile", profile.username || profile.phone || "—"],
			["Date of Birth", profile.dob || "—"],
			["Referral Code", profile.referral_code],
			["City", [profile.city, profile.state].filter(Boolean).join(", ") || "—"]
		];
		let y = 220;
		rows.forEach(([k, v]) => {
			ctx.fillStyle = "#6b6b5f";
			ctx.font = "18px Arial";
			ctx.fillText(k.toUpperCase(), 330, y);
			ctx.fillStyle = "#0f2e1d";
			ctx.font = "bold 26px Arial";
			ctx.fillText(v, 330, y + 30);
			y += 70;
		});
		ctx.fillStyle = "#6b6b5f";
		ctx.font = "16px Arial";
		ctx.fillText("This card is the property of Righvedh Sanjivni. Valid with active membership.", 60, 590);
		const link = document.createElement("a");
		link.download = `${profile.member_code}-id-card.png`;
		link.href = canvas.toDataURL("image/png");
		link.click();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			title: "Employee / Member ID Card",
			children: [
				msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-lg bg-primary/10 text-primary text-sm p-3 mb-4",
					children: msg
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: cardRef,
					className: "max-w-xl rounded-2xl overflow-hidden border border-border shadow-elegant",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-primary text-primary-foreground px-6 py-4 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-12 w-12 rounded-full overflow-hidden bg-white ring-2 ring-gold/60",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoAsset.url,
								alt: "Logo",
								className: "h-full w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-serif text-xl font-bold",
							children: "RIGHVEDH SANJIVNI"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[10px] uppercase tracking-[0.3em] text-gold",
							children: "Member Identity Card"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-cream p-6 flex gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-36 w-28 shrink-0 rounded-lg border-2 border-primary overflow-hidden bg-white flex items-center justify-center",
							children: profile.photo_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: profile.photo_url,
								alt: "Member",
								className: "h-full w-full object-cover"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted-foreground text-center px-2",
								children: "No photo uploaded"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm space-y-1.5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "Name",
									v: profile.full_name || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "User ID",
									v: profile.member_code,
									mono: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "Mobile",
									v: profile.username || profile.phone || "—",
									mono: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "Date of Birth",
									v: profile.dob || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "Referral Code",
									v: profile.referral_code,
									mono: true
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardRow, {
									k: "City",
									v: [profile.city, profile.state].filter(Boolean).join(", ") || "—"
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap gap-3 items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "rounded-full border border-input px-5 py-2.5 text-sm cursor-pointer",
						children: [busy ? "Uploading..." : "Upload Photo", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							className: "hidden",
							disabled: busy,
							onChange: (e) => {
								const fl = e.target.files?.[0];
								if (fl) uploadPhoto(fl);
							}
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: download,
						className: "rounded-full bg-gradient-gold px-6 py-2.5 text-sm font-semibold text-gold-foreground shadow-gold",
						children: "Download ID Card"
					})]
				})
			]
		})
	});
}
function CardRow({ k, v, mono }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-28 text-xs uppercase tracking-wide text-muted-foreground pt-0.5",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `font-semibold text-primary ${mono ? "font-mono" : ""}`,
			children: v
		})]
	});
}
//#endregion
export { Dashboard as component };
