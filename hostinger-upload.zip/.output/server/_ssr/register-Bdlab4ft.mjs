import { r as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DCIbG3ZB.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _ as useSearch, g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as Copy, U as CircleCheck } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
import { c as registerMember, h as useServerFn } from "./mlm.functions-DUvakcGb.mjs";
import { t as PasswordInput } from "./password-input-DZQVOfRZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-Bdlab4ft.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var logoAsset = { url: "/logo.png" };
function mobileToEmail(mobile) {
	return `${mobile.trim()}@rs.local`;
}
function Register() {
	const nav = useNavigate();
	const createMember = useServerFn(registerMember);
	const s = useSearch({ from: "/register" });
	const [form, setForm] = (0, import_react.useState)({
		full_name: "",
		mobile: "",
		email: "",
		dob: "",
		password: "",
		sponsor_code: s.ref?.toUpperCase() || "",
		position: s.pos || "left"
	});
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const [success, setSuccess] = (0, import_react.useState)(null);
	function up(k, v) {
		setForm((f) => ({
			...f,
			[k]: v
		}));
	}
	async function submit(e) {
		e.preventDefault();
		setError("");
		const mobile = form.mobile.replace(/\D/g, "");
		if (!/^[6-9]\d{9}$/.test(mobile)) {
			setError("Enter a valid 10-digit Indian mobile number.");
			return;
		}
		setLoading(true);
		try {
			const res = await createMember({ data: {
				fullName: form.full_name.trim(),
				mobile,
				realEmail: form.email.trim(),
				dob: form.dob,
				password: form.password,
				sponsorCode: form.sponsor_code.trim().toUpperCase(),
				position: form.position
			} });
			const { error: loginError } = await supabase.auth.signInWithPassword({
				email: mobileToEmail(mobile),
				password: form.password
			});
			if (loginError) throw loginError;
			setSuccess({
				memberCode: res.memberCode,
				mobile,
				password: form.password
			});
		} catch (registrationError) {
			const message = registrationError instanceof Error ? registrationError.message : "Registration failed";
			setError(message.toLowerCase().includes("already") ? "This mobile number is already registered." : message);
		} finally {
			setLoading(false);
		}
	}
	if (success) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "min-h-[80vh] flex items-center justify-center bg-gradient-leaf px-6 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border bg-card p-10 shadow-elegant text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "mx-auto h-14 w-14 text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Registration Success"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-2xl text-primary",
					children: "Your User ID"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2 font-serif text-4xl font-bold text-primary tracking-wide",
					children: success.memberCode
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl border border-border bg-muted/40 p-5 text-left text-sm space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Login Mobile",
						value: success.mobile
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "Password",
						value: success.password
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted-foreground",
					children: "Take a screenshot of this screen. Login with your mobile number and this password."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => nav({
						to: "/dashboard",
						replace: true
					}),
					className: "mt-6 w-full rounded-full bg-gradient-gold py-3.5 font-semibold text-gold-foreground shadow-gold hover:opacity-90",
					children: "Go to My Dashboard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => navigator.clipboard?.writeText(`User ID: ${success.memberCode}\nMobile: ${success.mobile}\nPassword: ${success.password}`),
					className: "mt-3 inline-flex items-center gap-2 text-sm text-primary hover:text-primary-glow",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4" }), " Copy details"]
				})
			]
		})
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "min-h-[80vh] flex items-center justify-center bg-gradient-leaf px-6 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-3xl border border-border bg-card p-10 shadow-elegant",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-20 w-20 rounded-full overflow-hidden bg-white flex items-center justify-center ring-2 ring-gold/50 shadow-soft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoAsset.url,
								alt: "Logo",
								className: "h-full w-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-serif text-3xl text-primary",
							children: "Join Our Family"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground text-center",
							children: "Register with your sponsor's ID. Your mobile number becomes your login ID."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-4",
					onSubmit: submit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Full Name",
								value: form.full_name,
								onChange: (v) => up("full_name", v)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mobile Number (Login ID)",
								type: "tel",
								value: form.mobile,
								onChange: (v) => up("mobile", v.replace(/\D/g, "").slice(0, 10)),
								placeholder: "10-digit mobile"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								type: "email",
								value: form.email,
								onChange: (v) => up("email", v)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Date of Birth",
								type: "date",
								value: form.dob,
								onChange: (v) => up("dob", v)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Sponsor ID",
								value: form.sponsor_code,
								onChange: (v) => up("sponsor_code", v.toUpperCase()),
								placeholder: "e.g. RSABC123",
								required: false
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-sm font-medium",
								children: ["Position", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: form.position,
									onChange: (e) => up("position", e.target.value),
									className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm focus:ring-2 focus:ring-ring",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "left",
										children: "Left"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "right",
										children: "Right"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Password",
							type: "password",
							value: form.password,
							onChange: (v) => up("password", v)
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg bg-destructive/10 text-destructive text-sm p-3",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: loading || !ready,
							className: "w-full rounded-full bg-gradient-gold py-3.5 font-semibold text-gold-foreground shadow-gold hover:opacity-90 disabled:opacity-60",
							children: loading ? "Creating..." : !ready ? "Please wait..." : "Register"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-center text-sm text-muted-foreground",
					children: [
						"Already a member?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "text-primary font-semibold hover:text-primary-glow",
							children: "Login"
						})
					]
				})
			]
		})
	}) });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-semibold text-primary",
			children: value
		})]
	});
}
function Field({ label, value, onChange, type = "text", placeholder, required = true }) {
	if (type === "password") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
			value,
			onChange,
			required,
			placeholder,
			autoComplete: "new-password"
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			required,
			placeholder,
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm focus:ring-2 focus:ring-ring"
		})]
	});
}
//#endregion
export { Register as component };
