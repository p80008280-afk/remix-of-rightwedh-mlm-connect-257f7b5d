import { i as TSS_SERVER_FUNCTION, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Cy4wKG6N.mjs";
import { a as stringType, i as objectType, n as enumType, r as numberType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mlm.functions-osgKODY-.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var registerMember_createServerFn_handler = createServerRpc({
	id: "63df4d594e6482f23fb402be517e760acd7f7520fcefed57001f882f6f0d875f",
	name: "registerMember",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => registerMember.__executeServer(opts));
var registerMember = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date of birth"),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).default(""),
	position: enumType(["left", "right"])
}).parse(d)).handler(registerMember_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const syntheticEmail = `${data.mobile}@rs.local`;
	const { data: existing } = await supabaseAdmin.from("profiles").select("id").eq("username", data.mobile).maybeSingle();
	if (existing) throw new Error("This mobile number is already registered");
	let sponsorId = null;
	let parentId = null;
	if (data.sponsorCode) {
		const { data: sponsor, error: sponsorError } = await supabaseAdmin.from("profiles").select("id").eq("referral_code", data.sponsorCode).maybeSingle();
		if (sponsorError) throw sponsorError;
		if (!sponsor) throw new Error("Sponsor code is not valid");
		sponsorId = sponsor.id;
		parentId = sponsor.id;
		while (parentId) {
			const { data: child, error: childError } = await supabaseAdmin.from("profiles").select("id").eq("parent_id", parentId).eq("position", data.position).maybeSingle();
			if (childError) throw childError;
			if (!child) break;
			parentId = child.id;
		}
	}
	const { data: created, error: authError } = await supabaseAdmin.auth.admin.createUser({
		email: syntheticEmail,
		password: data.password,
		email_confirm: true,
		user_metadata: {
			full_name: data.fullName,
			phone: data.mobile,
			username: data.mobile,
			real_email: data.realEmail,
			sponsor_code: data.sponsorCode,
			position: data.position
		}
	});
	if (authError || !created.user) throw authError ?? /* @__PURE__ */ new Error("Could not create member");
	try {
		const userId = created.user.id;
		const { data: referralCode, error: codeError } = await supabaseAdmin.rpc("generate_referral_code");
		if (codeError || !referralCode) throw codeError ?? /* @__PURE__ */ new Error("Could not generate referral code");
		const { data: memberCode, error: memberCodeError } = await supabaseAdmin.rpc("generate_member_code");
		if (memberCodeError || !memberCode) throw memberCodeError ?? /* @__PURE__ */ new Error("Could not generate member ID");
		const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
			id: userId,
			full_name: data.fullName,
			phone: data.mobile,
			email: data.realEmail,
			username: data.mobile,
			dob: data.dob,
			member_code: memberCode,
			referral_code: referralCode,
			sponsor_id: sponsorId,
			parent_id: parentId,
			position: sponsorId ? data.position : null,
			is_active: false,
			login_password: data.password
		}, { onConflict: "id" });
		if (profileError) throw profileError;
		await Promise.all([
			supabaseAdmin.from("wallets").upsert({ user_id: userId }, { onConflict: "user_id" }),
			supabaseAdmin.from("tree_stats").upsert({ user_id: userId }, { onConflict: "user_id" }),
			supabaseAdmin.from("user_roles").upsert({
				user_id: userId,
				role: "member"
			}, { onConflict: "user_id,role" })
		]);
		return {
			ok: true,
			memberCode,
			referralCode
		};
	} catch (setupError) {
		await supabaseAdmin.auth.admin.deleteUser(created.user.id);
		throw setupError;
	}
});
var getMyDirectTeam_createServerFn_handler = createServerRpc({
	id: "d3aa2b19004a5d6f224214912fba60f0cce69c57763035e0c208c1bd2fef493e",
	name: "getMyDirectTeam",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => getMyDirectTeam.__executeServer(opts));
var getMyDirectTeam = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyDirectTeam_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("profiles").select("id,full_name,referral_code,position,created_at,is_active").eq("sponsor_id", context.userId).order("created_at", { ascending: false });
	if (error) throw error;
	return (data ?? []).map((member) => ({
		id: member.id,
		full_name: member.full_name,
		referral_code: member.referral_code,
		member_position: member.position,
		created_at: member.created_at,
		is_active: member.is_active
	}));
});
var reviewOrder_createServerFn_handler = createServerRpc({
	id: "800fce929f9fbc54248d521eaf53940de033b7ebbe1a1b88c6ba46e75d0023ce",
	name: "reviewOrder",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => reviewOrder.__executeServer(opts));
var reviewOrder = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	orderId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(reviewOrder_createServerFn_handler, async ({ data, context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { error } = await supabaseAdmin.rpc("admin_review_order", {
		_order_id: data.orderId,
		_action: data.action,
		_note: data.note
	});
	if (error) throw error;
	return { ok: true };
});
var reviewWithdrawal_createServerFn_handler = createServerRpc({
	id: "c638f4607614c44874652ef7ac5e174ebdd5634c7945d171fa73d8e960f5e90f",
	name: "reviewWithdrawal",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => reviewWithdrawal.__executeServer(opts));
var reviewWithdrawal = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	withdrawalId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(reviewWithdrawal_createServerFn_handler, async ({ data, context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { error } = await supabaseAdmin.rpc("admin_review_withdrawal", {
		_withdrawal_id: data.withdrawalId,
		_action: data.action,
		_note: data.note
	});
	if (error) throw error;
	return { ok: true };
});
var upsertProduct_createServerFn_handler = createServerRpc({
	id: "08bc5bd1ba03345ea7136845a5dcc41ecd564e120451e2161dacbcb1623972e9",
	name: "upsertProduct",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => upsertProduct.__executeServer(opts));
var upsertProduct = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	id: stringType().uuid().optional(),
	name: stringType().min(1),
	description: stringType().default(""),
	category: stringType().default("General"),
	image_url: stringType().default(""),
	mrp: numberType().nonnegative(),
	direct_commission: numberType().nonnegative(),
	pair_bonus: numberType().nonnegative(),
	stock: numberType().int().nonnegative(),
	status: enumType(["active", "inactive"]).default("active")
}).parse(d)).handler(upsertProduct_createServerFn_handler, async ({ data, context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	if (data.id) {
		const { id, ...rest } = data;
		const { error } = await supabaseAdmin.from("products").update(rest).eq("id", id);
		if (error) throw error;
	} else {
		const { error } = await supabaseAdmin.from("products").insert(data);
		if (error) throw error;
	}
	return { ok: true };
});
var updateMemberStatus_createServerFn_handler = createServerRpc({
	id: "06cffbec6e121ebebf665af3d686f5d02fd7099d000a0389ab7fa99e83a041af",
	name: "updateMemberStatus",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => updateMemberStatus.__executeServer(opts));
var updateMemberStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	kyc_status: enumType([
		"pending",
		"approved",
		"rejected"
	]).optional(),
	is_active: booleanType().optional()
}).parse(d)).handler(updateMemberStatus_createServerFn_handler, async ({ data, context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const patch = {};
	if (data.kyc_status) patch.kyc_status = data.kyc_status;
	if (typeof data.is_active === "boolean") patch.is_active = data.is_active;
	const { error } = await supabaseAdmin.from("profiles").update(patch).eq("id", data.userId);
	if (error) throw error;
	return { ok: true };
});
var updatePlanSettings_createServerFn_handler = createServerRpc({
	id: "26e7b1016ca7c300ae5d8c7e203d33245a5849dccea16ae780328a68f1e9f63f",
	name: "updatePlanSettings",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => updatePlanSettings.__executeServer(opts));
var updatePlanSettings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	min_withdrawal: numberType().nonnegative(),
	tds_percent: numberType().nonnegative(),
	admin_charge: numberType().nonnegative(),
	withdrawal_days: numberType().int().nonnegative(),
	daily_pair_cap: numberType().int().nonnegative(),
	refund_days: numberType().int().nonnegative(),
	monthly_repurchase: booleanType(),
	upi_id: stringType().min(3),
	payment_account_name: stringType().min(1),
	qr_image_url: stringType().min(1),
	qr_image_path: stringType().optional()
}).parse(d)).handler(updatePlanSettings_createServerFn_handler, async ({ data, context }) => {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { error } = await supabaseAdmin.from("plan_settings").update({
		...data,
		updated_at: (/* @__PURE__ */ new Date()).toISOString()
	}).eq("id", 1);
	if (error) throw error;
	return { ok: true };
});
var resetMemberPassword_createServerFn_handler = createServerRpc({
	id: "daf614919d3622098abde76cc72ecfaedbd8fae5c963bdd9e051f7b9fadf1546",
	name: "resetMemberPassword",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => resetMemberPassword.__executeServer(opts));
var resetMemberPassword = createServerFn({ method: "POST" }).inputValidator((d) => objectType({
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	email: stringType().trim().email(),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(resetMemberPassword_createServerFn_handler, async ({ data }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data: profile, error } = await supabaseAdmin.from("profiles").select("id,email,dob").eq("username", data.mobile).maybeSingle();
	if (error) throw error;
	if (!profile || (profile.email ?? "").trim().toLowerCase() !== data.email.trim().toLowerCase() || profile.dob !== data.dob) throw new Error("Details do not match our records. Please contact support.");
	const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(profile.id, { password: data.newPassword });
	if (updateError) throw updateError;
	await supabaseAdmin.from("profiles").update({ login_password: data.newPassword }).eq("id", profile.id);
	return { ok: true };
});
var getMyTree_createServerFn_handler = createServerRpc({
	id: "49423a5f7efbde3049ab55f24ea06c0ad3bdf2b8e88a476dc6aafc505ce086df",
	name: "getMyTree",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => getMyTree.__executeServer(opts));
var getMyTree = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyTree_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { data, error } = await supabaseAdmin.from("profiles").select("id,full_name,member_code,parent_id,position,is_active");
	if (error) throw error;
	const rows = data ?? [];
	const byParent = /* @__PURE__ */ new Map();
	for (const row of rows) {
		if (!row.parent_id) continue;
		const list = byParent.get(row.parent_id) ?? [];
		list.push(row);
		byParent.set(row.parent_id, list);
	}
	function build(id, depth) {
		const self = rows.find((r) => r.id === id);
		if (!self) return null;
		const kids = depth >= 10 ? [] : byParent.get(id) ?? [];
		const leftKid = kids.find((k) => k.position === "left");
		const rightKid = kids.find((k) => k.position === "right");
		return {
			id: self.id,
			full_name: self.full_name,
			member_code: self.member_code,
			position: self.position,
			is_active: self.is_active,
			left: leftKid ? build(leftKid.id, depth + 1) : null,
			right: rightKid ? build(rightKid.id, depth + 1) : null
		};
	}
	return build(context.userId, 0);
});
async function assertAdmin(context) {
	const { data: isAdmin } = await context.supabase.rpc("has_role", {
		_user_id: context.userId,
		_role: "admin"
	});
	if (!isAdmin) throw new Error("Forbidden");
}
var adminAddMember_createServerFn_handler = createServerRpc({
	id: "6978bdfc0dc1d046ce1dda251923d4745b80d44c0d8131631f6e212e90039d6c",
	name: "adminAddMember",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminAddMember.__executeServer(opts));
var adminAddMember = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().optional().default("").transform((v) => /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).default(""),
	position: enumType(["left", "right"]).default("left"),
	activate: booleanType().default(false)
}).parse(d)).handler(adminAddMember_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const syntheticEmail = `${data.mobile}@rs.local`;
	const { data: existing } = await supabaseAdmin.from("profiles").select("id").eq("phone", data.mobile).maybeSingle();
	if (existing) throw new Error("This mobile number is already registered");
	let sponsorId = null;
	let parentId = null;
	if (data.sponsorCode) {
		const { data: sponsor } = await supabaseAdmin.from("profiles").select("id").eq("referral_code", data.sponsorCode).maybeSingle();
		if (!sponsor) throw new Error("Sponsor code is not valid");
		sponsorId = sponsor.id;
		parentId = sponsor.id;
		while (parentId) {
			const { data: child } = await supabaseAdmin.from("profiles").select("id").eq("parent_id", parentId).eq("position", data.position).maybeSingle();
			if (!child) break;
			parentId = child.id;
		}
	}
	const { data: created, error: authError } = await supabaseAdmin.auth.admin.createUser({
		email: syntheticEmail,
		password: data.password,
		email_confirm: true,
		user_metadata: {
			full_name: data.fullName,
			phone: data.mobile,
			username: data.mobile,
			real_email: data.realEmail,
			sponsor_code: data.sponsorCode,
			position: data.position
		}
	});
	if (authError || !created.user) throw authError ?? /* @__PURE__ */ new Error("Could not create member");
	try {
		const userId = created.user.id;
		const { data: referralCode } = await supabaseAdmin.rpc("generate_referral_code");
		const { data: memberCode } = await supabaseAdmin.rpc("generate_member_code");
		const { error: profileError } = await supabaseAdmin.from("profiles").upsert({
			id: userId,
			full_name: data.fullName,
			phone: data.mobile,
			email: data.realEmail,
			username: data.mobile,
			dob: data.dob,
			member_code: memberCode,
			referral_code: referralCode,
			sponsor_id: sponsorId,
			parent_id: parentId,
			position: sponsorId ? data.position : null,
			is_active: data.activate,
			account_status: "active",
			login_password: data.password
		}, { onConflict: "id" });
		if (profileError) throw profileError;
		await Promise.all([
			supabaseAdmin.from("wallets").upsert({ user_id: userId }, { onConflict: "user_id" }),
			supabaseAdmin.from("tree_stats").upsert({ user_id: userId }, { onConflict: "user_id" }),
			supabaseAdmin.from("user_roles").upsert({
				user_id: userId,
				role: "member"
			}, { onConflict: "user_id,role" })
		]);
		return {
			ok: true,
			memberCode,
			referralCode
		};
	} catch (setupError) {
		await supabaseAdmin.auth.admin.deleteUser(created.user.id);
		throw setupError;
	}
});
var adminSetAccountState_createServerFn_handler = createServerRpc({
	id: "b13323a0bf590f1cc5a38d042991d5a29ab954e2683c33ff11dd3cadfd9e49f2",
	name: "adminSetAccountState",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminSetAccountState.__executeServer(opts));
var adminSetAccountState = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	account_status: enumType([
		"active",
		"inactive",
		"suspended",
		"banned"
	]).optional(),
	is_active: booleanType().optional()
}).parse(d)).handler(adminSetAccountState_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const patch = {};
	if (data.account_status) patch.account_status = data.account_status;
	if (typeof data.is_active === "boolean") patch.is_active = data.is_active;
	const { error } = await supabaseAdmin.from("profiles").update(patch).eq("id", data.userId);
	if (error) throw error;
	return { ok: true };
});
var adminSetMemberPassword_createServerFn_handler = createServerRpc({
	id: "8149b961c456bf893dd4e18fd23c3873aeb46314bfc3abfc06b344c6e908a977",
	name: "adminSetMemberPassword",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminSetMemberPassword.__executeServer(opts));
var adminSetMemberPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({
	userId: stringType().uuid(),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(adminSetMemberPassword_createServerFn_handler, async ({ data, context }) => {
	await assertAdmin(context);
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, { password: data.newPassword });
	if (error) throw error;
	const { error: profileError } = await supabaseAdmin.from("profiles").update({ login_password: data.newPassword }).eq("id", data.userId);
	if (profileError) throw profileError;
	return { ok: true };
});
var claimMyReward_createServerFn_handler = createServerRpc({
	id: "edeb85c398aad8de0a3e5548afa06784ef16364854c645b9efaf1e5ed785647e",
	name: "claimMyReward",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => claimMyReward.__executeServer(opts));
var claimMyReward = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).inputValidator((d) => objectType({ level: numberType().int().positive() }).parse(d)).handler(claimMyReward_createServerFn_handler, async ({ data, context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	const { error } = await supabaseAdmin.rpc("claim_reward", {
		_user_id: context.userId,
		_level: data.level
	});
	if (error) throw new Error(error.message);
	return { ok: true };
});
var expireMyRewards_createServerFn_handler = createServerRpc({
	id: "95c78d13f7863edc18b525b9fc4699f3d1919b2b6a6eb3c6a6a4ccc34c63d397",
	name: "expireMyRewards",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => expireMyRewards.__executeServer(opts));
var expireMyRewards = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(expireMyRewards_createServerFn_handler, async ({ context }) => {
	const { supabaseAdmin } = await import("./client.server-KzwUIAkW.mjs");
	await supabaseAdmin.rpc("expire_due_rewards", { _user_id: context.userId });
	return { ok: true };
});
//#endregion
export { adminAddMember_createServerFn_handler, adminSetAccountState_createServerFn_handler, adminSetMemberPassword_createServerFn_handler, claimMyReward_createServerFn_handler, expireMyRewards_createServerFn_handler, getMyDirectTeam_createServerFn_handler, getMyTree_createServerFn_handler, registerMember_createServerFn_handler, resetMemberPassword_createServerFn_handler, reviewOrder_createServerFn_handler, reviewWithdrawal_createServerFn_handler, updateMemberStatus_createServerFn_handler, updatePlanSettings_createServerFn_handler, upsertProduct_createServerFn_handler };
