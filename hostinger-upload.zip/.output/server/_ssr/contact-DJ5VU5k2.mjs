import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { E as Mail, T as MapPin, V as Clock, n as Wallet } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DJ5VU5k2.js
var import_jsx_runtime = require_jsx_runtime();
var qrAsset = { url: "/phonepe-qr.png" };
function Contact() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-gradient-hero text-primary-foreground py-20",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Contact"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-serif text-5xl md:text-6xl",
					children: "Get in touch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary-foreground/80 max-w-xl mx-auto",
					children: "Product, membership or business enquiry — we're available 24 hours a day."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-6 py-20 grid lg:grid-cols-2 gap-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-5",
			children: [[
				{
					icon: Mail,
					t: "Email",
					d: "righvedhsanjivni@gmail.com",
					href: "mailto:righvedhsanjivni@gmail.com"
				},
				{
					icon: MapPin,
					t: "Address",
					d: "Scheme No. 136-A, Indore, MP, India"
				},
				{
					icon: Clock,
					t: "Support Hours",
					d: "24 hours, 7 days a week"
				},
				{
					icon: Wallet,
					t: "UPI ID",
					d: "kartiktirgar@ybl"
				}
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-4 rounded-2xl border border-border bg-card p-6 shadow-soft",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-12 w-12 rounded-lg bg-gradient-gold flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(i.icon, { className: "h-6 w-6 text-gold-foreground" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-widest text-gold font-semibold",
					children: i.t
				}), i.href ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: i.href,
					className: "font-serif text-lg text-primary hover:text-primary-glow",
					children: i.d
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-serif text-lg text-primary",
					children: i.d
				})] })]
			}, i.t)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-widest text-gold font-semibold mb-3",
						children: "PhonePe QR"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: qrAsset.url,
						alt: "PhonePe QR code",
						className: "w-48 rounded-xl mx-auto"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 text-center text-sm text-muted-foreground",
						children: "Scan & Pay — KARTIK TIRGAR"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "rounded-3xl border border-border bg-card p-8 shadow-elegant space-y-4 h-fit",
			onSubmit: (e) => {
				e.preventDefault();
				alert("Thank you! We will contact you shortly.");
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-serif text-2xl text-primary",
					children: "Send us a message"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-2 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						name: "name"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						name: "phone",
						type: "tel"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email",
					name: "email",
					type: "email"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Message",
					name: "message",
					textarea: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "w-full rounded-full bg-gradient-gold py-3.5 font-semibold text-gold-foreground shadow-gold hover:opacity-90",
					children: "Send Message"
				})
			]
		})]
	})] });
}
function Field({ label, name, type = "text", textarea }) {
	const cls = "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-medium text-foreground",
		children: [label, textarea ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			name,
			rows: 4,
			className: cls,
			required: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			name,
			type,
			className: cls,
			required: true
		})]
	});
}
//#endregion
export { Contact as component };
