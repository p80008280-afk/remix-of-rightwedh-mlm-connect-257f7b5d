import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as Leaf, f as Star, g as ShieldCheck, h as ShoppingBag } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/products-DaItDv2v.js
var import_jsx_runtime = require_jsx_runtime();
var capsuleAsset = { url: "/aaurva-capsule.png" };
var PRODUCTS = [
	{
		slug: "aaurva-capsule",
		name: "Aaurva Capsule",
		tagline: "Ayurvedic Weight & Natural Power",
		category: "Wellness",
		description: "A herbal weight-gain and strength formula crafted with 10+ powerful Ayurvedic herbs. Supports healthy weight, stamina, muscle mass and overall vitality — safe for daily use with no known side effects.",
		ingredients: [
			"Ashwagandha",
			"Shatavari",
			"Safed Musli",
			"Kaunch Beej",
			"Vidarikand",
			"Gokshura",
			"Shilajit",
			"Amla",
			"Giloy",
			"Yashtimadhu"
		],
		benefits: [
			"Healthy weight gain",
			"Boosts stamina & strength",
			"Improves appetite",
			"Supports muscle growth",
			"100% Ayurvedic formula",
			"GMP certified"
		],
		mrp: 3250,
		direct: 900,
		pair: 300,
		rating: 4.9,
		reviews: 2314,
		badge: "BESTSELLER"
	},
	{
		slug: "immuno-shakti",
		name: "Immuno Shakti Syrup",
		tagline: "Daily Immunity Booster",
		category: "Immunity",
		description: "A powerful Ayurvedic tonic combining Giloy, Tulsi and Amla to strengthen the body's natural defence system. Ideal for the whole family to stay strong through changing seasons.",
		ingredients: [
			"Giloy",
			"Tulsi",
			"Amla",
			"Ginger",
			"Honey",
			"Black Pepper"
		],
		benefits: [
			"Boosts immunity",
			"Fights seasonal infections",
			"Rich in Vitamin C",
			"Safe for all ages"
		],
		mrp: 850,
		direct: 240,
		pair: 80,
		rating: 4.8,
		reviews: 612
	},
	{
		slug: "detox-plus",
		name: "Detox Plus Churna",
		tagline: "Natural Cleanse & Digestion",
		category: "Detox",
		description: "Traditional Ayurvedic churna that gently detoxifies the liver, improves digestion and relieves constipation — helping you feel light, active and refreshed every day.",
		ingredients: [
			"Triphala",
			"Sonamukhi",
			"Saunf",
			"Ajwain",
			"Kala Namak",
			"Mulethi"
		],
		benefits: [
			"Cleanses digestive tract",
			"Relieves constipation",
			"Supports liver health",
			"Reduces bloating"
		],
		mrp: 650,
		direct: 180,
		pair: 60,
		rating: 4.7,
		reviews: 402
	},
	{
		slug: "kesh-vardhak",
		name: "Kesh Vardhak Hair Oil",
		tagline: "Ayurvedic Hair Growth Oil",
		category: "Hair Care",
		description: "A nourishing blend of Bhringraj, Amla and Brahmi that revitalises the scalp, reduces hairfall and promotes thick, shiny, healthy hair naturally.",
		ingredients: [
			"Bhringraj",
			"Amla",
			"Brahmi",
			"Coconut Oil",
			"Jatamansi",
			"Neem"
		],
		benefits: [
			"Reduces hairfall",
			"Prevents premature greying",
			"Deep scalp nourishment",
			"Promotes new hair growth"
		],
		mrp: 550,
		direct: 150,
		pair: 50,
		rating: 4.6,
		reviews: 298
	},
	{
		slug: "twak-glow",
		name: "Twak Glow Face Cream",
		tagline: "Ayurvedic Radiance Cream",
		category: "Skin Care",
		description: "Enriched with Kumkumadi, Saffron and Aloe Vera to brighten skin tone, reduce dark spots and give a natural, healthy Ayurvedic glow.",
		ingredients: [
			"Kumkumadi Tailam",
			"Saffron",
			"Aloe Vera",
			"Sandalwood",
			"Manjistha",
			"Vitamin E"
		],
		benefits: [
			"Brightens complexion",
			"Reduces dark spots",
			"Anti-ageing",
			"Deep hydration"
		],
		mrp: 950,
		direct: 270,
		pair: 90,
		rating: 4.7,
		reviews: 356
	},
	{
		slug: "joint-relief",
		name: "Joint Relief Oil",
		tagline: "Ayurvedic Pain Relief Oil",
		category: "Joint Care",
		description: "A warming Ayurvedic oil with Mahanarayan, Nirgundi and Gandhapura that eases joint pain, muscle stiffness and back pain — perfect for daily massage.",
		ingredients: [
			"Mahanarayan Tailam",
			"Nirgundi",
			"Gandhapura",
			"Kapoor",
			"Pudina",
			"Sesame Oil"
		],
		benefits: [
			"Relieves joint pain",
			"Reduces stiffness",
			"Improves mobility",
			"Soothes muscle fatigue"
		],
		mrp: 720,
		direct: 200,
		pair: 70,
		rating: 4.8,
		reviews: 471
	}
];
function Products() {
	const hero = PRODUCTS[0];
	const rest = PRODUCTS.slice(1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-hero text-primary-foreground py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Our Range"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-serif text-5xl md:text-6xl",
						children: "Ayurveda Products"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-primary-foreground/80 max-w-xl mx-auto",
						children: "Every purchase generates income for you and your team through our fair binary plan."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-6 py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-2 gap-10 items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative rounded-3xl overflow-hidden border border-border shadow-elegant",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: capsuleAsset.url,
						alt: hero.name,
						className: "w-full aspect-square object-cover"
					}), hero.badge && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "absolute top-4 left-4 rounded-full bg-gold text-gold-foreground text-[11px] px-3 py-1 font-bold shadow-gold",
						children: hero.badge
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Flagship Product"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl text-primary",
						children: hero.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-lg text-muted-foreground",
						children: hero.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center gap-1 text-gold",
						children: [Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-current" }, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-2 text-xs text-muted-foreground",
							children: [
								hero.rating,
								" / 5 · ",
								hero.reviews.toLocaleString(),
								"+ reviews"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-muted-foreground leading-relaxed",
						children: hero.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-5 grid sm:grid-cols-2 gap-3 text-sm",
						children: hero.benefits.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "h-4 w-4 text-primary shrink-0 mt-0.5" }),
								" ",
								i
							]
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceBox, {
								label: "MRP",
								value: `₹ ${hero.mrp.toLocaleString()}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceBox, {
								label: "Direct Commission",
								value: `₹ ${hero.direct}`,
								gold: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceBox, {
								label: "Pair Matching",
								value: `₹ ${hero.pair}`,
								gold: true
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard",
						search: { tab: "shop" },
						className: "mt-6 inline-flex items-center gap-2 rounded-full bg-gradient-gold px-7 py-3.5 text-sm font-semibold text-gold-foreground shadow-gold hover:opacity-90",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-4 w-4" }), " Buy Now"]
					})
				] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-leaf py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
							children: "Complete Range"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-serif text-4xl text-primary",
							children: "All Ayurveda Products"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-muted-foreground max-w-2xl mx-auto",
							children: "Each product carries its own Direct Sale Commission and Pair Matching bonus. Sell any product, earn on every order."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-6",
					children: rest.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft flex flex-col",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-40 rounded-xl bg-gradient-to-br from-primary/10 to-gold/20 flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-14 w-14 text-primary/70" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4 text-[10px] uppercase tracking-widest text-gold font-semibold",
								children: p.category
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-serif text-xl text-primary",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs text-muted-foreground",
								children: p.tagline
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-muted-foreground line-clamp-3",
								children: p.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 grid grid-cols-3 gap-2 text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg border border-border bg-background py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-widest text-muted-foreground",
											children: "MRP"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold text-primary",
											children: ["₹", p.mrp]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg bg-gradient-gold text-gold-foreground py-2 shadow-gold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-widest",
											children: "Direct"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold",
											children: ["₹", p.direct]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-lg bg-primary text-primary-foreground py-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-[9px] uppercase tracking-widest text-gold",
											children: "Pair"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-sm font-bold",
											children: ["₹", p.pair]
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/dashboard",
								search: { tab: "shop" },
								className: "mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { className: "h-4 w-4" }), " Buy Now"]
							})
						]
					}, p.slug))
				})]
			})
		})
	] });
}
function PriceBox({ label, value, gold }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl p-3 border text-center ${gold ? "bg-gradient-gold border-gold/40 text-gold-foreground shadow-gold" : "bg-card border-border"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-[10px] uppercase tracking-widest font-semibold ${gold ? "text-gold-foreground/80" : "text-muted-foreground"}`,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `mt-1 font-bold text-base ${gold ? "" : "text-primary"}`,
			children: value
		})]
	});
}
//#endregion
export { Products as component };
