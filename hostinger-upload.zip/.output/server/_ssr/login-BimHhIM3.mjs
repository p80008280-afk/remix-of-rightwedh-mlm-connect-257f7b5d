import { i as __toESM } from "../_runtime.mjs";
import { t as supabase } from "./client-DCIbG3ZB.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { g as useNavigate, h as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
import { t as PasswordInput } from "./password-input-DZQVOfRZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BimHhIM3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var logoAsset = { url: "/logo.png" };
function identifierToEmail(identifier) {
	return `${identifier.trim().toLowerCase().replace(/\s/g, "")}@rs.local`;
}
function Login() {
	const nav = useNavigate();
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	async function submit(e) {
		e.preventDefault();
		setError("");
		setLoading(true);
		try {
			const email = identifier.includes("@") ? identifier.trim().toLowerCase() : identifierToEmail(identifier);
			const { data, error: err } = await supabase.auth.signInWithPassword({
				email,
				password
			});
			if (err || !data.user) {
				setError("Login failed. Members must use their registered mobile number; the admin uses the admin email. Check the password and try again.");
				return;
			}
			const { data: acct } = await supabase.from("profiles").select("account_status").eq("id", data.user.id).maybeSingle();
			if (acct?.account_status && acct.account_status !== "active") {
				await supabase.auth.signOut();
				setError(`Your account is ${acct.account_status}. Please contact the company office.`);
				return;
			}
			const { data: roles, error: roleError } = await supabase.from("user_roles").select("role").eq("user_id", data.user.id);
			if (roleError) throw roleError;
			const isAdmin = roles?.some((r) => r.role === "admin");
			await nav({
				to: isAdmin ? "/admin" : "/dashboard",
				replace: true
			});
		} catch (loginError) {
			setError(loginError instanceof Error ? loginError.message : "Login could not be completed. Please try again.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteLayout, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "min-h-[80vh] flex items-center justify-center bg-gradient-leaf px-6 py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-3xl border border-border bg-card p-10 shadow-elegant",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-20 w-20 rounded-full overflow-hidden bg-white flex items-center justify-center ring-2 ring-gold/50 shadow-soft",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logoAsset.url,
								alt: "Logo",
								className: "h-full w-full object-cover"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 font-serif text-3xl text-primary",
							children: "Login"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Members login with mobile number. Admin can use email."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-8 space-y-4",
					onSubmit: submit,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Mobile Number or Admin Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "text",
								required: true,
								autoComplete: "username",
								value: identifier,
								onChange: (e) => setIdentifier(e.target.value),
								placeholder: "10-digit mobile number or admin email",
								className: "mt-1 w-full rounded-xl border border-input bg-background px-4 py-3 text-sm focus:ring-2 focus:ring-ring"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block text-sm font-medium",
							children: ["Password", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordInput, {
								value: password,
								onChange: setPassword
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg bg-destructive/10 text-destructive text-sm p-3",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: loading || !ready,
							className: "w-full rounded-full bg-gradient-gold py-3.5 font-semibold text-gold-foreground shadow-gold hover:opacity-90 disabled:opacity-60",
							children: loading ? "Logging in..." : !ready ? "Please wait..." : "Login"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/forgot-password",
						className: "text-sm text-primary hover:underline",
						children: "Forgot password?"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-center text-sm text-muted-foreground",
					children: "Use the mobile number given at registration; the same email can be reused for many accounts."
				})
			]
		})
	}) });
}
//#endregion
export { Login as component };
