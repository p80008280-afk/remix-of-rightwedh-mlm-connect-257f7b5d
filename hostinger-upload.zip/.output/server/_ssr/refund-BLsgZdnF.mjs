import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/refund-BLsgZdnF.js
var import_jsx_runtime = require_jsx_runtime();
function Refund() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-gradient-hero text-primary-foreground py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Legal"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-serif text-5xl",
					children: "Refund & Return Policy"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-primary-foreground/80",
					children: "15-day return / exchange window."
				})
			]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-6 py-16 space-y-8 text-[15px] leading-relaxed text-primary",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "1. 15-Day Window",
				children: "Products purchased on Righvedh Sanjivni may be returned within 15 days from the date of purchase, provided the item is unused, in its original packaging and in re-sellable condition."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "2. Income-Distributed Orders Are Final",
				children: "If the pair-matching income or direct commission on your order has already been distributed to the upline, that order is no longer eligible for refund. Product exchange may still be offered at the company's discretion."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "3. Product Exchange",
				children: "Within the 15-day window you may exchange the product for another Righvedh Sanjivni product of equal value at no extra cost. Difference in price (if any) is payable / refundable."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
				title: "4. How To Request",
				children: [
					"Write to ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-primary underline",
						href: "mailto:righvedhsanjivni@gmail.com",
						children: "righvedhsanjivni@gmail.com"
					}),
					" with your order date, member ID and reason. Our team will respond within 48 hours with return instructions."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "5. Refund Method",
				children: "Approved refunds are paid to your registered UPI ID within 7 working days after we receive and inspect the returned product."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
				title: "6. Non-Refundable",
				children: "Joining fees where the commission has been distributed, monthly repurchase products consumed by the member, and shipping charges are non-refundable."
			})
		]
	})] });
}
function Block({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "font-serif text-xl text-primary mb-2",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children
	})] });
}
//#endregion
export { Refund as component };
