import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Heart, O as Leaf, W as Award, u as Target } from "../_libs/lucide-react.mjs";
import { t as SiteLayout } from "./SiteLayout-AdIWHLqa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-CqgNuu-7.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteLayout, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-hero text-primary-foreground py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Our Story"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-serif text-5xl md:text-6xl",
						children: "About Righvedh Sanjivni"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-lg text-primary-foreground/80 max-w-2xl mx-auto leading-relaxed",
						children: "Bringing 5,000 years of Ayurvedic wisdom to every home — that is our dream."
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-6 py-20 grid lg:grid-cols-2 gap-14 items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
					children: "Vision"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-serif text-4xl text-primary",
					children: "Ayurveda in every home, livelihood in every hand."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-muted-foreground leading-relaxed",
					children: "Righvedh Sanjivni is built on a simple belief: good health and a better livelihood can go hand in hand. We operate from Scheme No. 136-A, Indore, MP and are growing our family across India."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground leading-relaxed",
					children: "Every product is certified, every member gets a fair opportunity, and every payout is fully transparent."
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-5",
				children: [
					{
						icon: Leaf,
						t: "Purity",
						d: "Pure, herb-based formulations."
					},
					{
						icon: Heart,
						t: "Trust",
						d: "An honest relationship with every member."
					},
					{
						icon: Target,
						t: "Growth",
						d: "A fair binary plan for everyone."
					},
					{
						icon: Award,
						t: "Excellence",
						d: "Global standards, Indian roots."
					}
				].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-12 w-12 rounded-lg bg-gradient-gold flex items-center justify-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(v.icon, { className: "h-6 w-6 text-gold-foreground" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 font-serif text-xl text-primary",
							children: v.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 text-sm text-muted-foreground",
							children: v.d
						})
					]
				}, v.t))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-gradient-leaf py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-4xl px-6 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs uppercase tracking-[0.3em] text-gold font-semibold",
						children: "Reach Us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-serif text-4xl text-primary",
						children: "Righvedh Sanjivni"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-muted-foreground",
						children: "Scheme No. 136-A, Indore, MP, India"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "mailto:righvedhsanjivni@gmail.com",
						className: "mt-2 inline-block text-primary font-semibold hover:text-primary-glow",
						children: "righvedhsanjivni@gmail.com"
					})
				]
			})
		})
	] });
}
//#endregion
export { About as component };
