import { i as TSS_SERVER_FUNCTION, l as createServerFn } from "./esm-9EjmF9OT.mjs";
import { t as requireSupabaseAuth } from "./auth-middleware-Cy4wKG6N.mjs";
import { a as stringType, i as objectType, n as enumType, r as numberType, t as booleanType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mlm.functions-E378NHp5.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
async function getAnonSupabase() {
	const url = process.env["SUPABASE_URL"] ?? process.env["VITE_SUPABASE_URL"];
	const key = process.env["SUPABASE_PUBLISHABLE_KEY"] ?? process.env["VITE_SUPABASE_PUBLISHABLE_KEY"] ?? process.env["SUPABASE_ANON_KEY"];
	if (!url || !key) throw new Error("Supabase environment variables are missing");
	const { createClient } = await import("../_libs/supabase__supabase-js.mjs").then((n) => n.n);
	return createClient(url, key, {
		auth: {
			persistSession: false,
			autoRefreshToken: false
		},
		global: { fetch: (input, init) => {
			const h = new Headers(init?.headers);
			if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
			h.set("apikey", key);
			return fetch(input, {
				...init,
				headers: h
			});
		} }
	});
}
var registerMember_createServerFn_handler = createServerRpc({
	id: "63df4d594e6482f23fb402be517e760acd7f7520fcefed57001f882f6f0d875f",
	name: "registerMember",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => registerMember.__executeServer(opts));
var registerMember = createServerFn({ method: "POST" }).validator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/, "Enter a valid 10-digit mobile number"),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/, "Enter a valid date of birth"),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).default(""),
	position: enumType(["left", "right"])
}).parse(d)).handler(registerMember_createServerFn_handler, async ({ data }) => {
	const { data: result, error } = await (await getAnonSupabase()).rpc("register_member", {
		_full_name: data.fullName,
		_mobile: data.mobile,
		_real_email: data.realEmail,
		_dob: data.dob,
		_password: data.password,
		_sponsor_code: data.sponsorCode || "",
		_position: data.position,
		_activate: false
	});
	if (error) throw new Error(error.message);
	const typed = result;
	if (!typed?.ok) throw new Error("Registration failed");
	return typed;
});
var adminAddMember_createServerFn_handler = createServerRpc({
	id: "6978bdfc0dc1d046ce1dda251923d4745b80d44c0d8131631f6e212e90039d6c",
	name: "adminAddMember",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminAddMember.__executeServer(opts));
var adminAddMember = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	fullName: stringType().trim().min(2).max(100),
	mobile: stringType().regex(/^[6-9][0-9]{9}$/),
	realEmail: stringType().trim().email().max(255),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	password: stringType().min(6).max(72),
	sponsorCode: stringType().trim().max(20).optional().default(""),
	position: enumType(["left", "right"]),
	activate: booleanType().default(false)
}).parse(d)).handler(adminAddMember_createServerFn_handler, async ({ data, context }) => {
	const { data: result, error } = await context.supabase.rpc("register_member", {
		_full_name: data.fullName,
		_mobile: data.mobile,
		_real_email: data.realEmail,
		_dob: data.dob,
		_password: data.password,
		_sponsor_code: data.sponsorCode || "",
		_position: data.position,
		_activate: data.activate
	});
	if (error) throw new Error(error.message);
	const typed = result;
	if (!typed?.ok) throw new Error("Member creation failed");
	return typed;
});
var getMyDirectTeam_createServerFn_handler = createServerRpc({
	id: "d3aa2b19004a5d6f224214912fba60f0cce69c57763035e0c208c1bd2fef493e",
	name: "getMyDirectTeam",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => getMyDirectTeam.__executeServer(opts));
var getMyDirectTeam = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyDirectTeam_createServerFn_handler, async ({ context }) => {
	const { data: rows, error } = await context.supabase.rpc("get_my_direct_team");
	if (error) throw error;
	return (rows ?? []).map((member) => ({
		id: member.id,
		full_name: member.full_name,
		referral_code: member.referral_code,
		member_position: member.member_position,
		created_at: member.created_at,
		is_active: member.is_active
	}));
});
var getMyTree_createServerFn_handler = createServerRpc({
	id: "49423a5f7efbde3049ab55f24ea06c0ad3bdf2b8e88a476dc6aafc505ce086df",
	name: "getMyTree",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => getMyTree.__executeServer(opts));
var getMyTree = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth]).handler(getMyTree_createServerFn_handler, async ({ context }) => {
	const { data: rows, error } = await context.supabase.rpc("get_my_tree_rows");
	if (error) throw error;
	const typedRows = rows ?? [];
	const byParent = /* @__PURE__ */ new Map();
	for (const row of typedRows) {
		const parent = row.parent_id ?? "";
		if (!byParent.has(parent)) byParent.set(parent, {});
		const bucket = byParent.get(parent);
		bucket[row.member_position] = row;
	}
	const build = (id, depth) => {
		const self = typedRows.find((r) => r.id === id);
		if (!self) return void 0;
		const kids = byParent.get(id) ?? {};
		const left = kids.left ? build(kids.left.id, depth + 1) ?? null : null;
		const right = kids.right ? build(kids.right.id, depth + 1) ?? null : null;
		return {
			id: self.id,
			full_name: self.full_name,
			member_code: self.member_code,
			is_active: self.is_active,
			left,
			right
		};
	};
	return build(context.userId, 0) ?? null;
});
var reviewOrder_createServerFn_handler = createServerRpc({
	id: "800fce929f9fbc54248d521eaf53940de033b7ebbe1a1b88c6ba46e75d0023ce",
	name: "reviewOrder",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => reviewOrder.__executeServer(opts));
var reviewOrder = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	orderId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(reviewOrder_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_review_order_hosted", {
		_order_id: data.orderId,
		_action: data.action,
		_note: data.note
	});
	if (error) throw error;
	return { ok: true };
});
var reviewWithdrawal_createServerFn_handler = createServerRpc({
	id: "c638f4607614c44874652ef7ac5e174ebdd5634c7945d171fa73d8e960f5e90f",
	name: "reviewWithdrawal",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => reviewWithdrawal.__executeServer(opts));
var reviewWithdrawal = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	withdrawalId: stringType().uuid(),
	action: enumType(["approve", "reject"]),
	note: stringType().optional().default("")
}).parse(d)).handler(reviewWithdrawal_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_review_withdrawal_hosted", {
		_withdrawal_id: data.withdrawalId,
		_action: data.action,
		_note: data.note
	});
	if (error) throw error;
	return { ok: true };
});
var upsertProduct_createServerFn_handler = createServerRpc({
	id: "08bc5bd1ba03345ea7136845a5dcc41ecd564e120451e2161dacbcb1623972e9",
	name: "upsertProduct",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => upsertProduct.__executeServer(opts));
var upsertProduct = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	id: stringType().uuid().optional(),
	name: stringType().min(1),
	description: stringType().optional().default(""),
	image_url: stringType().min(1),
	category: stringType().min(1),
	mrp: numberType().nonnegative(),
	direct_commission: numberType().nonnegative(),
	pair_bonus: numberType().nonnegative(),
	stock: numberType().int().min(0),
	status: enumType(["active", "inactive"])
}).parse(d)).handler(upsertProduct_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_upsert_product", {
		_id: data.id ?? null,
		_name: data.name,
		_description: data.description,
		_category: data.category,
		_image_url: data.image_url,
		_mrp: data.mrp,
		_direct_commission: data.direct_commission,
		_pair_bonus: data.pair_bonus,
		_stock: data.stock,
		_status: data.status
	});
	if (error) throw error;
	return { ok: true };
});
var updateMemberStatus_createServerFn_handler = createServerRpc({
	id: "06cffbec6e121ebebf665af3d686f5d02fd7099d000a0389ab7fa99e83a041af",
	name: "updateMemberStatus",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => updateMemberStatus.__executeServer(opts));
var updateMemberStatus = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	userId: stringType().uuid(),
	account_status: enumType([
		"Active",
		"Inactive",
		"Suspended",
		"Banned"
	]).optional(),
	is_active: booleanType().optional(),
	kyc_status: enumType([
		"pending",
		"approved",
		"rejected"
	]).optional()
}).parse(d)).handler(updateMemberStatus_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_set_member_state", {
		_user_id: data.userId,
		_account_status: data.account_status ?? void 0,
		_is_active: data.is_active ?? void 0,
		_kyc_status: data.kyc_status ?? void 0
	});
	if (error) throw error;
	return { ok: true };
});
var adminSetAccountState_createServerFn_handler = createServerRpc({
	id: "b13323a0bf590f1cc5a38d042991d5a29ab954e2683c33ff11dd3cadfd9e49f2",
	name: "adminSetAccountState",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminSetAccountState.__executeServer(opts));
var adminSetAccountState = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	userId: stringType().uuid(),
	account_status: enumType([
		"Active",
		"Inactive",
		"Suspended",
		"Banned"
	]),
	is_active: booleanType()
}).parse(d)).handler(adminSetAccountState_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_set_member_state", {
		_user_id: data.userId,
		_account_status: data.account_status,
		_is_active: data.is_active,
		_kyc_status: void 0
	});
	if (error) throw error;
	return { ok: true };
});
var updatePlanSettings_createServerFn_handler = createServerRpc({
	id: "26e7b1016ca7c300ae5d8c7e203d33245a5849dccea16ae780328a68f1e9f63f",
	name: "updatePlanSettings",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => updatePlanSettings.__executeServer(opts));
var updatePlanSettings = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	min_withdrawal: numberType().nonnegative(),
	tds_percent: numberType().min(0).max(100),
	admin_charge: numberType().nonnegative(),
	withdrawal_days: numberType().int().nonnegative(),
	daily_pair_cap: numberType().int().nonnegative(),
	refund_days: numberType().int().nonnegative(),
	monthly_repurchase: booleanType(),
	upi_id: stringType().min(1),
	payment_account_name: stringType().min(1),
	qr_image_url: stringType().optional().nullable(),
	qr_image_path: stringType().optional().nullable()
}).parse(d)).handler(updatePlanSettings_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_update_plan_settings", {
		_min_withdrawal: data.min_withdrawal,
		_tds_percent: data.tds_percent,
		_admin_charge: data.admin_charge,
		_withdrawal_days: data.withdrawal_days,
		_daily_pair_cap: data.daily_pair_cap,
		_refund_days: data.refund_days,
		_monthly_repurchase: data.monthly_repurchase,
		_upi_id: data.upi_id,
		_payment_account_name: data.payment_account_name,
		_qr_image_url: data.qr_image_url ?? void 0,
		_qr_image_path: data.qr_image_path ?? void 0
	});
	if (error) throw error;
	return { ok: true };
});
var resetMemberPassword_createServerFn_handler = createServerRpc({
	id: "daf614919d3622098abde76cc72ecfaedbd8fae5c963bdd9e051f7b9fadf1546",
	name: "resetMemberPassword",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => resetMemberPassword.__executeServer(opts));
var resetMemberPassword = createServerFn({ method: "POST" }).validator((d) => objectType({
	mobile: stringType().regex(/^[6-9][0-9]{9}$/),
	email: stringType().trim().email(),
	dob: stringType().regex(/^\d{4}-\d{2}-\d{2}$/),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(resetMemberPassword_createServerFn_handler, async ({ data }) => {
	const { error } = await (await getAnonSupabase()).rpc("reset_member_password", {
		_mobile: data.mobile,
		_email: data.email,
		_dob: data.dob,
		_new_password: data.newPassword
	});
	if (error) throw new Error(error.message);
	return { ok: true };
});
var adminSetMemberPassword_createServerFn_handler = createServerRpc({
	id: "8149b961c456bf893dd4e18fd23c3873aeb46314bfc3abfc06b344c6e908a977",
	name: "adminSetMemberPassword",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => adminSetMemberPassword.__executeServer(opts));
var adminSetMemberPassword = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({
	userId: stringType().uuid(),
	newPassword: stringType().min(6).max(72)
}).parse(d)).handler(adminSetMemberPassword_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("admin_set_member_password", {
		_user_id: data.userId,
		_new_password: data.newPassword
	});
	if (error) throw error;
	return { ok: true };
});
var claimMyReward_createServerFn_handler = createServerRpc({
	id: "edeb85c398aad8de0a3e5548afa06784ef16364854c645b9efaf1e5ed785647e",
	name: "claimMyReward",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => claimMyReward.__executeServer(opts));
var claimMyReward = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).validator((d) => objectType({ level: numberType().int().min(1).max(18) }).parse(d)).handler(claimMyReward_createServerFn_handler, async ({ data, context }) => {
	const { error } = await context.supabase.rpc("claim_my_reward", { _level: data.level });
	if (error) throw error;
	return { ok: true };
});
var expireMyRewards_createServerFn_handler = createServerRpc({
	id: "95c78d13f7863edc18b525b9fc4699f3d1919b2b6a6eb3c6a6a4ccc34c63d397",
	name: "expireMyRewards",
	filename: "src/lib/mlm.functions.ts"
}, (opts) => expireMyRewards.__executeServer(opts));
var expireMyRewards = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth]).handler(expireMyRewards_createServerFn_handler, async ({ context }) => {
	const { error } = await context.supabase.rpc("expire_my_rewards");
	if (error) throw error;
	return { ok: true };
});
//#endregion
export { adminAddMember_createServerFn_handler, adminSetAccountState_createServerFn_handler, adminSetMemberPassword_createServerFn_handler, claimMyReward_createServerFn_handler, expireMyRewards_createServerFn_handler, getMyDirectTeam_createServerFn_handler, getMyTree_createServerFn_handler, registerMember_createServerFn_handler, resetMemberPassword_createServerFn_handler, reviewOrder_createServerFn_handler, reviewWithdrawal_createServerFn_handler, updateMemberStatus_createServerFn_handler, updatePlanSettings_createServerFn_handler, upsertProduct_createServerFn_handler };
