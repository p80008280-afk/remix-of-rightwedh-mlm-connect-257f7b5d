//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-D2_ow_tm.js
var manifest = {
	"06cffbec6e121ebebf665af3d686f5d02fd7099d000a0389ab7fa99e83a041af": {
		functionName: "updateMemberStatus_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"08bc5bd1ba03345ea7136845a5dcc41ecd564e120451e2161dacbcb1623972e9": {
		functionName: "upsertProduct_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"26e7b1016ca7c300ae5d8c7e203d33245a5849dccea16ae780328a68f1e9f63f": {
		functionName: "updatePlanSettings_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"49423a5f7efbde3049ab55f24ea06c0ad3bdf2b8e88a476dc6aafc505ce086df": {
		functionName: "getMyTree_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"63df4d594e6482f23fb402be517e760acd7f7520fcefed57001f882f6f0d875f": {
		functionName: "registerMember_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"6978bdfc0dc1d046ce1dda251923d4745b80d44c0d8131631f6e212e90039d6c": {
		functionName: "adminAddMember_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"800fce929f9fbc54248d521eaf53940de033b7ebbe1a1b88c6ba46e75d0023ce": {
		functionName: "reviewOrder_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"8149b961c456bf893dd4e18fd23c3873aeb46314bfc3abfc06b344c6e908a977": {
		functionName: "adminSetMemberPassword_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"95c78d13f7863edc18b525b9fc4699f3d1919b2b6a6eb3c6a6a4ccc34c63d397": {
		functionName: "expireMyRewards_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"b13323a0bf590f1cc5a38d042991d5a29ab954e2683c33ff11dd3cadfd9e49f2": {
		functionName: "adminSetAccountState_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"c638f4607614c44874652ef7ac5e174ebdd5634c7945d171fa73d8e960f5e90f": {
		functionName: "reviewWithdrawal_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"d3aa2b19004a5d6f224214912fba60f0cce69c57763035e0c208c1bd2fef493e": {
		functionName: "getMyDirectTeam_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"daf614919d3622098abde76cc72ecfaedbd8fae5c963bdd9e051f7b9fadf1546": {
		functionName: "resetMemberPassword_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	},
	"edeb85c398aad8de0a3e5548afa06784ef16364854c645b9efaf1e5ed785647e": {
		functionName: "claimMyReward_createServerFn_handler",
		importer: () => import("./_ssr/mlm.functions-E378NHp5.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
