globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/phonepe-qr.png": {
		"type": "image/png",
		"etag": "\"37fb9-BZjLVaKLZezoweJEwgwRvuLZpyI\"",
		"mtime": "2026-09-15T15:09:18.504Z",
		"size": 229305,
		"path": "../public/phonepe-qr.png"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"217-FDuJkreooW0Hx18icNv6G+8KMEo\"",
		"mtime": "2026-09-15T15:09:18.503Z",
		"size": 535,
		"path": "../public/favicon.svg"
	},
	"/assets/SiteLayout-CwPixQyE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2315-/EFIjyxczBEs2iLYvBzPIYJrYBM\"",
		"mtime": "2026-09-15T15:09:17.057Z",
		"size": 8981,
		"path": "../public/assets/SiteLayout-CwPixQyE.js"
	},
	"/assets/circle-check-CP1fqZAq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-u+aY/QAbqqY8wVK1QvFvaIXYbcs\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 178,
		"path": "../public/assets/circle-check-CP1fqZAq.js"
	},
	"/assets/clock-TG24jTAE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-S6HhK2xNlrma8IDLTHu6P7RNXTM\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 169,
		"path": "../public/assets/clock-TG24jTAE.js"
	},
	"/assets/copy-DbTxdhzR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec-5GQT5EaeHouAqq/8jL/RFPC2i+g\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 236,
		"path": "../public/assets/copy-DbTxdhzR.js"
	},
	"/assets/contact-B2algsMm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d58-h4oYvWf5UoJf5SFk5lI56HAKwLk\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 3416,
		"path": "../public/assets/contact-B2algsMm.js"
	},
	"/assets/createLucideIcon-B-E48kAl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-T15DckxMpkR9v/ZOuQY/vmnt8dM\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 1192,
		"path": "../public/assets/createLucideIcon-B-E48kAl.js"
	},
	"/assets/disclaimer-CBTdyWUn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1e-J6a/Kd5vpCL2IqsJb3DJQ+XBHGk\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 2590,
		"path": "../public/assets/disclaimer-CBTdyWUn.js"
	},
	"/assets/forgot-password-CfykQ3Sz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9f-tXzQV/duTgotEHrD7dY8IwqlWRA\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 3231,
		"path": "../public/assets/forgot-password-CfykQ3Sz.js"
	},
	"/assets/dashboard-DmmcuyMY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2fb-c1RG4bS2tGqde1/QyZIpprZPIyA\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 41723,
		"path": "../public/assets/dashboard-DmmcuyMY.js"
	},
	"/assets/arrow-right-CaTwsgy1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-cx/+3/mJskGhNcVOIrbHZK/Ik0o\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 165,
		"path": "../public/assets/arrow-right-CaTwsgy1.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"49-CT9T01xZWJBkmsegSalCofVzDQ4\"",
		"mtime": "2026-09-15T15:09:18.504Z",
		"size": 73,
		"path": "../public/robots.txt"
	},
	"/assets/login-DxN-7Pha.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d6c-9ijRJTD3XvcmQgGh/iQZTUmdj3A\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 3436,
		"path": "../public/assets/login-DxN-7Pha.js"
	},
	"/assets/log-out-D46uYx7J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f4-T1+jVLE/nMY21ccgW/LInKbpGPQ\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 756,
		"path": "../public/assets/log-out-D46uYx7J.js"
	},
	"/assets/mlm.functions-D7oAExVB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1915-JBVAxtgLYG4fDOJKzHaXSwthwGI\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 6421,
		"path": "../public/assets/mlm.functions-D7oAExVB.js"
	},
	"/assets/plus-CEpKvdwy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-u0HvSFAyofedYCBK39cPEZ+58do\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 153,
		"path": "../public/assets/plus-CEpKvdwy.js"
	},
	"/assets/privacy-C7fIJq8R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5a-NfuSIvncW5qaoIThgFzRpGruGKw\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 2906,
		"path": "../public/assets/privacy-C7fIJq8R.js"
	},
	"/assets/password-input-Cft95woU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59a-Pp8haIcZCEQLAHEm9JBwf2pWr4U\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 1434,
		"path": "../public/assets/password-input-Cft95woU.js"
	},
	"/assets/plan-CUbdnE0U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24ba-DK616k1fzFMDN8vjDLXJsl2QaWE\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 9402,
		"path": "../public/assets/plan-CUbdnE0U.js"
	},
	"/assets/about--iXwOJF9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dfc-KUv+ZU812VIhOdYwsF/e9lKzn70\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 3580,
		"path": "../public/assets/about--iXwOJF9.js"
	},
	"/assets/admin-B_QZp26n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be7a-vA9hxtBBJnhDxmUqQzv5OQEU6Zo\"",
		"mtime": "2026-09-15T15:09:17.058Z",
		"size": 48762,
		"path": "../public/assets/admin-B_QZp26n.js"
	},
	"/assets/index-BC4UvvUF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90f6b-+2Au9mAWnjFzBCe8RCkAcirf6G0\"",
		"mtime": "2026-09-15T15:09:17.057Z",
		"size": 593771,
		"path": "../public/assets/index-BC4UvvUF.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"c680a-YIWoOfvkGHhOPxjFvPcD4vMxDLY\"",
		"mtime": "2026-09-15T15:09:18.504Z",
		"size": 813066,
		"path": "../public/logo.png"
	},
	"/aaurva-capsule.png": {
		"type": "image/png",
		"etag": "\"123d13-8/oaLnAfXaa8SZRFeyuP8jornRQ\"",
		"mtime": "2026-09-15T15:09:18.505Z",
		"size": 1195283,
		"path": "../public/aaurva-capsule.png"
	},
	"/assets/products-Dnw8G3EZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23ce-i89C2DXaEp2NAkgZrRQk78q971c\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 9166,
		"path": "../public/assets/products-Dnw8G3EZ.js"
	},
	"/assets/register-Bmne5W8c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1990-HCWMmhttBdNcD4CrHkjJreOR6tk\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 6544,
		"path": "../public/assets/register-Bmne5W8c.js"
	},
	"/assets/refund-DOFpfoji.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"96c-BNmzUGPFBV4CiAeBfDrmKzRLNvI\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 2412,
		"path": "../public/assets/refund-DOFpfoji.js"
	},
	"/assets/routes-PwbhPz5q.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3942-AeASfLFcdUYANePMF6l5jLSIdsI\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 14658,
		"path": "../public/assets/routes-PwbhPz5q.js"
	},
	"/assets/route-BG1EZr93.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a-0iUMVN6L/X8tBagmzzWyv/EjkZY\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 138,
		"path": "../public/assets/route-BG1EZr93.js"
	},
	"/assets/star-z4IXGf62.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e3-Sz3WSftGwr9U4B1f3RP1ywLevlQ\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 739,
		"path": "../public/assets/star-z4IXGf62.js"
	},
	"/assets/users-CxxkGPZO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-rQ5mviexTfmTRyb0miSUD4nUfj0\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 306,
		"path": "../public/assets/users-CxxkGPZO.js"
	},
	"/assets/useStore-DAs5vFz2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6b50-gJVpJ72ZOwiLeFNrSvHPv8Rvm2k\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 27472,
		"path": "../public/assets/useStore-DAs5vFz2.js"
	},
	"/assets/wallet-dSg6RgKt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-ATF6DKRVlWvrShw4XOmc9fejJZM\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 286,
		"path": "../public/assets/wallet-dSg6RgKt.js"
	},
	"/assets/styles-DHzyrMHg.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16c12-rzZ+ASSTbow5J+w/woegd/azNKs\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 93202,
		"path": "../public/assets/styles-DHzyrMHg.css"
	},
	"/assets/trending-up-B9F4ta3j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-aSC+Nu4CRHaEfVk84GSMQXoYtrY\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 175,
		"path": "../public/assets/trending-up-B9F4ta3j.js"
	},
	"/assets/shopping-bag-C1VUHukY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"154-zFadR8dKWVsgEjVRDyj630K5lcY\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 340,
		"path": "../public/assets/shopping-bag-C1VUHukY.js"
	},
	"/assets/terms-vOyg8a4k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ccf-SW+TayjTIf8oSATQ+0/iVxc98PA\"",
		"mtime": "2026-09-15T15:09:17.059Z",
		"size": 3279,
		"path": "../public/assets/terms-vOyg8a4k.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_j21Qvj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
