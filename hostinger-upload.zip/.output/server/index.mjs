globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"49-CT9T01xZWJBkmsegSalCofVzDQ4\"",
		"mtime": "2026-09-14T18:41:42.274Z",
		"size": 73,
		"path": "../public/robots.txt"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"217-FDuJkreooW0Hx18icNv6G+8KMEo\"",
		"mtime": "2026-09-14T18:41:42.274Z",
		"size": 535,
		"path": "../public/favicon.svg"
	},
	"/assets/about-C3EfAe9V.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dfc-EYIPyElMGB+r17YoiJsougxFmR0\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 3580,
		"path": "../public/assets/about-C3EfAe9V.js"
	},
	"/assets/SiteLayout-DT2TAG4L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2315-v4yji2ihssz4J2xxxw+TGkTrgLg\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 8981,
		"path": "../public/assets/SiteLayout-DT2TAG4L.js"
	},
	"/assets/arrow-right-CaTwsgy1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-cx/+3/mJskGhNcVOIrbHZK/Ik0o\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 165,
		"path": "../public/assets/arrow-right-CaTwsgy1.js"
	},
	"/assets/admin-BDwex2ci.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be7a-NwDcjh92COtkOZG54xM7OCvf4YU\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 48762,
		"path": "../public/assets/admin-BDwex2ci.js"
	},
	"/assets/contact-B8x8tYoe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d58-89iR4xk+kwGAaF8X5p4Bn1YAzmM\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 3416,
		"path": "../public/assets/contact-B8x8tYoe.js"
	},
	"/assets/clock-TG24jTAE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-S6HhK2xNlrma8IDLTHu6P7RNXTM\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 169,
		"path": "../public/assets/clock-TG24jTAE.js"
	},
	"/assets/createLucideIcon-B-E48kAl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-T15DckxMpkR9v/ZOuQY/vmnt8dM\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 1192,
		"path": "../public/assets/createLucideIcon-B-E48kAl.js"
	},
	"/assets/forgot-password-D-yWdZ4b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c9f-NfCFFiXK+Ov4WQ74zxBliJUAPlc\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 3231,
		"path": "../public/assets/forgot-password-D-yWdZ4b.js"
	},
	"/assets/disclaimer-C8VH-Hd9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a1e-Tb3DepBRHigBajBEpPCUnCQ7dq8\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 2590,
		"path": "../public/assets/disclaimer-C8VH-Hd9.js"
	},
	"/assets/dashboard-B7tku3A4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a2fb-dCGbp9mMJVSV+yaZ5Go4pkud1/s\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 41723,
		"path": "../public/assets/dashboard-B7tku3A4.js"
	},
	"/assets/login-D_qFmvoP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d6c-x4kIEP0CePs+umbj3LNS9xH+wnM\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 3436,
		"path": "../public/assets/login-D_qFmvoP.js"
	},
	"/assets/mlm.functions-DPUc81vs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1915-eiIMKBOq2BXiNXVP2tp1qLW+WD4\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 6421,
		"path": "../public/assets/mlm.functions-DPUc81vs.js"
	},
	"/assets/password-input-Cft95woU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59a-Pp8haIcZCEQLAHEm9JBwf2pWr4U\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 1434,
		"path": "../public/assets/password-input-Cft95woU.js"
	},
	"/assets/plan-ySW9X5Op.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24ba-7HcuVWdQz6nPc+6bmDdMlkGXu7c\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 9402,
		"path": "../public/assets/plan-ySW9X5Op.js"
	},
	"/assets/circle-check-CP1fqZAq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-u+aY/QAbqqY8wVK1QvFvaIXYbcs\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 178,
		"path": "../public/assets/circle-check-CP1fqZAq.js"
	},
	"/assets/plus-CEpKvdwy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-u0HvSFAyofedYCBK39cPEZ+58do\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 153,
		"path": "../public/assets/plus-CEpKvdwy.js"
	},
	"/assets/privacy-Dc9d1H3k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5a-F75YW1Rg7exvW/D3ClRDMOpPJ3c\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 2906,
		"path": "../public/assets/privacy-Dc9d1H3k.js"
	},
	"/assets/log-out-D46uYx7J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f4-T1+jVLE/nMY21ccgW/LInKbpGPQ\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 756,
		"path": "../public/assets/log-out-D46uYx7J.js"
	},
	"/assets/copy-DbTxdhzR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec-5GQT5EaeHouAqq/8jL/RFPC2i+g\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 236,
		"path": "../public/assets/copy-DbTxdhzR.js"
	},
	"/phonepe-qr.png": {
		"type": "image/png",
		"etag": "\"37fb9-BZjLVaKLZezoweJEwgwRvuLZpyI\"",
		"mtime": "2026-09-14T18:41:42.276Z",
		"size": 229305,
		"path": "../public/phonepe-qr.png"
	},
	"/assets/index-ZzwFvoB2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"90f6b-cqFsLVghJf6wWXqBAHPl7KDU+PU\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 593771,
		"path": "../public/assets/index-ZzwFvoB2.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"c680a-YIWoOfvkGHhOPxjFvPcD4vMxDLY\"",
		"mtime": "2026-09-14T18:41:42.276Z",
		"size": 813066,
		"path": "../public/logo.png"
	},
	"/aaurva-capsule.png": {
		"type": "image/png",
		"etag": "\"123d13-8/oaLnAfXaa8SZRFeyuP8jornRQ\"",
		"mtime": "2026-09-14T18:41:42.276Z",
		"size": 1195283,
		"path": "../public/aaurva-capsule.png"
	},
	"/assets/refund-Cj5qOp32.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"96c-aRk9oVP+D8p/hFzMzdbzIwCu/IQ\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 2412,
		"path": "../public/assets/refund-Cj5qOp32.js"
	},
	"/assets/star-z4IXGf62.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e3-Sz3WSftGwr9U4B1f3RP1ywLevlQ\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 739,
		"path": "../public/assets/star-z4IXGf62.js"
	},
	"/assets/route-DfxcyOBD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a-IDYL2kCRH6iiBkyRUdHrPXaM9uk\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 138,
		"path": "../public/assets/route-DfxcyOBD.js"
	},
	"/assets/routes-C5WZrcYz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3942-UtmFH4X+TBa1UYWRwv/Bnlv1VA0\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 14658,
		"path": "../public/assets/routes-C5WZrcYz.js"
	},
	"/assets/shopping-bag-C1VUHukY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"154-zFadR8dKWVsgEjVRDyj630K5lcY\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 340,
		"path": "../public/assets/shopping-bag-C1VUHukY.js"
	},
	"/assets/register-Cfo6N66l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1990-B8WDjRQvqzGXY/koP1iIlcSe+WY\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 6544,
		"path": "../public/assets/register-Cfo6N66l.js"
	},
	"/assets/useStore-DAs5vFz2.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6b50-gJVpJ72ZOwiLeFNrSvHPv8Rvm2k\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 27472,
		"path": "../public/assets/useStore-DAs5vFz2.js"
	},
	"/assets/wallet-dSg6RgKt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-ATF6DKRVlWvrShw4XOmc9fejJZM\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 286,
		"path": "../public/assets/wallet-dSg6RgKt.js"
	},
	"/assets/styles-DHzyrMHg.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"16c12-rzZ+ASSTbow5J+w/woegd/azNKs\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 93202,
		"path": "../public/assets/styles-DHzyrMHg.css"
	},
	"/assets/products-DOeozzOA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23ce-1q9qAHTmn4ecrwMhLrWmvvhEW0k\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 9166,
		"path": "../public/assets/products-DOeozzOA.js"
	},
	"/assets/trending-up-B9F4ta3j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-aSC+Nu4CRHaEfVk84GSMQXoYtrY\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 175,
		"path": "../public/assets/trending-up-B9F4ta3j.js"
	},
	"/assets/terms-CJ9KPTxx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ccf-cCGRZnepJGEpTBQSPwF952hUBOg\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 3279,
		"path": "../public/assets/terms-CJ9KPTxx.js"
	},
	"/assets/users-CxxkGPZO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-rQ5mviexTfmTRyb0miSUD4nUfj0\"",
		"mtime": "2026-09-14T18:41:41.045Z",
		"size": 306,
		"path": "../public/assets/users-CxxkGPZO.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_j21Qvj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
