globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as NodeResponse, i as defineLazyEventHandler, l as serve, n as HTTPError, r as defineHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/manifest.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"2bc-02MLlIN2W/2TTDDagOniVnwrkjc\"",
		"mtime": "2026-10-21T15:55:45.494Z",
		"size": 700,
		"path": "../public/manifest.webmanifest"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"49-CT9T01xZWJBkmsegSalCofVzDQ4\"",
		"mtime": "2026-10-21T15:55:45.498Z",
		"size": 73,
		"path": "../public/robots.txt"
	},
	"/assets/about-DPgiaWvh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dff-WiHHaJTHjUDnobqPSlzD9IyEByQ\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 3583,
		"path": "../public/assets/about-DPgiaWvh.js"
	},
	"/assets/arrow-right-BreTTagn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-KJ+x62igVgachkoTX0M/Dv1/NmA\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 165,
		"path": "../public/assets/arrow-right-BreTTagn.js"
	},
	"/assets/circle-check-e96BBa8W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-tDI0OzxnH2dQnhwERIqW0Z/QjOg\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 178,
		"path": "../public/assets/circle-check-e96BBa8W.js"
	},
	"/assets/clock-DhIl8hnh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-jfrJVKvSS2IQMLSAW+Eyogu6BAs\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 169,
		"path": "../public/assets/clock-DhIl8hnh.js"
	},
	"/phonepe-qr.png": {
		"type": "image/png",
		"etag": "\"37fb9-BZjLVaKLZezoweJEwgwRvuLZpyI\"",
		"mtime": "2026-10-21T15:55:45.494Z",
		"size": 229305,
		"path": "../public/phonepe-qr.png"
	},
	"/assets/contact-DG7WxIPw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5b-+tp2L2El0qdfDKcvRtNgIIG3oD8\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 3419,
		"path": "../public/assets/contact-DG7WxIPw.js"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"217-FDuJkreooW0Hx18icNv6G+8KMEo\"",
		"mtime": "2026-10-21T15:55:45.498Z",
		"size": 535,
		"path": "../public/favicon.svg"
	},
	"/.well-known/assetlinks.json": {
		"type": "application/json",
		"etag": "\"145-82B4KXKbVQ2Vpm3/ElUuX4MwJAs\"",
		"mtime": "2026-10-21T15:55:45.494Z",
		"size": 325,
		"path": "../public/.well-known/assetlinks.json"
	},
	"/sw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"235-jgjtrramo8KLDBtM+uW03coHoso\"",
		"mtime": "2026-10-21T15:55:45.498Z",
		"size": 565,
		"path": "../public/sw.js"
	},
	"/assets/createLucideIcon-BzbuOpc0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ab-YUTpwtnZEe5ENxea3zHPyRzQEQo\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 1195,
		"path": "../public/assets/createLucideIcon-BzbuOpc0.js"
	},
	"/assets/copy-CMHWJAm5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ec-Di3fZcr9qXPIWUZv7kYFNhqbupE\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 236,
		"path": "../public/assets/copy-CMHWJAm5.js"
	},
	"/assets/disclaimer-BNpmM8Dv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a21-pl498q/JSzRbWfhESpGCSs/vtkM\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 2593,
		"path": "../public/assets/disclaimer-BNpmM8Dv.js"
	},
	"/assets/forgot-password-Bi7ThQLG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d0b-/eCY8d95us4cPmQ84ojfpF+ofCc\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 3339,
		"path": "../public/assets/forgot-password-Bi7ThQLG.js"
	},
	"/assets/admin-WcOZrpaB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d2b3-0oXJygWhtnHZgJleAlpqrRNQ6lM\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 53939,
		"path": "../public/assets/admin-WcOZrpaB.js"
	},
	"/assets/download-dz5W4KKb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-HrfP8oEmBFhYEE8/Y8ApfzOUDXs\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 232,
		"path": "../public/assets/download-dz5W4KKb.js"
	},
	"/assets/log-out-BBDDtYdP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f4-+1H1TPDVP95uncaFMrRZaE8wEq4\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 756,
		"path": "../public/assets/log-out-BBDDtYdP.js"
	},
	"/assets/dashboard-8coBr0CP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b247-JKh4kH/nwNXcd7tB9oaR8hTp7qE\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 45639,
		"path": "../public/assets/dashboard-8coBr0CP.js"
	},
	"/assets/SiteLayout-BB4mSBeJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2431-cm6YTxdvVzpujx9XC6t/phhFsJw\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 9265,
		"path": "../public/assets/SiteLayout-BB4mSBeJ.js"
	},
	"/logo.png": {
		"type": "image/png",
		"etag": "\"c680a-YIWoOfvkGHhOPxjFvPcD4vMxDLY\"",
		"mtime": "2026-10-21T15:55:45.495Z",
		"size": 813066,
		"path": "../public/logo.png"
	},
	"/assets/login-CnfI1RvI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ed1-K08qERMzcFr3qPo+b/fnuJPMMIw\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 3793,
		"path": "../public/assets/login-CnfI1RvI.js"
	},
	"/aaurva-capsule.png": {
		"type": "image/png",
		"etag": "\"123d13-8/oaLnAfXaa8SZRFeyuP8jornRQ\"",
		"mtime": "2026-10-21T15:55:45.498Z",
		"size": 1195283,
		"path": "../public/aaurva-capsule.png"
	},
	"/assets/index-GqzRCOut.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"94623-11eBkA0T6MlbCLc5Ym+StUfib50\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 607779,
		"path": "../public/assets/index-GqzRCOut.js"
	},
	"/assets/password-input-BpMPp1VV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"59d-AY65yMRXoEt+3rLptBv9S12bolw\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 1437,
		"path": "../public/assets/password-input-BpMPp1VV.js"
	},
	"/assets/plan-BQa-hW0i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24bd-OsIkC2LtXgXrQuJvjsrO0NuPHAQ\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 9405,
		"path": "../public/assets/plan-BQa-hW0i.js"
	},
	"/assets/products-DCzlGzpr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"23d1-RCzvyGoERYVFbsJeXArOpMCcKTA\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 9169,
		"path": "../public/assets/products-DCzlGzpr.js"
	},
	"/assets/privacy-B65Qcl5d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b5d-fsuhYfL0yOmlFjbLBxqhFlSgnDU\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 2909,
		"path": "../public/assets/privacy-B65Qcl5d.js"
	},
	"/assets/register-wvdp_XbU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a5e-lKPKbzfOwyeisteGH+X8fhkhI8E\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 6750,
		"path": "../public/assets/register-wvdp_XbU.js"
	},
	"/assets/refund-e37OmyKS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"96f-GiH/KiaAMowaz9ovWHSsUMHKEZU\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 2415,
		"path": "../public/assets/refund-e37OmyKS.js"
	},
	"/assets/route-Do0t5JRe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8d-4OiKi3Yw3/qYbHPst/yV/gbsBhQ\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 141,
		"path": "../public/assets/route-Do0t5JRe.js"
	},
	"/assets/plus-BQgSUM9m.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"99-a7liVs7iMXQuKtNlNqpFIiHRXRw\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 153,
		"path": "../public/assets/plus-BQgSUM9m.js"
	},
	"/assets/shopping-bag-Kl6hK9mI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"154-QgEMzsrJPSgw7Xutz4YhEf/OT2s\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 340,
		"path": "../public/assets/shopping-bag-Kl6hK9mI.js"
	},
	"/assets/star-CVAYwxdY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2e3-G6Rp61A8wwOwnsIhIguK7TwnA9M\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 739,
		"path": "../public/assets/star-CVAYwxdY.js"
	},
	"/assets/terms-BnyiCptM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cd2-qIi1PE6ygmQ6tmFaa2JpiXzTyIM\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 3282,
		"path": "../public/assets/terms-BnyiCptM.js"
	},
	"/assets/trending-up-CT2_jQej.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-ASDxQBiWW94KVliQrgTKeTuMAHY\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 175,
		"path": "../public/assets/trending-up-CT2_jQej.js"
	},
	"/assets/users-BsfoCn1D.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-ua2U6ZcrvAwaJKCyhj4cDSvexEc\"",
		"mtime": "2026-10-21T15:55:44.137Z",
		"size": 306,
		"path": "../public/assets/users-BsfoCn1D.js"
	},
	"/assets/useSelector-C0pj3Bsi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2911-nWCeGhzOt7oMlz52lITJL+0HGF8\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 10513,
		"path": "../public/assets/useSelector-C0pj3Bsi.js"
	},
	"/assets/wallet-Cs0V40q1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-5elk8ULnNSt+ThwPSfZy5mhKGys\"",
		"mtime": "2026-10-21T15:55:44.137Z",
		"size": 286,
		"path": "../public/assets/wallet-Cs0V40q1.js"
	},
	"/assets/styles-ZQa4s9k-.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"17003-LiAU+/K83clT+u40PXjDdgo/aXg\"",
		"mtime": "2026-10-21T15:55:44.137Z",
		"size": 94211,
		"path": "../public/assets/styles-ZQa4s9k-.css"
	},
	"/assets/x-GyDu7eCf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9a-6F7t686rPhyLsotySmnGBbVNWbQ\"",
		"mtime": "2026-10-21T15:55:44.137Z",
		"size": 154,
		"path": "../public/assets/x-GyDu7eCf.js"
	},
	"/assets/routes-C0ORWWQ7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3c6e-E+VDVbSJWO+xmcnF/oJbis8Xx7g\"",
		"mtime": "2026-10-21T15:55:44.136Z",
		"size": 15470,
		"path": "../public/assets/routes-C0ORWWQ7.js"
	},
	"/righvedh-sanjivni.apk": {
		"type": "application/vnd.android.package-archive",
		"etag": "\"2550ae-N8dTZD79LAAOsaa73bdhtfO8mrM\"",
		"mtime": "2026-10-21T15:55:45.499Z",
		"size": 2445486,
		"path": "../public/righvedh-sanjivni.apk"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_j21Qvj = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_j21Qvj
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
