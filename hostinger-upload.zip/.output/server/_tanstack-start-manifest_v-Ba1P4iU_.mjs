//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ba1P4iU_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/about",
			"/contact",
			"/disclaimer",
			"/forgot-password",
			"/login",
			"/plan",
			"/privacy",
			"/products",
			"/refund",
			"/register",
			"/sitemap.xml",
			"/terms"
		],
		preloads: ["/assets/index-BC4UvvUF.js", "/assets/useStore-DAs5vFz2.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BC4UvvUF.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-PwbhPz5q.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/arrow-right-CaTwsgy1.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/SiteLayout-CwPixQyE.js",
			"/assets/star-z4IXGf62.js",
			"/assets/shopping-bag-C1VUHukY.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js"
		]
	},
	"/_authenticated": {
		filePath: "/dev-server/src/routes/_authenticated/route.tsx",
		children: ["/_authenticated/admin", "/_authenticated/dashboard"],
		preloads: ["/assets/route-BG1EZr93.js"]
	},
	"/about": {
		filePath: "/dev-server/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about--iXwOJF9.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/SiteLayout-CwPixQyE.js"
		]
	},
	"/contact": {
		filePath: "/dev-server/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-B2algsMm.js",
			"/assets/clock-TG24jTAE.js",
			"/assets/SiteLayout-CwPixQyE.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	},
	"/disclaimer": {
		filePath: "/dev-server/src/routes/disclaimer.tsx",
		children: void 0,
		preloads: ["/assets/disclaimer-CBTdyWUn.js", "/assets/SiteLayout-CwPixQyE.js"]
	},
	"/forgot-password": {
		filePath: "/dev-server/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-CfykQ3Sz.js",
			"/assets/mlm.functions-D7oAExVB.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-CwPixQyE.js"
		]
	},
	"/login": {
		filePath: "/dev-server/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DxN-7Pha.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-CwPixQyE.js"
		]
	},
	"/plan": {
		filePath: "/dev-server/src/routes/plan.tsx",
		children: void 0,
		preloads: [
			"/assets/plan-CUbdnE0U.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/arrow-right-CaTwsgy1.js",
			"/assets/SiteLayout-CwPixQyE.js",
			"/assets/plus-CEpKvdwy.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js"
		]
	},
	"/privacy": {
		filePath: "/dev-server/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-C7fIJq8R.js", "/assets/SiteLayout-CwPixQyE.js"]
	},
	"/products": {
		filePath: "/dev-server/src/routes/products.tsx",
		children: void 0,
		preloads: [
			"/assets/products-Dnw8G3EZ.js",
			"/assets/SiteLayout-CwPixQyE.js",
			"/assets/star-z4IXGf62.js",
			"/assets/shopping-bag-C1VUHukY.js"
		]
	},
	"/refund": {
		filePath: "/dev-server/src/routes/refund.tsx",
		children: void 0,
		preloads: ["/assets/refund-DOFpfoji.js", "/assets/SiteLayout-CwPixQyE.js"]
	},
	"/register": {
		filePath: "/dev-server/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-Bmne5W8c.js",
			"/assets/mlm.functions-D7oAExVB.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/copy-DbTxdhzR.js",
			"/assets/password-input-Cft95woU.js",
			"/assets/SiteLayout-CwPixQyE.js"
		]
	},
	"/terms": {
		filePath: "/dev-server/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-vOyg8a4k.js", "/assets/SiteLayout-CwPixQyE.js"]
	},
	"/_authenticated/admin": {
		filePath: "/dev-server/src/routes/_authenticated/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-B_QZp26n.js",
			"/assets/mlm.functions-D7oAExVB.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/circle-check-CP1fqZAq.js",
			"/assets/log-out-D46uYx7J.js",
			"/assets/plus-CEpKvdwy.js",
			"/assets/users-CxxkGPZO.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "/dev-server/src/routes/_authenticated/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DmmcuyMY.js",
			"/assets/mlm.functions-D7oAExVB.js",
			"/assets/createLucideIcon-B-E48kAl.js",
			"/assets/clock-TG24jTAE.js",
			"/assets/copy-DbTxdhzR.js",
			"/assets/log-out-D46uYx7J.js",
			"/assets/shopping-bag-C1VUHukY.js",
			"/assets/trending-up-B9F4ta3j.js",
			"/assets/users-CxxkGPZO.js",
			"/assets/wallet-dSg6RgKt.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
